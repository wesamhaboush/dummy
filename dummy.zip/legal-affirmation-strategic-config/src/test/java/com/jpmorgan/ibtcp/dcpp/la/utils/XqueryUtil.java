package com.jpmorgan.ibtcp.dcpp.la.utils;

import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.ibtcp.dcpp.la.utils.ModelFactory;
import net.sf.saxon.s9api.*;
import org.apache.commons.io.IOUtils;

import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static net.sf.saxon.event.Builder.LINKED_TREE;
import static net.sf.saxon.lib.FeatureKeys.TREE_MODEL;

public class XqueryUtil {
	public XqueryUtil() {
	}

	private static final ModelFactory MODEL_FACTORY = new ModelFactory(true);

	private static Processor proc = createProcessor();

    private static Processor createProcessor(){
        Processor proc = new Processor(true);
        proc.setConfigurationProperty(TREE_MODEL, LINKED_TREE);
        return proc;
    }
	public static XQueryEvaluator xqueryEvaluator(String xqueryModule, Map<String, String> varValueMap)
			throws SaxonApiException {
		XQueryCompiler comp = proc.newXQueryCompiler();
		comp.setUpdatingEnabled(true);
		XQueryExecutable exp = comp.compile(xqueryModule);

		XQueryEvaluator qe = exp.load();

		for (Map.Entry<String, String> entry : varValueMap.entrySet()) {
			XdmNode source = proc.newDocumentBuilder().build(new StreamSource(IOUtils.toInputStream(entry.getValue())));
			qe.setExternalVariable(new QName(entry.getKey()), source);
		}
		return qe;
	}

	public static XQueryEvaluator xqueryEvaluatorForXdmvalue(String xqueryModule, Map<String, XdmValue> varValueMap)
			throws SaxonApiException {
		XQueryCompiler comp = proc.newXQueryCompiler();
		comp.setUpdatingEnabled(true);
		XQueryExecutable exp = comp.compile(xqueryModule);
		XQueryEvaluator qe = exp.load();
		for (Map.Entry<String, XdmValue> entry : varValueMap.entrySet()) {
			qe.setExternalVariable(new QName(entry.getKey()), entry.getValue());
		}
		return qe;
	}

	/**
	 * Get value from Xdm Node.
	 * 
	 * @param xpath
	 *            string.
	 * @param proc
	 *            processor from XQuery Engine.
	 * @return string value of xpath.
	 * @throws Exception
	 *             if we get a Exception.
	 */
	public static String getViaXpath(final String xpath, final XdmNode node) throws SaxonApiException {
		XPathCompiler xPathCompiler = proc.newXPathCompiler();
		XPathSelector pathSelector = xPathCompiler.compile(xpath).load();
		pathSelector.setContextItem(node);
		StringWriter sw = new StringWriter();
		Serializer out = proc.newSerializer(sw);
		out.setOutputProperty(Serializer.Property.OMIT_XML_DECLARATION, "yes");
		proc.writeXdmValue(pathSelector.evaluate(), out);
		return sw.toString();
	}

	public static XdmNode getXdmNode(String xml) throws SaxonApiException {
		return proc.newDocumentBuilder().build(new StreamSource(new StringReader(xml)));
	}

	public static String removePrelog(final String xml) {
		return xml.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
	}

	public static String getStringFromPayload(DsThunderheadInput dsThi) {
		return MODEL_FACTORY.toXml(dsThi);
	}

	public static DsThunderheadInput getDsThunderheadInputFromResult(XdmValue result) {
		final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
		return MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
	}

    public static String asString(XdmItem xdmItem) {
        return xdmItem.getStringValue().replace("#END","");
    }


}
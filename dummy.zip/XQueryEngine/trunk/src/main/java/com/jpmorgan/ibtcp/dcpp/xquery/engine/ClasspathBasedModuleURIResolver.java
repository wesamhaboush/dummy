package com.jpmorgan.ibtcp.dcpp.xquery.engine;

import net.sf.saxon.lib.ModuleURIResolver;
import net.sf.saxon.trans.XPathException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;

import static com.google.common.base.Throwables.propagate;

class ClasspathBasedModuleURIResolver implements ModuleURIResolver, Serializable {
    private static final transient Logger LOGGER = LoggerFactory.getLogger(ClasspathBasedModuleURIResolver.class);
    private static final long serialVersionUID = -480364471418950068L;
    private final String classpathModuleBase;

    public ClasspathBasedModuleURIResolver(final String classpathModuleBase) {
        this.classpathModuleBase = classpathModuleBase;
    }

    @Override
    public final StreamSource[] resolve(final String s, final String s1, final String[] strings)
            throws XPathException {
        LOGGER.debug("s[{}], s1[{}], strings[{}]", s, s1, Arrays.asList(strings));
        final StreamSource[] sources = new StreamSource[strings.length];
        for (int i = 0; i < strings.length; i++) {
            sources[i] = loadResource(strings[i], i);
        }
        return sources;
    }

    private StreamSource loadResource(final String string, final int i) {
        try {
            final String[] split = string.split(":");
            final String fileName = split[split.length - 1];
            LOGGER.debug("Trying to Load XQuery Module {} {}", classpathModuleBase, fileName);
            final Resource resource = new ClassPathResource(classpathModuleBase + fileName);
            return new StreamSource(resource.getInputStream());
        } catch (IOException e) {
            throw propagate(e);
        }
    }
}

package com.jpmorgan.dcpp.commons;

import net.sf.saxon.TransformerFactoryImpl;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

public class Xsl {

  private static final TransformerFactory TRANSFORMER_FACTORY =  TransformerFactoryImpl.newInstance();

  public static void apply(final InputStream xslInputStream,
                           final InputStream xmlInputStream,
                           final OutputStream outputStream) throws IOException, TransformerException {
    final StreamSource xslSource = new StreamSource(xslInputStream);
    final StreamSource xmlSource = new StreamSource(xmlInputStream);
    final Transformer transformer = TRANSFORMER_FACTORY.newTransformer(xslSource);
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
    transformer.setOutputProperty(OutputKeys.ENCODING, Charsets.UTF_8.name());
    final StreamResult result = new StreamResult(new StringWriter());
    transformer.transform(xmlSource, result);
    outputStream.write(result.getWriter().toString().getBytes());
    outputStream.flush();
  }

  public static String apply(final String xsl,
                             final String xml) throws IOException, TransformerException {
    final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    try {
      apply(IOUtils.toInputStream(xsl), IOUtils.toInputStream(xml), outputStream);
      return new String(outputStream.toByteArray(), Charsets.UTF_8.name());
    } finally {
      IOUtils.closeQuietly(outputStream);
    }
  }
}

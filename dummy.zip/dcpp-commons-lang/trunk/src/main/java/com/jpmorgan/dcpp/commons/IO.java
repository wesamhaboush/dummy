package com.jpmorgan.dcpp.commons;

import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.slf4j.Logger;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import static com.jpmorgan.dcpp.commons.Objects.isNull;

public class IO {
    private  final static transient Logger LOG = Slf4jLoggerFactory.create();
    private final static Closeable NULL_CLOSEABLE = new Closeable() {
        @Override
        public void close() throws IOException {
            //do nothing
        }
    };
    private static final String DEFAULT_CLOSE_METHOD_NAME = "close";

    private IO(){}

    public static void closeQuietly(final Closeable... closeables){
        for(final Closeable closeable : closeables){
            try{
                if(closeable != null){
                    closeable.close();
                }
            } catch (final Exception e) {
                LOG.warn("failed to close {}, moving on ..", closeable);
            }
        }
    }

    public static <T> Closeable asCloseable(final T t){
        if(isNull(t)){
            return NULL_CLOSEABLE;
        } else {
            return new Closeable(){
                @Override
                public void close() throws IOException {
                    try {
                        t.getClass().getMethod(DEFAULT_CLOSE_METHOD_NAME).invoke(t);
                    } catch (IllegalAccessException e) {
                        LOG.warn("couldn't invoke {} on object {} ", DEFAULT_CLOSE_METHOD_NAME, t);
                    } catch (InvocationTargetException e) {
                        LOG.warn("couldn't invoke {} on object {} ", DEFAULT_CLOSE_METHOD_NAME, t);
                    } catch (NoSuchMethodException e) {
                        LOG.warn("couldn't invoke {} on object {} ", DEFAULT_CLOSE_METHOD_NAME, t);
                    }
                }
            };
        }
    }

    public static <T> Closeable asCloseable(final T t, final String closeMethodName){
        if(isNull(t)){
            return NULL_CLOSEABLE;
        } else {
            return new Closeable(){
                @Override
                public void close() throws IOException {
                    try {
                        t.getClass().getMethod(closeMethodName).invoke(t);
                    } catch (IllegalAccessException e) {
                        LOG.warn("couldn't invoke [{}] on object [{}] ", closeMethodName, t);
                    } catch (InvocationTargetException e) {
                        LOG.warn("couldn't invoke [{}] on object [{}] ", closeMethodName, t);
                    } catch (NoSuchMethodException e) {
                        LOG.warn("couldn't invoke [{}] on object [{}] ", closeMethodName, t);
                    }
                }
            };
        }
    }
}

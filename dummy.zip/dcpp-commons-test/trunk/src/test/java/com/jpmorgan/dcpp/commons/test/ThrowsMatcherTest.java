package com.jpmorgan.dcpp.commons.test;

import org.junit.Test;

import static com.jpmorgan.dcpp.commons.test.ThrowsMatcher.isThrownBy;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class ThrowsMatcherTest {

    @Test
    public void testIsThrownBy() throws Exception {
        //given
        final String x = null;

        //when
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                x.toString();
            }
        };

        //then
        assertThat(NullPointerException.class, isThrownBy(runnable));
    }

    @Test
    public void testIsNotThrownBy() throws Exception {
        //given

        //when
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
            }
        };

        //then
        assertThat(NullPointerException.class, not(isThrownBy(runnable)));
    }
}

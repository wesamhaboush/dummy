package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ClassesTest {
    @Test
    public void testGetClassLoader() throws Exception {
        assertNotNull(Classes.getClassLoader());
    }

    @Test
    public void testIsArray() {
        final Object[] array = new Object[0];

        assertTrue(Classes.isArray(array));
    }

    @Test(expected = RuntimeException.class)
    public void testIsArrayExceptionCase() {
        final Object[] nullArray = null;
        Classes.isArray(nullArray);
    }

    @Test
    public void testGetCaller1() throws ClassNotFoundException {
        assertEquals(Class.forName("org.junit.runners.model.FrameworkMethod$1"), Classes.getInvokerClassOfCurrentMethod());
    }

    @Test
    public void testGetCaller2() throws ClassNotFoundException {
        new CallerClass(new CalleeClass()).method();
    }

    @Test
    public void testGetCurrentClass() throws ClassNotFoundException {
        assertEquals(this.getClass(), Classes.getCurrentClass());
    }


    @Test
    public void testGetClasspathItems() throws ClassNotFoundException {
        System.out.println(Classes.getClasspathItems());
    }

    //utils

    private static class CallerClass {
        private final CalleeClass callee;

        public CallerClass(final CalleeClass callee){
            this.callee = callee;
        }

        public void method(){
            callee.method();
        }
    }

    private static class CalleeClass {
        public void method(){
            assertEquals(CallerClass.class, Classes.getInvokerClassOfCurrentMethod());
        }
    }
}

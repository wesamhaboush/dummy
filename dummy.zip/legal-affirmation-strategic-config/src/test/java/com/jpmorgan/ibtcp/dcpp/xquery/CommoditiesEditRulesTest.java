package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.TBooleanConditionTypeEnum;
import com.jpmorgan.dcpp.la.model.generated.TValueTypeEnum;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static com.jpmorgan.dcpp.commons.Randoms.randomBoolean;
import static com.jpmorgan.dcpp.commons.Randoms.randomFrom;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CommoditiesEditRulesTest extends AbstractXqueryTest {

    private static final String EDIT_RULES_XQY = "PaperConfirmationBusinessRules/Commodity/edit_commodities.xqy";
    private static final String CODE_TO_STUB = "editReason:addEditReason($editReason)";
    private static final String STUB_CODE = "$editReason";

    @Test
    public void testEditForNonBullionEgyMissingISDA() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Long Form ISDA Pending";
        final String owningBusiness = "EGY";
        final boolean agreementPending = true;
        final String tradeDomain = "85";

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .withAgreementPending(agreementPending)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        assertEquals(editReason, resultXdmItems.iterator().next().toString());
    }

    @Test
    public void testEditForNonBullionEgyNoIsdaAgreement() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Long Form - No Agreement";
        final String owningBusiness = "EGY";
        final String tradeDomain = "85";

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .noAgreements()
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        assertEquals(editReason, resultXdmItems.iterator().next().toString());
    }

    @Test
    public void testEditForNonBullionEgyNoIsdaAgreement2() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Long Form - No Agreement";
        final String owningBusiness = "EGY";
        final String tradeDomain = "85";

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .emptyAgreement()
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        assertEquals(editReason, resultXdmItems.iterator().next().toString());
    }

    @Test
    public void testEditForNonBullionEgyDefaultOffsetDays() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Default value for Offset Days";
        final String owningBusiness = "EGY";
        final String tradeDomain = "85";

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .withTradeLeg(999, randomFrom(TValueTypeEnum.class), nextInt(0, 50000))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue(Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testEditForEgyBreakStp() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Break STP flag set to true in trade message";
        final String owningBusiness = "EGY";
        final String tradeDomain = "85";
        final boolean breakStp = true;

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .withConfirmationProcessing(randomAlphabetic(5), breakStp, randomFrom(TBooleanConditionTypeEnum.class), randomBoolean())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue(Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testNoAutoExercise() throws IOException, SaxonApiException {
        //given
        final String editReason = "Break STP - Alternative Exercise Provisions need to be added";
        final String owningBusiness = "EGY";
        final String tradeDomain = "85";
        final boolean automaticExercise = true;

        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeDomain(tradeDomain)
                .withAutomaticExercise(automaticExercise)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        //System.out.println(payloadXml);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue(Iterators.any(reasons, hasReason(editReason)));
    }


    private Predicate<? super String> hasReason(final String targetReason) {
        return new Predicate<String>() {
            @Override
            public boolean apply(final String currentReason) {
                return targetReason.equals(currentReason);
            }
        };
    }

    private Function<XdmItem, String> convertToString() {
        return new Function<XdmItem, String>() {
            @Override
            public String apply(final XdmItem xdmItem) {
                return xdmItem.toString();
            }
        };
    }
}

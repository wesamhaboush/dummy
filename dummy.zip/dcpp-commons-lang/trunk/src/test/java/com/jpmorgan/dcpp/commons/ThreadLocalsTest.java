package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.junit.After;
import org.junit.Test;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static com.google.common.base.Throwables.propagate;
import static java.util.concurrent.Executors.newSingleThreadExecutor;
import static org.junit.Assert.*;

public class ThreadLocalsTest {

    @Test
    public void testEquals() {
        assertTrue(new EntityClass("").equals(new EntityClass("")));
    }

    @Test
    public void testGetTLODoesNotMixObjectsAcrossThreads() throws Exception {
        //given
        final CyclicBarrier cyclicBarrier = new CyclicBarrier(2);
        final List<Throwable> exceptions = new LinkedList<Throwable>();
        final Runnable runnable1 = new ThreadLocalsUsingRunnable(cyclicBarrier, exceptions);
        final Runnable runnable2 = new ThreadLocalsUsingRunnable(cyclicBarrier, exceptions);

        //when
        final Thread thread1 = new Thread(runnable1);
        thread1.start();
        final Thread thread2 = new Thread(runnable2);
        thread2.start();

        thread1.join();
        thread2.join();

        //then
        //in the runnables themselves plus this one here to check for errors
        assertTrue("exceptions found, but not expected " + exceptions, exceptions.isEmpty());
    }

    @Test
    public void testPutTLODoesOverrideExistingValues() throws Exception {
        //given
        final String value1 = "value1";
        final String value2 = "value2";

        ThreadLocals.clear();
        ThreadLocals.putTlo(String.class, value1);
        final String result1 = ThreadLocals.getTLO(String.class, String.class);

        //when
        ThreadLocals.putTlo(String.class, value2);
        final String result2 = ThreadLocals.getTLO(String.class, String.class);

        //then
        assertEquals(value1, result1);
        assertEquals(value2, result2);
    }

    @Test
    public void testPutTLOIfAbsentDoesNotOverrideExistingValues() throws Exception {
        //given
        final String value1 = "value1";
        final String value2 = "value2";

        ThreadLocals.clear();
        ThreadLocals.putTlo(String.class, value1);
        final String result1 = ThreadLocals.getTLO(String.class, String.class);

        //when
        ThreadLocals.putTloIfAbsent(String.class, value2);
        final String result2 = ThreadLocals.getTLO(String.class, String.class);

        //then
        assertEquals(value1, result1);
        assertEquals(value1, result2);
    }


    @Test
    public void testClearRemovesObjectFromCurrentThreadMap() throws Exception {
        //given
        ThreadLocals.putTlo(EntityClass.class, new EntityClass(Thread.currentThread().getId() + ""));
        assertEquals(new EntityClass(Thread.currentThread().getId() + ""), ThreadLocals.getTLO(EntityClass.class, EntityClass.class));

        //when
        ThreadLocals.clear();

        //then
        assertNull(ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
    }

    @Test
    public void testClearRemovesObjectFromCurrentThreadMapButNotOthers() throws Exception {
        //given
        final CyclicBarrier addingCyclicBarrier = new CyclicBarrier(2);
        final CyclicBarrier clearingCyclicBarrier = new CyclicBarrier(2);
        final AtomicBoolean clearanceOccurend = new AtomicBoolean(false);

        final class ClearingThreadLocalMapClass implements Runnable {
            @Override
            public void run() {
                //add an object
                ThreadLocals.putTlo(EntityClass.class, new EntityClass(Thread.currentThread().getId() + ""));
                try {
                    //wait for others to add their objects too
                    addingCyclicBarrier.await();
                } catch (InterruptedException e) {
                    throw propagate(e);
                } catch (BrokenBarrierException e) {
                    throw propagate(e);
                }
                //check your object exists
                assertEquals(new EntityClass(Thread.currentThread().getId() + ""), ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
                //Once object out of the two should clear the barrier. this is random, and it does not matter.
                final boolean isItMeWhoClearsTheMap = clearanceOccurend.compareAndSet(false, true);
                if (isItMeWhoClearsTheMap) {
//                    System.out.println(Thread.currentThread().getId() + " clearing map");
                    ThreadLocals.clear();
                } else {
//                    System.out.println(Thread.currentThread().getId() + " NOT clearing map");
                }
                try {
                    //wait for someone to remove it
                    clearingCyclicBarrier.await();
                } catch (InterruptedException e) {
                    throw propagate(e);
                } catch (BrokenBarrierException e) {
                    throw propagate(e);
                }
                //now, if you were cleared, check object is NOT available. If you were not, check object is available.
                if (isItMeWhoClearsTheMap) {
                    assertNull(ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
                } else {
                    assertEquals(new EntityClass(Thread.currentThread().getId() + ""), ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
                }
            }
        }
        ;

        //when
        final Thread thread1 = new Thread(new ClearingThreadLocalMapClass());
        thread1.start();
        final Thread thread2 = new Thread(new ClearingThreadLocalMapClass());
        thread2.start();

        //then
        //all assertions are on the class above
    }

    @Test
    public void testClearingNonInitializedThreadLocalsIsSafe() throws ExecutionException, InterruptedException {
        //given
        final Runnable codeToRun = new Runnable() {
            @Override
            public void run() {
                ThreadLocals.clear();
            }
        };

        //when
        final Future<?> resultPromise = newSingleThreadExecutor().submit(codeToRun);

        //then
        assertNull(resultPromise.get());
    }

    @After
    public void tearDown() throws Exception {
        ThreadLocals.destroy();
    }

    @Test
    public void testGetThreadVariableString() {
        String variableName = "TEST_VAR";
        Object variable = ThreadLocals.getTLO(variableName, String.class);
        assertNull(variable);

        Integer newValue = Integer.valueOf(10);
        ThreadLocals.putTlo(variableName, newValue);
        Object variable2 = ThreadLocals.getTLO(variableName, Integer.class);
        assertNotNull(variable2);
        assertSame(newValue, variable2);
        assertEquals(newValue, variable2);
    }

    @Test
    public void testGetThreadVariableString_MultiThreads() throws InterruptedException {
        final Map<String, Object> varMap = new HashMap<String, Object>();
        final String thread1Name = "THREAD_1";
        final String thread2Name = "THREAD_2";
        final String variableName = "TEST_VAR";
        final Integer initialValue = new Integer(0);
        final Integer secondValue = new Integer(1);
        Runnable runnable1 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, initialValue);
                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                varMap.put(thread1Name, variable);
            }
        };

        Runnable runnable2 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, secondValue);
                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                varMap.put(thread2Name, variable);
            }
        };

        Thread thread1 = new Thread(runnable1);
        Thread thread2 = new Thread(runnable2);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();


        Object variable = varMap.get(thread1Name);
        assertNotNull(variable);
        assertSame(initialValue, variable);
        assertEquals(0, variable);

        Object variable2 = varMap.get(thread2Name);
        assertNotNull(variable2);
        assertNotSame(initialValue, variable2);
        assertEquals(1, variable2);
    }

    @Test
    public void testGetThreadVariableStringInitialValue_withClass() {
        String variableName = "TEST_VAR";
        Integer initialValue = new Integer(0);
        Integer variable = ThreadLocals.getTLO(variableName, initialValue.getClass());
        assertNull(variable);
    }

    @Test
    public void testDestroy_MultiThreads() throws InterruptedException {
        final String variableName = "TEST_VAR";
        final Integer initialValue = new Integer(0);
        final Integer secondValue = new Integer(1);
        Runnable runnable1 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, initialValue);

                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                assertNotNull(variable);

                ThreadLocals.destroy();
                variable = ThreadLocals.getTLO(variableName, String.class);
                assertNull(variable);
            }
        };

        Runnable runnable2 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, secondValue);
                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                assertNotNull(variable);

                ThreadLocals.destroy();

                variable = ThreadLocals.getTLO(variableName, String.class);
                assertNull(variable);

            }
        };

        Thread thread1 = new Thread(runnable1);
        Thread thread2 = new Thread(runnable2);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();
    }

    @Test
    public void testRemoveVariable_MultiThreads() throws InterruptedException {
        final String variableName = "TEST_VAR";
        final String variableName2 = "TEST_VAR2";
        final Integer initialValue = new Integer(0);
        final AtomicInteger assertions = new AtomicInteger(0);
        Runnable runnable1 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, initialValue);
                ThreadLocals.putTlo(variableName2, initialValue);

                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                Object variable2 = ThreadLocals.getTLO(variableName2, Integer.class);
                assertNotNull(variable);
                assertions.incrementAndGet();
                assertNotNull(variable2);
                assertions.incrementAndGet();

                ThreadLocals.remove(variableName);

                variable = ThreadLocals.getTLO(variableName, String.class);
                variable2 = ThreadLocals.getTLO(variableName2, Integer.class);

                assertNull(variable);
                assertions.incrementAndGet();
                assertNotNull(variable2);
                assertions.incrementAndGet();
            }
        };

        Runnable runnable2 = new Runnable() {

            @Override
            public void run() {
                ThreadLocals.putTlo(variableName, initialValue);
                ThreadLocals.putTlo(variableName2, initialValue);

                Object variable = ThreadLocals.getTLO(variableName, Integer.class);
                Object variable2 = ThreadLocals.getTLO(variableName2, Integer.class);
                assertNotNull(variable);
                assertions.incrementAndGet();
                assertNotNull(variable2);
                assertions.incrementAndGet();

                ThreadLocals.remove(variableName);

                variable = ThreadLocals.getTLO(variableName, String.class);
                variable2 = ThreadLocals.getTLO(variableName2, Integer.class);

                assertNull(variable);
                assertions.incrementAndGet();
                assertNotNull(variable2);
                assertions.incrementAndGet();
            }
        };

        Thread thread1 = new Thread(runnable1);
        Thread thread2 = new Thread(runnable2);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();
        //check no exceptions were thrown in the runners (bypassing the assertions)
        assertEquals(8, assertions.get());
    }

    //Utils

    private static final class EntityClass {
        private final String data;

        private EntityClass(String data) {
            this.data = data;
        }

        @Override
        public boolean equals(Object that) {
            return EqualsBuilder.reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }
    }

    private static class ThreadLocalsUsingRunnable implements Runnable {
        private final CyclicBarrier cyclicBarrier;
        private final List<Throwable> exceptions;

        private ThreadLocalsUsingRunnable(CyclicBarrier cyclicBarrier, List<Throwable> exceptions) {
            this.cyclicBarrier = cyclicBarrier;
            this.exceptions = exceptions;
        }

        @Override
        public void run() {
            try{
                doRun();
            }catch (Throwable throwable){
                exceptions.add(throwable);
            }
        }

        private void doRun() throws InterruptedException, BrokenBarrierException {
            final EntityClass entityInstance = new EntityClass(String.valueOf(Thread.currentThread().getId()));
            ThreadLocals.putTlo(EntityClass.class, entityInstance);
            System.out.println(Thread.currentThread().getId() + " waiting other threads to insert their values ...");
            cyclicBarrier.await();
            System.out.println(Thread.currentThread().getId() + " checking values ...");
            final EntityClass expected = new EntityClass(String.valueOf(Thread.currentThread().getId()));
            assertEquals(expected, ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
            assertSame(entityInstance, ThreadLocals.getTLO(EntityClass.class, EntityClass.class));
            System.out.println(Thread.currentThread().getId() + " finished successfully ");
        }
    }
}

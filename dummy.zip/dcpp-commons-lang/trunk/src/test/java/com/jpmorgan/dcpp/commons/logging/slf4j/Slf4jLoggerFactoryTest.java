package com.jpmorgan.dcpp.commons.logging.slf4j;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class Slf4jLoggerFactoryTest {
    @Test
    public void testCreate() throws Exception {
        assertNotNull(Slf4jLoggerFactory.create());
    }
}

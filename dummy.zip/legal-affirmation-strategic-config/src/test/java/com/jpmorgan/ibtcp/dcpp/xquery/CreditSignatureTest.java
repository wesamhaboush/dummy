package com.jpmorgan.ibtcp.dcpp.xquery;

import static com.jpmorgan.dcpp.commons.Xmls.xpathValue;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.ibtcp.dcpp.la.utils.ModelFactory;

public class CreditSignatureTest extends AbstractXqueryTest {

    private static final ModelFactory MODEL_FACTORY = new ModelFactory(false);
    public static final String SIGNATURE_TRANSFORM_RESOURCE_XQY =
            "PaperConfirmationBusinessRules/Credit/SignatureRule.xqy";
    private static final String OQL_CODE_TO_STUB = "lookup:oql('getSignature',concat('id=',$sigId))";

    @Test
    public void testEnrichPayload_N059923_Signature() throws IOException, SaxonApiException, XPathExpressionException,
            SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                "<gbom><referenceData><common><businessId><id>N059923</id></businessId></common><workerData><name><first>Josephine</first><middle>M</middle><last>Sullivan</last></name></workerData></referenceData></gbom>";

        StringBuilder testPayload = new StringBuilder();
        testPayload.append("<dsThunderheadInput>");
        testPayload.append("<owningSubBusiness>Exotics &amp; Hybrids - Credit</owningSubBusiness>");
        testPayload.append("<parties>");
        testPayload.append("</parties>");
        testPayload.append("<productEnrichment>");
        testPayload.append("<assetClass>Credit</assetClass>");
        testPayload.append("</productEnrichment>");
        testPayload
                .append("<clientContacts><contact><documentDeliveryMedium>FAX</documentDeliveryMedium></contact></clientContacts>");
        testPayload.append("</dsThunderheadInput>");
        DsThunderheadInput inputPayload = MODEL_FACTORY.fromXml(testPayload.toString(), DsThunderheadInput.class);
        String payload = MODEL_FACTORY.toXml(inputPayload);
        //given
        final String xqueryModule = addStubs(loadModuleAsString(SIGNATURE_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);
        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals("SIGNATORY", xpathValue(result.toString(), "//personDetails/personDetail/type/text()"));
        assertEquals("N059923", xpathValue(result.toString(), "//personDetails/personDetail/id/text()"));
        assertEquals("Josephine", xpathValue(result.toString(), "//personDetails/personDetail/firstName/text()"));
        assertEquals("M", xpathValue(result.toString(), "//personDetails/personDetail/secondName/text()"));
        assertEquals("Sullivan", xpathValue(result.toString(), "//personDetails/personDetail/surname/text()"));
    }

    @Test
    public void testEnrichPayload_I050367_Signature() throws IOException, SaxonApiException, XPathExpressionException,
            SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                "<gbom><referenceData><common><businessId><id>I050367</id></businessId></common><workerData><name><first>Angela</first><middle>A</middle><last>Mann</last></name></workerData></referenceData></gbom>";

        StringBuilder testPayload = new StringBuilder();
        testPayload.append("<dsThunderheadInput>");
        testPayload.append("<owningSubBusiness>Credit Flow</owningSubBusiness>");
        testPayload.append("<parties>");
        testPayload.append("</parties>");
        testPayload.append("<productEnrichment>");
        testPayload.append("<assetClass>Credit</assetClass>");
        testPayload.append("</productEnrichment>");
        testPayload
                .append("<clientContacts><contact><documentDeliveryMedium>FAX</documentDeliveryMedium></contact></clientContacts>");
        testPayload.append("</dsThunderheadInput>");
        //given
        final String xqueryModule = addStubs(loadModuleAsString(SIGNATURE_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);
        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", testPayload.toString()).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals("SIGNATORY", xpathValue(result.toString(), "//personDetails/personDetail/type/text()"));
        assertEquals("I050367", xpathValue(result.toString(), "//personDetails/personDetail/id/text()"));
        assertEquals("Angela", xpathValue(result.toString(), "//personDetails/personDetail/firstName/text()"));
        assertEquals("A", xpathValue(result.toString(), "//personDetails/personDetail/secondName/text()"));
        assertEquals("Mann", xpathValue(result.toString(), "//personDetails/personDetail/surname/text()"));
    }

    @Test
    public void testEnrichPayload_For_Hardcopy() throws IOException, SaxonApiException, XPathExpressionException,
            SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                "<gbom><referenceData><common><businessId><id>I050367</id></businessId></common><workerData><name><first>Angela</first><middle>A</middle><last>Mann</last></name></workerData></referenceData></gbom>";

        StringBuilder testPayload = new StringBuilder();
        testPayload.append("<dsThunderheadInput>");
        testPayload.append("<owningSubBusiness>Credit Flow</owningSubBusiness>");
        testPayload.append("<parties>");
        testPayload.append("</parties>");
        testPayload.append("<productEnrichment>");
        testPayload.append("<assetClass>Credit</assetClass>");
        testPayload.append("</productEnrichment>");
        testPayload
                .append("<clientContacts><contact><contactType>PRIMARY</contactType><documentDeliveryMedium>HARDCOPY</documentDeliveryMedium></contact></clientContacts>");
        testPayload.append("</dsThunderheadInput>");
        //given
        final String xqueryModule = addStubs(loadModuleAsString(SIGNATURE_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);
        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", testPayload.toString()).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals("SIGNATORY", xpathValue(result.toString(), "//personDetails/personDetail/type/text()"));
        assertEquals("EMPTY", xpathValue(result.toString(), "//personDetails/personDetail/id/text()"));
    }

    private String addStubs(final String rawModuleCode, final String stubcode) {
        return rawModuleCode.replace(OQL_CODE_TO_STUB, stubcode);
    }
}

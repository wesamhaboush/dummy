package com.jpmorgan.dcpp.commons.xml;

public interface CommonXml {
    PrologOrXmlElement comment(String text);
    PrologOrXmlElement comment(String text, boolean newLine);
    XmlStartTag commentedStart(String name);
    XmlStartTag commentedStart(String prefix, String name);
    PrologOrXmlElement pi(String target, String data);
    PrologOrXmlElement processingInstruction(String target, String data);
    XmlStartTag start(String name);
    XmlStartTag start(String prefix, String name);
}

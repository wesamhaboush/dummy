package com.jpmorgan.hotel;

public abstract class AbstractRoom {
    private final String id;

    public AbstractRoom(final String id){
        this.id = id;
    }

    public String getId(){
        return this.id;
    }
}

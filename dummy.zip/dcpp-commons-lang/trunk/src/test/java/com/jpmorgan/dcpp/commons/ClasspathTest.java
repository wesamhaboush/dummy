package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class ClasspathTest {
  private static final String TEST_RESOURCE_PATH = "test.xml";

  @Test
  public void testResourceAsStringWillNotFailReadingWhenResourceExistsInClassPath() throws Exception {
    assertNotNull(Classpath.resourceAsString(TEST_RESOURCE_PATH));
  }
}

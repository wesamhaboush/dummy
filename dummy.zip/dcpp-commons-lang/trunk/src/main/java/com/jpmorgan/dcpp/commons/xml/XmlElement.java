package com.jpmorgan.dcpp.commons.xml;

public interface XmlElement extends CommonXml {

    XmlElement blankLine();
    XmlElement cdata(String text);
    XmlElement cdata(String text, boolean newLine);
    XmlElement child(String name);
    XmlElement child(String name, String text);
    XmlElement child(String prefix, String name, String text);
    void close();
    XmlElement end();
    XmlElement end(boolean verbose);
    XmlElement text(String text);
    XmlElement text(String text, boolean newLine);
    XmlElement unescapedText(String unescapedText);
    XmlElement unescapedText(String unescapedText, boolean newLine);
}

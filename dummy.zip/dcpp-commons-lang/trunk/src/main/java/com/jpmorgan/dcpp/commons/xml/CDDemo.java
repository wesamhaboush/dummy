package com.jpmorgan.dcpp.commons.xml;


public class CDDemo {

    public static void main(String[] args) {
        Xml wax = new Xml(Version.V1_0);

        wax.xslt("artist.xslt")
           .dtd("http://www.ociweb.com/xml/music.dtd")
           .start("artist")
           .attr("name", "Gardot, Melody")
           .defaultNamespace("http://www.ociweb.com/music",
               "http://www.ociweb.com/xml/music.xsd")
           .namespace("date", "http://www.ociweb.com/date",
               "http://www.ociweb.com/xml/date.xsd")

           .comment("This is one of my favorite CDs!")
           .start("cd").attr("year", 2007)
           .child("title", "Worrisome Heart")
           .child("date", "purchaseDate", "4/3/2008")

           .close(); // terminates all unterminated elements
    }
}
package com.jpmorgan.dcpp.commons.test;

import org.apache.commons.lang3.Validate;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class IsBetweenInclusive extends TypeSafeMatcher<Double> {

    private final double lower;
    private final double upper;

    private IsBetweenInclusive(final double lower, final double upper) {
        Validate.isTrue(lower <= upper, "lower bound is not less than or equal to upper bound");

        this.lower = lower;
        this.upper = upper;
    }

    @Override
    public boolean matchesSafely(Double number) {
        return number >= lower && number <= upper;
    }

    @Override
    public void describeTo(Description description) {
        description.appendText(String.format("is between inclusive [%f] [%f]", lower, upper));
    }

    @org.hamcrest.Factory
    public static Matcher<Double> isBetween(final double lower, final double upper) {
        return new IsBetweenInclusive(lower, upper);
    }
}
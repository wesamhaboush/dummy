package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.jpmorgan.dcpp.commons.Dates;
import com.jpmorgan.dcpp.la.model.generated.*;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Dates.toXmlGregorianCalendar;
import static com.jpmorgan.dcpp.commons.Randoms.*;
import static com.jpmorgan.dcpp.la.model.generated.TDomain.PRODUCT_CLASSIFICATION;
import static com.jpmorgan.dcpp.la.model.generated.TLegTypeEnum.FLOATING_INTEREST_RATE;
import static com.jpmorgan.dcpp.la.model.generated.TScheduleType.FX_RESET;
import static com.jpmorgan.dcpp.la.model.generated.TSourceType.PRIMARY;
import static com.jpmorgan.dcpp.la.model.generated.TValueTypeEnum.FX_CONSTANT_NOTIONAL;
import static com.jpmorgan.dcpp.la.model.generated.TValueTypeEnum.MTM_VARYING_NOTIONAL_CCY;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.referenceDataKey;
import static java.util.Arrays.asList;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.lang3.StringUtils.join;
import static org.joda.time.DateTime.now;
import static org.junit.Assert.assertNull;
import org.junit.Ignore;

public class CcsMtmMatrixRatesTest extends AbstractXqueryTest {
    private static final String CCS_MTM_MATRIX_RATES_XQY = "PaperConfirmationBusinessRules/Rates/ccs-mtm-matrix-rates.xqy";
    private static final Set<? extends Set<String>> CURRENCY_PAIRS = newHashSet(
            newHashSet("AUD", "EUR"),
            newHashSet("AUD", "JPY"),
            newHashSet("AUD", "NZD"),
            newHashSet("AUD", "USD"),
            newHashSet("CAD", "USD"),
            newHashSet("CAD", "EUR"),
            newHashSet("CHF", "DKK"),
            newHashSet("CHF", "EUR"),
            newHashSet("CHF", "SEK"),
            newHashSet("CHF", "USD"),
            newHashSet("CZK", "USD"),
            newHashSet("DKK", "EUR"),
            newHashSet("DKK", "USD"),
            newHashSet("EUR", "CZK"),
            newHashSet("EUR", "GBP"),
            newHashSet("EUR", "JPY"),
            newHashSet("EUR", "NOK"),
            newHashSet("EUR", "PLN"),
            newHashSet("EUR", "SEK"),
            newHashSet("EUR", "USD"),
            newHashSet("GBP", "NOK"),
            newHashSet("GBP", "USD"),
            newHashSet("HKD", "USD"),
            newHashSet("HUF", "EUR"),
            newHashSet("HUF", "USD"),
            newHashSet("ILS", "USD"),
            newHashSet("JPY", "CAD"),
            newHashSet("JPY", "NZD"),
            newHashSet("JPY", "USD"),
            newHashSet("JPY", "GBP"),
            newHashSet("MXN", "USD"),
            newHashSet("NOK", "USD"),
            newHashSet("NZD", "EUR"),
            newHashSet("NZD", "GBP"),
            newHashSet("NZD", "USD"),
            newHashSet("PLN", "CHF"),
            newHashSet("PLN", "USD"),
            newHashSet("RUB", "USD"),
            newHashSet("SEK", "USD"),
            newHashSet("ZAR", "USD")
            );
    private static final List<String> CURRENCIES = newArrayList(
            "AUD",
            "CAD",
            "CHF",
            "CZK",
            "DKK",
            "EUR",
            "GBP",
            "HKD",
            "HUF",
            "ILS",
            "JPY",
            "MXN",
            "NOK",
            "NZD",
            "PLN",
            "RUB",
            "SEK",
            "USD",
            "ZAR"
    );

    private static final String ISDA_NAME = "CCS_MTM_STANDARD";
    private static final List<String> PRODUCT_CLASSIFICATIONS = newArrayList("D193", "D495", "D627", "D628");

    @Test
    public void whenDcodeIsNotIncluded_NoIsdaTagsReturned() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final String currency1 = randomFrom(CURRENCIES);
        final String currency2 = currency1;
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "MXMC";
        final String fxResetOffset = randomDuration();
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        trade.getProduct().getProductClasses().clear();
        trade.getProduct().getProductClasses().add(referenceDataKey(PRODUCT_CLASSIFICATION,randomNotIn(randomStringFactory(4), PRODUCT_CLASSIFICATIONS)));
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertNull(getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenCurrenciesAreSame() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final String currency1 = randomFrom(CURRENCIES);
        final String currency2 = currency1;
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "MXMC";
        final String fxResetOffset = randomDuration();
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenNoSpecificRules() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> noSpecificRuleCurrencyPair = getNoRulesCurrencyCombination().iterator();
        final String currency1 = noSpecificRuleCurrencyPair.next();
        final String currency2 = noSpecificRuleCurrencyPair.next();
        final String fxResetOffset = randomDuration();
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "MXMC";

        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenGbpUsdRuleMatches() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("GBP","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,0);
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "GBLO";

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenGbpUsdRuleMatches_IncorrectResetOffset() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("GBP","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P3D"; //does not match specs, so should by isAdheredTo = false
        final XMLGregorianCalendar pricingTime = xmlTime(11,0);
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "GBLO";

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenGbpUsdRuleMatches_IncorrectResetTime() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("GBP","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,randomInt(1, 10)); //does not match specs, so should by isAdheredTo = false
        final String sourcePage = "REUTERS FXFIX";
        final String fxCalendar = "GBLO";

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                newArrayList(fxCalendar),
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenPlnUsdRuleMatches() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("PLN","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,15);
        final String sourcePage = "REUTERS NBPFIXA";
        final List<String> fxCalendars = newArrayList("GBLO", "USNY", "PLWA");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                fxCalendars,
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenPlnUsdRuleMatches_IncorrectSourcePage() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("PLN","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,15);
        final String sourcePage = "REUTERS NBPFIXA" + randomAlphanumeric(2);
        final List<String> fxCalendars = newArrayList("GBLO", "USNY", "PLWA");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                fxCalendars,
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

   // @Test
    @Ignore
    public void whenPlnUsdRuleMatches_NotCorrectNumberOfCurrencies() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("PLN","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,15);
        final String sourcePage = "REUTERS NBPFIXA";
        final List<String> fxCalendars = newArrayList("GBLO", "USNY", "PLWA");

        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                fxCalendars,
                fxResetOffset,
                pricingTime);
        final Trade tradeWithExtraCurrency = addCurrencyToTrade(trade, randomNotIn(randomStringFactory(3), CURRENCIES));
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(tradeWithExtraCurrency)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withName(ISDA_NAME).withKey(""));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenPlnUsdRuleMatches_NotSameNumberOfCalendars() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_MTM_MATRIX_RATES_XQY);
        final Iterator<String> specificRuleCurrencyPair = newHashSet("PLN","USD").iterator();
        final String currency1 = specificRuleCurrencyPair.next();
        final String currency2 = specificRuleCurrencyPair.next();
        final String fxResetOffset = "-P2D";
        final XMLGregorianCalendar pricingTime = xmlTime(11,15);
        final String sourcePage = "REUTERS NBPFIXA";
        final List<String> fxCalendars = newArrayList("GBLO", "USNY");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                currency1,
                currency2,
                sourcePage,
                fxCalendars,
                fxResetOffset,
                pricingTime);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    //private

    private static void prettyPrint(final String payloadXml) throws IOException, ParserConfigurationException, TransformerException {
        //uncomment to pretty print, comment to turn off
//        Xmls.print(Xmls.toW3cDoc(payloadXml), System.out);
    }

    private static Trade createTrade(
            final String currency1,
            final String currency2,
            final String sourcePage,
            final List<String> fxResetCalendars,
            final String fxOffset,
            final XMLGregorianCalendar pricingTime) throws DatatypeConfigurationException {
        return new Trade()
                .withEvent(stockEvent())
                .withTradeHeader(stockTradeHeader())
                .withProduct(new TProduct()
                             .withProductClasses(referenceDataKey(PRODUCT_CLASSIFICATION, randomFrom(PRODUCT_CLASSIFICATIONS)))
                             .withTradeLegs(new TTradeLeg()
                                             .withLegType(new TLegType().withValue(FLOATING_INTEREST_RATE))
                                             .withInterestLeg(new TInterestLeg()
                                                     .withFxLinkedNotional(new TFxLinkedNotional()
                                                                     .withContractValues(
                                                                             new TContractValue().withValueType(new TValueType().withValue(MTM_VARYING_NOTIONAL_CCY)).withCurrency(referenceDataKey(":erd.currency", currency1)),
                                                                             new TContractValue().withValueType(new TValueType().withValue(FX_CONSTANT_NOTIONAL)).withCurrency(referenceDataKey(":erd.currency", currency2))
                                                                     )
                                                                     .withFxMarkToMarketSource(new TFxFixingSource().withInformationSource(new TInformationSource()
                                                                                             .withSourceType(PRIMARY)
                                                                                             .withRateSourcePage(referenceDataKey(":isda.information-source", sourcePage))
                                                                             ).withPricingLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(":fpml.business-center"," ")))
                                                                     )
                                                                     .withEventDateSchedules(
                                                                             new TEventDateSchedule()
                                                                                     .withScheduleType(FX_RESET)
                                                                                     .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(Lists.transform(fxResetCalendars, toReferenceDataKeys()))
                                                                                     )
                                                                                     .withOffsetInterval(fxOffset)
                                                                     )
                                                                     .withFxFixingSource(new TFxFixingSource().withPricingTime(pricingTime).withPricingLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(":fpml.business-center"," "))))
                                                     ))
                             )
                );
    }

    private static Trade addCurrencyToTrade(final Trade trade, final String currency){
        trade.getProduct()
                .getTradeLegs().iterator().next()
                .getInterestLeg()
                .getFxLinkedNotional()
                .getContractValues().add(
                    new TContractValue().withValueType(new TValueType().withValue(MTM_VARYING_NOTIONAL_CCY)).withCurrency(referenceDataKey(":erd.currency", currency))
                );
        return trade;
    }

    private static Function<String, TReferenceDataKey> toReferenceDataKeys() {
        return new Function<String, TReferenceDataKey>() {
            @Override
            public TReferenceDataKey apply(final String fxCalendar) {
                return referenceDataKey(":fpml.business-center", fxCalendar);
            }
        };
    }

    private static TTradeHeader stockTradeHeader() throws DatatypeConfigurationException {
        return new TTradeHeader().withTradeDomain(randomNumeric(randomInt(2, 5))).withTradeDate(toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate())))
                .withPartyTradeData(new TPartyTradeData().withPartyViews(new TPartyView()).withBusinessIds(new TBusinessId()
                        .withIdentifierType(randomFrom(TIdentifierType.class)).withIdentifierValue(randomAlphanumeric(3))));
    }

    private static TEvent stockEvent() {
        return new TEvent().withEventTypes(referenceDataKey(":athena.instrument", randomAlphanumeric(6)));
    }

    private static String randomDuration() throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newDuration(Dates.Now.date().getTime()).toString();
    }

    private static XMLGregorianCalendar xmlTime(final int hour, final int mins) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hour, mins, 0, 0, 0);
    }


    private static Set<String> getNoRulesCurrencyCombination(){
        while (true){
            final String currency1 = randomFrom(CURRENCIES);
            final String currency2 = randomFrom(CURRENCIES);
            final Set<String> currencyCombination = newHashSet(currency1, currency2);
            if(currencyCombination.size() == 2 && !CURRENCY_PAIRS.contains(currencyCombination)){
                return currencyCombination;
            }
        }
    }
}

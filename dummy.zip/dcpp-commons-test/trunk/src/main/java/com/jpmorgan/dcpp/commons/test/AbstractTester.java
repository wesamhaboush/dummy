package com.jpmorgan.dcpp.commons.test;


import com.jpmorgan.dcpp.commons.CyclicIndex;
import com.jpmorgan.dcpp.commons.Factory;
import org.apache.commons.lang3.Validate;

import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.jpmorgan.dcpp.commons.Objects.isNull;
import static com.jpmorgan.dcpp.commons.Randoms.*;
import static org.apache.commons.lang3.ArrayUtils.toPrimitive;
import static org.mockito.Mockito.mock;

public class AbstractTester {
    public static final Factory<Void, Integer> INTEGER_FACTORY = new Factory<Void, Integer>() {
        private int previous = 0;

        @Override
        public Integer create(Void vo1d) {
            int newValue = randomInt();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Integer[]> INTEGER_ARRAY_FACTORY = new Factory<Void, Integer[]>() {
        @Override
        public Integer[] create(final Void aVoid) {
            return randomArray(Integer[].class, INTEGER_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, int[]> INT_ARRAY_FACTORY = new Factory<Void, int[]>() {
        @Override
        public int[] create(final Void aVoid) {
            return toPrimitive(INTEGER_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Short> SHORT_FACTORY = new Factory<Void, Short>() {

        private short previous = 0;

        @Override
        public Short create(Void vo1d) {
            short newValue = randomShort();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Short[]> SHORT_ARRAY_FACTORY = new Factory<Void, Short[]>() {
        @Override
        public Short[] create(final Void aVoid) {
            return randomArray(Short[].class, SHORT_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, short[]> PRIMITIVE_SHORT_ARRAY_FACTORY = new Factory<Void, short[]>() {
        @Override
        public short[] create(final Void aVoid) {
            return toPrimitive(SHORT_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Long> LONG_FACTORY = new Factory<Void, Long>() {

        private long previous = 0l;

        @Override
        public Long create(Void vo1d) {
            long newValue = randomLong();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Long[]> LONG_ARRAY_FACTORY = new Factory<Void, Long[]>() {
        @Override
        public Long[] create(final Void aVoid) {
            return randomArray(Long[].class, LONG_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, long[]> PRIMITIVE_LONG_ARRAY_FACTORY = new Factory<Void, long[]>() {
        @Override
        public long[] create(final Void aVoid) {
            return toPrimitive(LONG_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Double> DOUBLE_FACTORY = new Factory<Void, Double>() {

        private double previous = 0;

        @Override
        public Double create(Void vo1d) {
            double newValue = randomDouble();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Double[]> DOUBLE_ARRAY_FACTORY = new Factory<Void, Double[]>() {
        @Override
        public Double[] create(final Void aVoid) {
            return randomArray(Double[].class, DOUBLE_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, double[]> PRIMITIVE_DOUBLE_ARRAY_FACTORY = new Factory<Void, double[]>() {
        @Override
        public double[] create(final Void aVoid) {
            return toPrimitive(DOUBLE_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Float> FLOAT_FACTORY = new Factory<Void, Float>() {

        private float previous = 0f;

        @Override
        public Float create(Void vo1d) {
            float newValue = randomFloat();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Float[]> FLOAT_ARRAY_FACTORY = new Factory<Void, Float[]>() {
        @Override
        public Float[] create(final Void aVoid) {
            return randomArray(Float[].class, FLOAT_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, float[]> PRIMITIVE_FLOAT_ARRAY_FACTORY = new Factory<Void, float[]>() {
        @Override
        public float[] create(final Void aVoid) {
            return toPrimitive(FLOAT_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Boolean> BOOLEAN_FACTORY = new Factory<Void, Boolean>() {

        private boolean previous = false;

        @Override
        public Boolean create(Void vo1d) {
            boolean newValue = randomBoolean();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Boolean[]> BOOLEAN_ARRAY_FACTORY = new Factory<Void, Boolean[]>() {
        @Override
        public Boolean[] create(final Void aVoid) {
            return randomArray(Boolean[].class, BOOLEAN_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, boolean[]> PRIMITIVE_BOOLEAN_ARRAY_FACTORY = new Factory<Void, boolean[]>() {
        @Override
        public boolean[] create(final Void aVoid) {
            return toPrimitive(BOOLEAN_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Character> CHARACTER_FACTORY = new Factory<Void, Character>() {

        private char previous = '\0';

        @Override
        public Character create(Void vo1d) {
            char newValue = randomChar();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Character[]> CHARACTER_ARRAY_FACTORY = new Factory<Void, Character[]>() {
        @Override
        public Character[] create(final Void aVoid) {
            return randomArray(Character[].class, CHARACTER_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, char[]> PRIMITIVE_CHAR_ARRAY_FACTORY = new Factory<Void, char[]>() {
        @Override
        public char[] create(final Void aVoid) {
            return toPrimitive(CHARACTER_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, Byte> BYTE_FACTORY = new Factory<Void, Byte>() {

        private byte previous = 0;

        @Override
        public Byte create(Void vo1d) {
            byte newValue = randomByte();
            if (newValue == previous) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, Byte[]> BYTE_ARRAY_FACTORY = new Factory<Void, Byte[]>() {
        @Override
        public Byte[] create(final Void aVoid) {
            return randomArray(Byte[].class, BYTE_FACTORY, randomInt(1, 100));
        }
    };
    public static final Factory<Void, byte[]> PRIMITIVE_BYTE_ARRAY_FACTORY = new Factory<Void, byte[]>() {
        @Override
        public byte[] create(final Void aVoid) {
            return toPrimitive(BYTE_ARRAY_FACTORY.create(null));
        }
    };
    public static final Factory<Void, String> STRING_FACTORY = new Factory<Void, String>() {

        private String previous = "";

        @Override
        public String create(Void vo1d) {
            String newValue = randomAlphanumeric(randomInt(1, 100));
            if (newValue.equals(previous)) {
                newValue = create(null);
            }
            previous = newValue;
            return newValue;
        }
    };
    public static final Factory<Void, String[]> STRING_ARRAY_FACTORY = new Factory<Void, String[]>() {
        @Override
        public String[] create(final Void aVoid) {
            return randomArray(String[].class, STRING_FACTORY, randomInt(1, 100));
        }
    };
    private final Map<Class<?>, Factory<Void, ?>> factoriesForNonStandardTypes = new HashMap<Class<?>, Factory<Void, ?>>();


    static enum ClassType {
        ENUM, STANDARD, NON_FINAL, OTHER
    }

    private final static Map<Class<?>, Factory<Void, ?>> FACTORIES_FOR_STANDARD_TYPES = createStandardFactories();

    protected Factory<Void, ?> getFactoryForClass(final Class<?> type) {
        Factory<Void, ?> result;
        final ClassType classType = getClassType(type);
        switch (classType) {
            case STANDARD:
                result = FACTORIES_FOR_STANDARD_TYPES.get(type);
                break;
            case ENUM:
                result = factoryForEnum(type);
                break;
            case NON_FINAL:
                result = factoryFor(type);
                break;
            case OTHER:
            default:
                result = factoriesForNonStandardTypes.get(type);
                Validate.isTrue(!isNull(result), "otherFactories does not contain a factory for type " + type);
        }
        return result;
    }

    private ClassType getClassType(final Class<?> type) {
        if (FACTORIES_FOR_STANDARD_TYPES.containsKey(type)) {
            return ClassType.STANDARD;
        }
        if (type.isEnum()) {
            Validate.isTrue(type.getEnumConstants().length > 0, "enumConstants count is greater than 0 must be true. " +
                    "cannot use this field for equality or hashcoding, since the enum has no values, only null can be assigned to it. Exclude it please");
            return ClassType.ENUM;
        }
        if (!Modifier.isFinal(type.getModifiers())) {
            return ClassType.NON_FINAL;
        }
        return ClassType.OTHER;
    }

    private static Map<Class<?>, Factory<Void, ?>> createStandardFactories() {
        final Map<Class<?>, Factory<Void, ?>> factories = new HashMap<Class<?>, Factory<Void, ?>>();

        //Integer/int
        factories.put(int.class, INTEGER_FACTORY);
        factories.put(Integer.class, factories.get(int.class));
        factories.put(int[].class, INT_ARRAY_FACTORY);
        factories.put(Integer[].class, INTEGER_ARRAY_FACTORY);

        factories.put(short.class, SHORT_FACTORY);
        factories.put(Short.class, factories.get(short.class));
        factories.put(short[].class, PRIMITIVE_SHORT_ARRAY_FACTORY);
        factories.put(Short[].class, SHORT_ARRAY_FACTORY);

        factories.put(long.class, LONG_FACTORY);
        factories.put(Long.class, factories.get(long.class));
        factories.put(long[].class, PRIMITIVE_LONG_ARRAY_FACTORY);
        factories.put(Long[].class, LONG_ARRAY_FACTORY);

        factories.put(double.class, DOUBLE_FACTORY);
        factories.put(Double.class, factories.get(double.class));
        factories.put(double[].class, PRIMITIVE_DOUBLE_ARRAY_FACTORY);
        factories.put(Double[].class, DOUBLE_ARRAY_FACTORY);

        factories.put(float.class, FLOAT_FACTORY);
        factories.put(Float.class, factories.get(float.class));
        factories.put(float[].class, PRIMITIVE_FLOAT_ARRAY_FACTORY);
        factories.put(Float[].class, FLOAT_ARRAY_FACTORY);

        factories.put(boolean.class, BOOLEAN_FACTORY);
        factories.put(Boolean.class, factories.get(boolean.class));
        factories.put(boolean[].class, PRIMITIVE_BOOLEAN_ARRAY_FACTORY);
        factories.put(Boolean[].class, BOOLEAN_ARRAY_FACTORY);

        factories.put(char.class, CHARACTER_FACTORY);
        factories.put(Character.class, factories.get(char.class));
        factories.put(char[].class, PRIMITIVE_CHAR_ARRAY_FACTORY);
        factories.put(Character[].class, CHARACTER_ARRAY_FACTORY);

        factories.put(byte.class, BYTE_FACTORY);
        factories.put(Byte.class, factories.get(byte.class));
        factories.put(byte[].class, PRIMITIVE_BYTE_ARRAY_FACTORY);
        factories.put(Byte[].class, BYTE_ARRAY_FACTORY);

        factories.put(String.class, STRING_FACTORY);
        factories.put(String[].class, STRING_ARRAY_FACTORY);

        return factories;
    }

    private static Factory<Void, ?> factoryFor(final Class<?> sClass) {
        return new Factory<Void, Object>() {
            @Override
            public Object create(Void vo1d) {
                return mock(sClass);
            }
        };
    }

    private static Factory<Void, ?> factoryForEnum(final Class<?> sClass) {
        return new Factory<Void, Object>() {

            private final Object[] ss = sClass.getEnumConstants();
            private final CyclicIndex index = new CyclicIndex(ss.length);

            @Override
            public Object create(Void vo1d) {
                return ss[index.next()];
            }
        };
    }

    protected void addFactories(Map<Class<?>, Factory<Void, ?>> extraFactories) {
        this.factoriesForNonStandardTypes.putAll(extraFactories);
    }

    protected Map<Class<?>, Factory<Void, ?>> getFactoriesForStandardTypes() {
        return Collections.unmodifiableMap(FACTORIES_FOR_STANDARD_TYPES);
    }

    protected Map<Class<?>, Factory<Void, ?>> getFactoriesForNonStandardTypes() {
        return Collections.unmodifiableMap(factoriesForNonStandardTypes);
    }
}

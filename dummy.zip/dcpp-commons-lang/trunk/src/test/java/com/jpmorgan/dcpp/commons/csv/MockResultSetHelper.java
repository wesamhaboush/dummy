package com.jpmorgan.dcpp.commons.csv;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;


public class MockResultSetHelper implements ResultSetHelper {

    private String[] columnNames;
    private String[] columnValues;

    public MockResultSetHelper(String[] names, String[] values) {
        columnNames = names;
        columnValues = values;
    }

    public String[] getColumnNames(ResultSet rs) throws SQLException {
        return columnNames;
    }

    public String[] getColumnValues(ResultSet rs) throws SQLException, IOException {
        return columnValues;
    }
}

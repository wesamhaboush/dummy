package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.junit.Test;

import java.io.IOException;
import java.util.Iterator;

import static com.jpmorgan.dcpp.commons.Randoms.randomBoolean;
import static com.jpmorgan.dcpp.la.model.generated.TBooleanConditionTypeEnum.NON_STD_CONFIRM;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.junit.Assert.assertTrue;

public class EquitiesEditRulesTest extends AbstractXqueryTest {

    private static final String EDIT_RULES_XQY = "PaperConfirmationBusinessRules/Equity/edit_equities.xqy";
    private static final String CODE_TO_STUB = "editReason:addEditReason($editReason)";
    private static final String STUB_CODE = "$editReason";

    @Test
    public void testRmsConfirmationComments() throws IOException, SaxonApiException {
        //given
        final String editReason = "RMS Confirmation Comments";
        final String owningBusiness = "EDG";
        final String xqueryModule = loadModuleAsString(EDIT_RULES_XQY).replace(CODE_TO_STUB, STUB_CODE);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withConfirmationProcessing(randomAlphanumeric(30), randomBoolean() , NON_STD_CONFIRM, true )
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }


    private Predicate<? super String> hasReason(final String targetReason) {
        return new Predicate<String>() {
            @Override
            public boolean apply(final String currentReason) {
                return targetReason.equals(currentReason);
            }
        };
    }

    private Function<XdmItem, String> convertToString() {
        return new Function<XdmItem, String>() {
            @Override
            public String apply(final XdmItem xdmItem) {
                return xdmItem.toString();
            }
        };
    }


}

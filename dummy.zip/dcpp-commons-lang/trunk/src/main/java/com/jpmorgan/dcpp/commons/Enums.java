package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.Validate;

public class Enums {
    /**
     * @param s string representation (name) of the member (case insensitive)
     * @param clazz enum class
     * @param <T>
     * @return true if found, false otherwise
     */
    public static <T extends Enum<T>> boolean isInEnumIgnoreCase(final String s, final Class<T> clazz){
        Validate.notNull(clazz, "clazz is null");
        Validate.notNull(s, "enum name is null");
        boolean result = false;
        for(final T t : clazz.getEnumConstants()){
            if( t.name().equalsIgnoreCase(s) ){
                result = true;
                break;
            }
        }
        return result;
    }

    /**
     * @param s string name of the member (case insensitive)
     * @param clazz enum class to look in
     * @param <T>
     * @return Either a member of the enum, or a null if it doesn't match any member
     */
    public static <T extends Enum<T>> T stringToEnumIgnoreCase(final String s, final Class<T> clazz){
        Validate.notNull(clazz, "clazz is null");
        Validate.notNull(s, "enum string value is null");

        T result = null;
        final String sTrimmed = s.trim();
        for(final T t : clazz.getEnumConstants()){
            if( t.name().equalsIgnoreCase(sTrimmed) ){
                result = t;
                break;
            }
        }
        return result;
    }
}

package com.jpmorgan.dcpp.commons;

import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;
import org.joda.time.DateTime;
import org.junit.Test;
import org.mockito.internal.util.collections.Sets;

import java.util.*;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.transform;
import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Integers.range;
import static com.jpmorgan.dcpp.commons.Randoms.randomBoolean;
import static com.jpmorgan.dcpp.commons.Randoms.randomFrom;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

public class RandomsTest {
    @Test
    public void testRandomFromEnum() {
        //then
        //if five consecutive elements are the same, I suspect it is not random!
        assertTrue(
                newHashSet(
                        randomFrom(TestEnum.class),
                        randomFrom(TestEnum.class),
                        randomFrom(TestEnum.class),
                        randomFrom(TestEnum.class),
                        randomFrom(TestEnum.class)
                ).size() > 1);
    }

    @Test
    public void testRandomFromArray() {
        //given
        final Object[] obs = {new Object(), new Object(), new Object()};

        //then
        //if five consecutive elements are the same, I suspect it is not random!
        assertTrue(Iterables.any(newArrayList(
                newHashSet(randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs) ).size() > 1,
                newHashSet(randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs) ).size() > 1,
                newHashSet(randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs), randomFrom(obs) ).size() > 1),
                Predicates.equalTo(Boolean.TRUE)));
    }

    @Test
    public void testRandomFromBoolean() {
        //given

        //then
        //if 10 consecutive elements are the same, I suspect it is not random!
        final HashSet<Boolean> booleans = newHashSet(
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean(),
                randomBoolean()
        );
        assertTrue("random number was not very random ? here is the generated set: " + booleans, booleans.size() > 1);
    }

    @Test
    public void testRandomFloatBetween() {
        final float value = Randoms.randomFloat(-1.0f, 20.0f);
        assertTrue(value < 20.0f && value > -1.0f);

        //chances of a randomizer producing the same exact values 4 consecutive times should be infinitisimal
        assertFalse(Equals.allEqual(
                Randoms.randomFloat(-1.0f, 20.0f),
                Randoms.randomFloat(-1.0f, 20.0f),
                Randoms.randomFloat(-1.0f, 20.0f),
                Randoms.randomFloat(-1.0f, 20.0f)));
    }

    @Test
    public void testRandomDoubleBetween() {
        final double value = Randoms.randomDouble(-1.0, 20.0);
        assertTrue(value < 20.0 && value > -1.0);

        //chances of a randomizer producing the same exact values 4 consecutive times should be infinitisimal
        assertFalse(Equals.allEqual(
                Randoms.randomDouble(-1.0f, 20.0f),
                Randoms.randomDouble(-1.0f, 20.0f),
                Randoms.randomDouble(-1.0f, 20.0f),
                Randoms.randomDouble(-1.0f, 20.0f)));
    }

    @Test
    public void testRandomPositiveInt() {
        assertTrue(Randoms.randomPositiveInt() > 0);
        assertFalse(Equals.allEqual(
                Randoms.randomPositiveInt(),
                Randoms.randomPositiveInt(),
                Randoms.randomPositiveInt(),
                Randoms.randomPositiveInt()));
    }

    @Test
    public void testRandomInt() {
        assertFalse(Equals.allEqual(
                Randoms.randomInt(),
                Randoms.randomInt(),
                Randoms.randomInt(),
                Randoms.randomInt()));
    }

    @Test
    public void testRandomLong() {
        assertFalse(Equals.allEqual(
                Randoms.randomLong(),
                Randoms.randomLong(),
                Randoms.randomLong(),
                Randoms.randomLong()));
    }

    @Test
    public void testRandomDouble() {
        assertFalse(Equals.allEqual(
                Randoms.randomDouble(),
                Randoms.randomDouble(),
                Randoms.randomDouble(),
                Randoms.randomDouble()));
    }

    @Test
    public void testRandomShort() {
        assertFalse(Equals.allEqual(
                Randoms.randomShort(),
                Randoms.randomShort(),
                Randoms.randomShort(),
                Randoms.randomShort()));
    }

    @Test
    public void testRandomChar() {
        assertFalse(Equals.allEqual(
                Randoms.randomChar(),
                Randoms.randomChar(),
                Randoms.randomChar(),
                Randoms.randomChar()));
    }

    @Test
    public void testRandomByte() {
        assertFalse(Equals.allEqual(
                Randoms.randomByte(),
                Randoms.randomByte(),
                Randoms.randomByte(),
                Randoms.randomByte()));
    }

    @Test
    public void testRandomIntBetween() {
        final int value = Randoms.randomInt(-500, 1500);
        assertTrue(value < 1500 && value > -500);

        //chances of a randomizer producing the same exact values 4 consecutive times should be infinitisimal
        assertFalse(Equals.allEqual(
                Randoms.randomInt(-500, 1500),
                Randoms.randomInt(-500, 1500),
                Randoms.randomInt(-500, 1500),
                Randoms.randomInt(-500, 1500)));
    }

    /**
     * after five seconds of trying on the random generator to get different
     * values, I am doubtful this is random
     */
    @Test(timeout = 5000)
    public void testRandomBoolean() {
        //chances of a randomizer producing the same exact value many many consecutive times should be infinitisimal
        final Set<Boolean> booleans = newHashSet();
        final Runnable code = new Runnable() {

            @Override
            public void run() {
                while (booleans.size() <= 1) {
                    booleans.add(Randoms.randomBoolean());
                }
            }
        };

        final String message = String.format("code ran for with result [%s], " +
                        "something is not random here", booleans.toString());
        assertFalse(message, booleans.size() == 1);
    }

    @Test
    public void testRandomFrom() {
        //one item list
        final int[] oneItemArray = new int[]{876};
        assertEquals(876, Randoms.randomFrom(oneItemArray));
        assertEquals(876, Randoms.randomFrom(oneItemArray));
        assertEquals(876, Randoms.randomFrom(oneItemArray));

        //multi item list
        final int[] fourItemArray = new int[]{876, 877, 878, 879};
        final Collection<Integer> allItems = newArrayList(876, 877, 878, 879);
        final Collection<Integer> foundItems = newArrayList();

        int count = 0;
        while (!allItems.equals(foundItems) && count < 1000) {
            final int nextValue = Randoms.randomFrom(fourItemArray);
            assertTrue(allItems.contains(nextValue));
            foundItems.add(nextValue);
            count += 1;
        }
    }

    @Test(expected = RuntimeException.class)
    public void testRandomFromExceptionCaseWithNull() {
        int[] nullIntsArray = null;

        //exception cases
        Randoms.randomFrom(nullIntsArray);
    }

    @Test(expected = RuntimeException.class)
    public void testRandomFromExceptionCaseWithEmptyArrayF() {
        //exception cases
        Randoms.randomFrom(new int[]{});
    }

    @Test
    public void testRandomAlphanum() {
        final Random r = new Random(System.currentTimeMillis());
        final int length = r.nextInt(20) + 1;
        //chances of a randomizer producing the same exact values 4 consecutive times should be infinitisimal
        assertFalse(Equals.allEqual(
                Randoms.randomAlphanumeric(length),
                Randoms.randomAlphanumeric(length),
                Randoms.randomAlphanumeric(length),
                Randoms.randomAlphanumeric(length)));
    }


    @Test
    public void testRandomFloat() {
        assertFalse(Equals.allEqual(
                Randoms.randomFloat(),
                Randoms.randomFloat(),
                Randoms.randomFloat(),
                Randoms.randomFloat()));
    }

    @Test
    public void testRandomCombinationOf() {
        final Factory<Void, ? extends Collection<Dummy>> factory = new Factory<Void, ArrayList<Dummy>>() {
            @Override
            public ArrayList<Dummy> create(final Void o) {
                return new ArrayList<Dummy>();
            }
        };
        assertFalse(Equals.allEqual(
                Randoms.randomFrom(Dummy.values()),
                Randoms.randomFrom(factory, Dummy.values()),
                Randoms.randomFrom(factory, Dummy.values()),
                Randoms.randomFrom(factory, Dummy.values())));
    }

    @Test
    public void testRandomStringWithTwoInts() {
        assertFalse(Equals.allEqual(
                Randoms.randomString(1, 10),
                Randoms.randomString(1, 10),
                Randoms.randomString(1, 10),
                Randoms.randomString(1, 10)));

        assertFalse(Equals.allEqual(
                Randoms.randomString(1, 10).length(),
                Randoms.randomString(1, 10).length(),
                Randoms.randomString(1, 10).length(),
                Randoms.randomString(1, 10).length()));
    }

    @Test
    public void testRandomStringWithOneInt() {
        assertFalse(Equals.allEqual(
                Randoms.randomString(10),
                Randoms.randomString(10),
                Randoms.randomString(10),
                Randoms.randomString(10)));
    }

    @Test
    public void testRandomFromWithCollections(){
        //given
        final Collection<String> coll = newArrayList("a","b","c");

        //when
        final String result = Randoms.randomFrom(coll);

        //then
        assertNotNull(result);
        assertTrue(coll.contains(result));
        while(true){
            if(Randoms.randomFrom(coll).equals(Randoms.randomFrom(coll))){
                break;
            }
        }
    }


    @Test
    public void testRandomFromWithArrays(){
        //given
        final String[] array = {"a","b","c"};

        //when
        final String result = Randoms.randomFrom(array);

        //then
        assertNotNull(result);
        assertTrue(Arrays.asList(array).contains(result));
        while(true){
            if(!Randoms.randomFrom(array).equals(Randoms.randomFrom(array))){
                break;
            }
        }
    }

    @Test
    public void testRandomDateBetween(){
        //given
        final Date first = new Date();
        //50 days ahead
        final Date second = new Date(first.getTime() + (50 * 24 * 60 * 60 * 1000));

        //when
        final Date randomDate = Randoms.randomDateBetween(first, second);

        //then
        assertTrue(String.format("date[%s] is not between lower[%s] and upper[%s]", randomDate, first, second),
                randomDate.getTime() >= first.getTime() && randomDate.getTime() <= second.getTime());
    }

    @Test
    public void testRandomDateBetween_DateTime(){
        //given
        final DateTime first = new DateTime();
        //50 days ahead
        final DateTime second = new DateTime(first.plusDays(50));

        //when
        final DateTime randomDate = Randoms.randomDateBetween(first, second);

        //then
        assertTrue(String.format("dateTime[%s] is not between lower[%s] and upper[%s]", randomDate, first, second),
                randomDate.toDate().getTime() >= first.toDate().getTime() && randomDate.toDate().getTime() <= second.toDate().getTime());
    }

    @Test
    public void testRandomDateBetween_String(){
        //given
        final DateTime first = new DateTime();
        //50 days ahead
        final DateTime second = new DateTime(first.plusDays(50));

        //when
        final String randomDate = Randoms.randomDateBetween(Dates.printDateTime(first), Dates.printDateTime(second));

        //then
        assertTrue(String.format("dateTime[%s] is not between lower[%s] and upper[%s]", randomDate, first, second),
                Dates.parseDateTime(randomDate).toDate().getTime() >= first.toDate().getTime() && Dates.parseDateTime(randomDate).toDate().getTime() <= second.toDate().getTime());
    }

    @Test
    public void testRandomNotInForStringsGoodFactory(){
        //given
        final Factory<Void, String> stringFactory = new Factory<Void, String>() {
            private final String[] values = {"1", "2", "3", "4", "5"};
            private final CyclicIndex cyclicIndex = new CyclicIndex(values.length);
            @Override
            public String create(final Void aVoid) {
                return values[cyclicIndex.next()];
            }
        };

        final Collection<String> unwantedValues = newArrayList("1", "2", "3", "4");

        //when
        final String wantedValue = Randoms.randomNotIn(stringFactory, unwantedValues);

        //then
        assertEquals("5", wantedValue);
    }

    @Test
    public void testRandomNotInForIntegersGoodFactory(){
        //given
        final Factory<Void, Integer> stringFactory = new Factory<Void, Integer>() {
            private final Integer[] values = {1, 2, 3, 4, 5};
            private final CyclicIndex cyclicIndex = new CyclicIndex(values.length);
            @Override
            public Integer create(final Void aVoid) {
                return values[cyclicIndex.next()];
            }
        };

        final Collection<Integer> unwantedValues = newArrayList(1, 2, 3, 4);

        //when
        final int wantedValue = Randoms.randomNotIn(stringFactory, unwantedValues);

        //then
        assertEquals(5, wantedValue);
    }

    @Test
    public void testRandomNotInForIntegersGoodFactoryFirstValueReturned(){
        //given
        final Factory<Void, Integer> stringFactory = new Factory<Void, Integer>() {
            private final Integer[] values = {1, 2, 3, 4, 5};
            private final CyclicIndex cyclicIndex = new CyclicIndex(values.length);
            @Override
            public Integer create(final Void aVoid) {
                return values[cyclicIndex.next()];
            }
        };

        final Collection<Integer> unwantedValues = newArrayList(2, 3, 4, 5);

        //when
        final int wantedValue = Randoms.randomNotIn(stringFactory, unwantedValues);

        //then
        assertEquals(1, wantedValue);
    }

    @Test
    public void testRandomDateFactory(){
        for(int i : range(0, 100)) {
            assertNotNull(Randoms.RANDOM_DATETIME_FACTORY.create(null));
        }
    }

    @Test
    public void testRandomCaseDoesRandomizeCases(){
        //given
        final TestCasingEnum enumMember = randomFrom(TestCasingEnum.class);

        //when
        final Set<String> randomCaseSet = Sets.newSet(
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name()),
                Randoms.randomCase(enumMember.name())
        );
        final Set<String> toLowerCase = toLowerCase(randomCaseSet);

        //then
        assertTrue(randomCaseSet.toString(), randomCaseSet.size() > 1);
        assertTrue(randomCaseSet.toString(), toLowerCase.size() == 1);
        assertTrue(randomCaseSet.toString(), toLowerCase.contains(enumMember.name().toLowerCase()));
    }

    @Test
    public void testRandomXml10String(){
        assertEquals("", Randoms.randomXml10String(0));

        assertFalse(Randoms.randomXml10String(100).matches(Randoms.XML_1_0PATTERN));
        assertFalse(Randoms.randomXml10String(0, 100).matches(Randoms.XML_1_0PATTERN));
    }

    //utils

    private Set<String> toLowerCase(final Set<String> set) {
        return newHashSet(transform(newArrayList(set), toLowerCase()));
    }

    private Function<String, String> toLowerCase() {
        return new Function<String, String>() {
            @Override
            public String apply(final String input) {
                return input.toLowerCase();
            }
        };
    }

    //test utils

    private static enum Dummy {

        A, B, C
    }

    //test
    private enum TestEnum {
        A, B, C;
    }

    private enum TestCasingEnum {
        JESUS, MOSES, BUDDHA;
    }
}

import net.sf.saxon.s9api.*;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;

public class XqueryTest {

    @Test
    public void testEvaluate() throws SaxonApiException, IOException {
        Processor proc = new Processor(true);
        XQueryCompiler comp = proc.newXQueryCompiler();
        XQueryExecutable exp = comp.compile(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("test4.xqy")));
        XQueryEvaluator qe = exp.load();
        qe.setExternalVariable(new QName("n"), new XdmAtomicValue(10));
        XdmValue result = qe.evaluate();
        for(Object o : result){
            System.out.println(o);
        }
//        int total = 0;
//        for (XdmItem item : result) {
//            total += ((XdmAtomicValue) item).getLongValue();
//        }
//        System.out.println("Total: " + total);
    }

    @Test
    public void testCanRunEvaluationXquery() throws SaxonApiException, IOException {
        Processor proc = new Processor(true);
        XQueryCompiler comp = proc.newXQueryCompiler();
        XQueryExecutable exp = comp.compile(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("test.xqy")));
        XQueryEvaluator qe = exp.load();
        qe.setExternalVariable(new QName("n"), new XdmAtomicValue(10));
        XdmValue result = qe.evaluate();
        int total = 0;
        for (XdmItem item : result) {
            total += ((XdmAtomicValue) item).getLongValue();
        }
        System.out.println("Total: " + total);
    }

    @Test
    public void testCanRunEvaluationXquery2() throws SaxonApiException, IOException {
        Processor proc = new Processor(false);
        XQueryCompiler comp = proc.newXQueryCompiler();
        XQueryExecutable exp = comp.compile(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("test2.xqy")));
        XQueryEvaluator qe = exp.load();
        final String payload =
//                        "<payload>\n" +
                        "  <confirmationDocument>\n" +
                        "    <transmitPayloadInfo>\n" +
                        "      <tradeVersion>1</tradeVersion>\n" +
                        "      <tradeDate>1</tradeDate>\n" +
                        "    </transmitPayloadInfo>\n" +
                        "  </confirmationDocument>\n";
//                        "</payload> \n";
        new ItemTypeFactory(proc).getExternalObject(payload);
        XdmNode source = proc.newDocumentBuilder().build(new StreamSource(IOUtils.toInputStream(payload)));
        qe.setExternalVariable(new QName("payload"), source);
        qe.setExternalVariable(new QName("documentId"), new XdmAtomicValue("12345"));
        XdmValue result = qe.evaluate();
        System.out.println("Total: " + result.iterator().next());
    }

    @Test
    public void testStaticAnaylysis() throws SaxonApiException, IOException {
        Processor proc = new Processor(false);
        XQueryCompiler comp = proc.newXQueryCompiler();
        XQueryExecutable exp = comp.compile(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("test3.xqy")));
        XQueryEvaluator qe = exp.load();

    }
}

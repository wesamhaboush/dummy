package com.jpmorgan.ibtcp.dcpp.la.signature;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.Classes;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder;
import com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;


public class RatesSignatureTest {

    private static String xqueryModule = null;

    static {
        try {

            xqueryModule = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Rates/signature_rates.xqy")).replace("declare namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\";",
                    "import module namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\" at 'src/test/resources/xquery/mockLookup.xqy';");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testRatesDraftedCommodityTradesSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "12345";
        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testRatesDraftedCommodityTradesSignatoryNotApplied() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942425";
        String ownerSPN = "12345";
        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        //Expect Default Rule Applied
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testHardCopyDeliveryMediumSignatoryWithNoDetailsFound() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "EMPTY";
        String arrangerCountry = "";
        String ownerCity = "INDIA";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "HARDCOPY";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, null, null, null),
                actual.getPersonDetails());

    }

    @Test
    public void testNotHardCopyDeliveryMediumSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "INDIA";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "SOFTCOPY";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testHardCopyDeliveryMediumBangkokSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "BANGKOK";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "SOFTCOPY";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertFalse(PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC").equals(actual.getPersonDetails()));
    }


    @Test
    public void testThailandSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "U724262";
        String arrangerCountry = "";
        String ownerCity = "BANGKOK";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "HARDCOPY";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testMexicoSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "F047671";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0208";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testNonMexicoSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0209";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        //Assert default rule applied
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }



    @Test
    public void testChileSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "U306706";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0788";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testTokyoJpmcbSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "U459142";
        String arrangerCountry = "";
        String ownerCity = "TOKYO";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0109";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }


    @Test
    public void testTokyoInvalideNonApplicableLegalEntityJpmcbSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "TOKYO";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0110";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        //assert Tokyo but non applicable Legal entity defaults to default signatory
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }


    @Test
    public void testTokyoJpmslSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "U362152";
        String arrangerCountry = "";
        String ownerCity = "TOKYO";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0725";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }


    @Test
    public void testClientPreferenceAgreementSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "U362152";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "5330416";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testArrangerCountryHongKongProcessedSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "V113493";
        String arrangerCountry = "PHILIPPINES";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }


    @Test
    public void testArrangerCountryNonHongKongProcessedSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "PAKISTAN";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);

        //default to default signatory
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testLondonSpnSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "V113493";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "A102765814";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }


    @Test
    public void testNonLondonSpnSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "12345";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "B102765814";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }



    @Test
    public void testSaraScrivenerSignatory() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "8390037";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "12345";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }

    @Test
    public void testDefaulRuleMatch() throws SaxonApiException, IOException, XPathExpressionException {
        final String id = "E082831";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "";
        String ownerSPN = "123456";

        String counterpartySPN = "12345";
        String arrangerDeskCaid = "12345";
        String ownerLegalEntity = "";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium,counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();

        //then
        final DsThunderheadInput actual = XqueryUtil.getDsThunderheadInputFromResult(result);
        assertEquals(
                PayloadBuilder.personalDetails("SIGNATORY", id, "ABC", "ABC", "ABC"),
                actual.getPersonDetails());

    }
}

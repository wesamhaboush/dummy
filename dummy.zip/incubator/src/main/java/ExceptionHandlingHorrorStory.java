import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.slf4j.Logger;

public class ExceptionHandlingHorrorStory {
    private final static transient Logger LOGGER = Slf4jLoggerFactory.create();

    private void parenting() throws Exception {
        try{
            parentingLogic();
        } catch (Exception up){
            throw up;
        }
    }

    private void accounting() throws Exception {
        try{
            accountingLogic();
        }catch (AccountingException e){
            throw away(e);
        }
    }

    private void sporting() {
        try {
            System.out.println("I am going to play sport in my leisure time");
            System.out.println("some times, I am not going to be free to do so, but that's ok, i'll make it up later.");
        } catch (NotFreeToSportTodayException stones){
          throw stones;
        }
    }

    private void logging(){
        final String businessId = "12345";
        try{
            process(businessId);
        }catch(LoggingException e){
            LOGGER.info("error occurred");
            throw e;
        }
    }

    private Feels nightlife(){
        drinkABit();
        drinkMore();
        dressUp();
        try{
            club();
            clubHarder();
            getLost();
        }catch(Exception e){
            handleDrinkingIncompetenceIssues(e);
            return Feels.Horrendous;
        }
        findAWayToGetHome();
        try{
            doWorkNextDay();
        } catch (HangOverException theTowel){
            throw theTowel;
        }
        return Feels.Good;
    }

    private void catchAllPlease(){
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(final Thread t, final Throwable e) {
                if(e instanceof UnTestedCodeException) {
                    phoneSimonCooperImmediately();
                }
            }

            private void phoneSimonCooperImmediately() {}
        });
    }

    private String anatomy() throws UnbelievableException {
        try{
            if(System.currentTimeMillis() < 0){
                throw new UnbelievableException("time machine has been invented!!");
            }
            return "good";
        }catch (UnbelievableException ex){
            if(true) {
                throw ex;
            }
        }
        return null;
    }

    //utils

    private void doWorkNextDay() {
        //are you joking?
    }

    private void findAWayToGetHome() {
        //or somewhere else
    }

    private void handleDrinkingIncompetenceIssues(final Exception e) {
        //badly handling such issues
    }

    private void clubHarder() {}

    private void club() {}

    private void dressUp() {}

    private void drinkMore() {}

    private void drinkABit() {}

    private Exception away(final Exception e) throws Exception {
        throw new Exception(e.getMessage());
    }


    public Object getLost() {return null;}

    private static class ParentingException extends Exception{

        public ParentingException(final String s) {
            super(s);
        }

    }

    private static class AccountingException extends Exception{

        public AccountingException(final String s) {
            super(s);
        }

    }
    private static class NotFreeToSportTodayException extends RuntimeException{

        public NotFreeToSportTodayException(final String s) {
            super(s);
        }

    }
    private void parentingLogic() throws ParentingException {
        throw new ParentingException("quite often");
    }

    private void accountingLogic() throws AccountingException {
        throw new AccountingException("I can always do with more money");
    }



    private enum Feels {Good, Bad, Ugly, Horrendous, Ecstatic;}
    private class HangOverException extends RuntimeException{}

    private class LoggingException extends RuntimeException{

    }

    private void process(final String businessId) {}

    private class UnTestedCodeException  extends RuntimeException{
    }

    private class UnbelievableException extends Throwable {
        public UnbelievableException(final String s) {
        }
    }
}

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.apache.commons.collections4.Closure;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.collect.Maps.newHashMap;
import static java.lang.System.out;
import static org.apache.commons.collections4.CollectionUtils.forAllDo;
import static org.apache.commons.lang.ArrayUtils.contains;
import static org.apache.commons.lang3.ArrayUtils.toArray;
import static org.apache.commons.lang3.ObjectUtils.defaultIfNull;
import static org.apache.commons.lang3.StringUtils.defaultString;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.join;

public class Uifology {
    private final static transient Logger LOGGER = Slf4jLoggerFactory.create();
    private final static char SEPARATOR = ' ';
    private static final String NAME_ERROR_MSG_TEMPLATE = "blank first names are not allowedb data set first[%s] middle[%s] last[%s]";
    private static final Map<Boolean, Closure<String>> PROCESSERS = ImmutableMap.<Boolean, Closure<String>>builder()
            .put(Boolean.TRUE, nullNameProcessor())
            .put(Boolean.FALSE, goodNameProcessor())
            .build();

    public String prepareName(String firstname, String middlename, String lastname){
        checkArgument(isNotBlank(firstname), NAME_ERROR_MSG_TEMPLATE, firstname, middlename, lastname);
        return join(firstname, denull(middlename), denull(lastname), SEPARATOR); //why join, and NOT plus?
    }

    private String denull(final String potentiallyNull) {
        return defaultString(potentiallyNull, "");
    }

    public Collection<String> garbageCollection(Collection<String> someNames) {
        LOGGER.debug("I have received {} names to process. ", denull(someNames).size());
        for (String name : denull(someNames)) {
            printStatistics(name);
        }
        return someNames;
    }

    public Collection<String> garbageCollectionAdvanced(Collection<String> someNames) {
        forAllDo(someNames, printStatistics());
        return someNames;
    }

    private Closure<String> printStatistics() {
        return new Closure<String>() {
            @Override
            public void execute(final String s) {
                PROCESSERS.get(s == null).execute(s);
            }
        };
    }

    private Collection<String> denull(final Collection<String> someNames) {
        return defaultIfNull(someNames, emptyCollection());
    }

    private List<String> emptyCollection() {
        return Collections.<String>emptyList();
    }

    private static void printStatistics(final String name) {
        out.printf("I got name: %s ", name);
        out.printf("let's see it capitalized: %s ", name.toUpperCase());
        out.printf("let's see it small letter: %s ", name.toLowerCase());
        out.printf("let's see how long it is: %d ", name.length());
        out.printf("is it too short: %b ", name.length() < 2);
        out.printf("is it too long: %b ", name.length() < 20);
        out.printf("is it famous: %b ", contains(toArray("jesus", "obama", "rihanna"), name));
    }

    private static Closure<String> goodNameProcessor() {
        return new Closure<String>() {
            @Override
            public void execute(final String input) {
                printStatistics(input);
            }
        };
    }

    private static Closure<String> nullNameProcessor() {
        return new Closure<String>() {
            @Override
            public void execute(final String input) {
                out.printf("null name found, not processing that.");
            }
        };
    }
}

package com.jpmorgan.dcpp.commons.caching.impl;

import com.google.common.cache.Cache;
import com.jpmorgan.dcpp.commons.caching.CacheService;
import net.sf.ehcache.CacheManager;
import org.junit.Test;

import static org.junit.Assert.*;

public class CacheServiceImplTest {
    @Test
    public void testPutGetRemoveAndClearVanilla() throws Exception {
        //given
        final String key1 = "a";
        final String key2 = "c";
        final String key3 = "k";
        final String value1 = "b";
        final String value2 = "d";

        //when
        final CacheService<String, String> cache = new CacheServiceImpl<String, String>();
        cache.put(key1, value1);
        cache.put(key2, value2);

        //then
        assertEquals(value1, cache.get(key1));
        assertEquals(value2, cache.get(key2));
        assertEquals(null, cache.get(key3));

        cache.remove(key1);

        assertEquals(null, cache.get(key1));
        assertEquals(value2, cache.get(key2));
        assertEquals(null, cache.get(key3));

        cache.clear();

        assertEquals(null, cache.get(key1));
        assertEquals(null, cache.get(key2));
        assertEquals(null, cache.get(key3));
    }

    @Test
    public void testNullKeyForPutAndGet() throws Exception {
        //given
        final String key = "a";
        final String value = "b";
        final String nullKey = null;
        final String nullValue = null;

        //when
        final CacheService<String, String> cache = new CacheServiceImpl<String, String>();
        cache.put(key, nullValue);
        cache.put(nullKey, value);

        //then
        assertEquals(null, cache.get(key));
        assertEquals(null, cache.get(nullKey));
    }

    @Test
    public void testRemoveNonExistantElementIsOk() throws Exception {
        new CacheServiceImpl<Object, Object>().remove("fictitiousElement");
    }

    @Test
    public void testCanHaveMultipleCaches() throws Exception {
        //given
        final String cacheName1 = "L1Cache";
        final String cacheName2 = "L2Cache";

        //when
        final CacheServiceImpl cache1 = new CacheServiceImpl(cacheName1);
        final CacheServiceImpl cache2 = new CacheServiceImpl(cacheName2);

        //then
        assertNotNull(CacheManager.create().getCache(cacheName1));
        assertNotNull(CacheManager.create().getCache(cacheName2));
    }

    @Test
    public void testCanHaveMultipleCachesInstantiatedMultipleTimes() throws Exception {
        //given
        final String cacheName1 = "L1Cache";
        final String cacheName2 = "L1Cache";

        //when
        final CacheServiceImpl cache1 = new CacheServiceImpl(cacheName1);
        final CacheServiceImpl cache2 = new CacheServiceImpl(cacheName2);

        //then

        final CacheManager cacheManager1 = CacheManager.create();
        final net.sf.ehcache.Cache gotCache1 = cacheManager1.getCache(cacheName1);
        final CacheManager cacheManager2 = CacheManager.create();
        final net.sf.ehcache.Cache gotCache2 = cacheManager2.getCache(cacheName2);

        assertSame(cacheManager1, cacheManager2);
        assertSame(gotCache1, gotCache2);
        assertNotSame(cache1, cache2);
        assertNotNull(gotCache1);
        assertNotNull(gotCache2);
    }
}

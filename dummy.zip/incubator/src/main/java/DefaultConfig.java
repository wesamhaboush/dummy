import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DefaultConfig {
    @Bean
    public String defaultString(){
        return "simple default string";
    }

    @Bean
    public PersonService personService(){
        return new PersonService();
    }

    @Bean
    public PersonRepository personRepository(){
        return new PersonRepositoryImpl1();
    }
}

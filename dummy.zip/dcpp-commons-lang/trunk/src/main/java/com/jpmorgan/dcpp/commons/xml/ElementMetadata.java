package com.jpmorgan.dcpp.commons.xml;

import java.util.*;

/* package */ final class ElementMetadata {

    private boolean defaultNamespaceDefined = false;
    private final Set<String> definedAttributeNames = new HashSet<String>();
    private final boolean isCommentElement;
    private final Map<String, String> namespacePrefixToURLMap =
        new HashMap<String, String>();

    private final XMLWriter out;
    private final ElementMetadata parent;

    private final String qualifiedName;

    private final Map<String, String> namespaceURIToSchemaPathMap =
        new TreeMap<String, String>();

    private boolean verifyUsage;

    /* package */ ElementMetadata(
        final XMLWriter out, final boolean verifyUsage,
        final ElementMetadata parent,
        final String prefix, final String name,
        final boolean isCommentElement) {

        this.verifyUsage = verifyUsage;
        this.out = out;

        this.qualifiedName = buildQualifiedName(prefix, name);
        this.isCommentElement = isCommentElement;
        this.parent = parent;
    }

    public String buildQualifiedName(final String prefix, final String name) {
        final boolean hasPrefix = XMLUtil.hasValue(prefix);

        if (verifyUsage) {
            if (hasPrefix) XMLUtil.verifyName(prefix);
            XMLUtil.verifyName(name);
        }

        return hasPrefix ? (prefix + ':' + name) : name;
    }

    public void closeStartTag() {
        writeSchemaLocations();
        out.writeStartTagClose();
    }

    public boolean containsNamespacePrefix(final String prefix) {
        return namespacePrefixToURLMap.containsKey(prefix);
    }

    private String formatSchemaLocationString() {
        final StringBuilder schemaLocation = new StringBuilder();
        for (final String uri : namespaceURIToSchemaPathMap.keySet()) {
            final String path = namespaceURIToSchemaPathMap.get(uri);

            // If not the first pair output ...
            if (schemaLocation.length() > 0)
                schemaLocation.append(out.getWhiteSpaceBreakForChildLevel());

            schemaLocation.append(uri + ' ' + path);
        }

        return schemaLocation.toString();
    }

    private String getNamespaceUrl(final String prefix) {
        final String namespaceURL = namespacePrefixToURLMap.get(prefix);
        if (namespaceURL == null && parent != null)
            return parent.getNamespaceUrl(prefix);

        return namespaceURL;
    }

    public ElementMetadata getParent() {
        return parent;
    }

    private String getRequiredNamespaceURL(final String prefix) {
        final String namespaceURL = getNamespaceUrl(prefix);
        if (namespaceURL == null || "".equals(namespaceURL)) {
            throw new IllegalArgumentException("The namespace prefix \""
                + prefix + "\" isn't in scope.");
        }

        return namespaceURL;
    }

    public void setTrustMe(final boolean trustMe) {
        this.verifyUsage = !trustMe;
        if (parent != null) parent.setTrustMe(trustMe);
    }

    private void verifyAttributeNamesWithinStartTag() {
        final Set<String> expandedAttributeNames = new HashSet<String>();

        for (final String qualifiedAttributeName : definedAttributeNames) {
            final int colonIndex = qualifiedAttributeName.indexOf(':');
            if (colonIndex > 0) {
                final String prefix =
                    qualifiedAttributeName.substring(0, colonIndex);
                final String name =
                    qualifiedAttributeName.substring(colonIndex + 1);
                final String namespaceURL = getRequiredNamespaceURL(prefix);

                final String expandedName = namespaceURL + ':' + name;
                if (expandedAttributeNames.contains(expandedName)) {
                    throw new IllegalArgumentException(
                        "The attribute <xmlns:ns=\"" + namespaceURL + "\" ns:"
                            + name + "> is defined twice in this element.");
                } else {
                    expandedAttributeNames.add(expandedName);
                }
            }
        }

        definedAttributeNames.clear();
    }

    private void verifyElementNamespaceUsage() {
        final int colonIndex = qualifiedName.indexOf(':');
        if (colonIndex > 0) {
            final String prefix = qualifiedName.substring(0, colonIndex);
            getRequiredNamespaceURL(prefix);
        }
    }

    private void verifyNamespaceData(
        final String prefix, final String uri, final String schemaPath) {

        final boolean hasPrefix = XMLUtil.hasValue(prefix);
        if (hasPrefix) XMLUtil.verifyName(prefix);
        XMLUtil.verifyURI(uri);
        if (schemaPath != null) XMLUtil.verifyURI(schemaPath);

        // Verify that the prefix isn't already defined
        // on the current element.
        if (hasPrefix) {
            if (containsNamespacePrefix(prefix)) {
                throw new IllegalArgumentException("The namespace prefix \""
                    + prefix + "\" is already defined on the current element.");
            }
        } else if (defaultNamespaceDefined) {
            throw new IllegalArgumentException("The default namespace "
                + "is already defined on the current element.");
        }
    }

    public void verifyOutstandingNamespacePrefixes() {
        verifyElementNamespaceUsage();
        verifyAttributeNamesWithinStartTag();
    }

    public String writeAttributeEqualsValue(
        final String prefix, final String name, final Object value,
        final boolean newLine, final boolean escape) {

        final String qualifiedAttributeName = buildQualifiedName(prefix, name);

        if (definedAttributeNames.contains(qualifiedAttributeName)) {
            throw new IllegalArgumentException("The attribute \""
                + qualifiedAttributeName
                + "\" is defined twice in this element.");
        }

        definedAttributeNames.add(qualifiedAttributeName);

        out.writeAttributeEqualsValue(
            qualifiedAttributeName, value, newLine, escape);

        return qualifiedAttributeName;
    }

    public void writeEndTag(final boolean verbose) {
        writeSchemaLocations();
        out.writeEndTag(qualifiedName, isCommentElement, verbose);
    }

    public void writeNamespaceDeclaration(final String prefix,
        final String uri, final String schemaPath) {
        if (verifyUsage) verifyNamespaceData(prefix, uri, schemaPath);

        out.writeNamespaceDeclaration(prefix, uri);

        // Add this prefix to the list of those in scope for this element.
        final boolean hasPrefix = XMLUtil.hasValue(prefix);
        if (hasPrefix) {
            namespacePrefixToURLMap.put(prefix, uri);
        } else {
            defaultNamespaceDefined = true;
        }

        if (schemaPath != null) {
            namespaceURIToSchemaPathMap.put(uri, schemaPath);
        }
    }

    private void writeSchemaLocations() {
        if (namespaceURIToSchemaPathMap.isEmpty()) return;

        // Write the attributes needed to associate XML Schemas
        // with this XML.
        String xmlSchemaVersion = out.getSchemaVersion();
        String ns_uri = "http://www.w3.org/" + xmlSchemaVersion +
            "/XMLSchema-instance";
        writeNamespaceDeclaration("xsi", ns_uri, null);
        writeAttributeEqualsValue("xsi", "schemaLocation",
            formatSchemaLocationString(), out.isIndentDefined(), false);

        namespaceURIToSchemaPathMap.clear();
    }

    public void writeStartTagOpen(final boolean inCommentedStart) {
        out.writeStartTagOpen(qualifiedName, inCommentedStart);
    }
}

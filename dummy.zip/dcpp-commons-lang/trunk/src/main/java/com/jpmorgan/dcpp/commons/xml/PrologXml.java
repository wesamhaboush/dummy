package com.jpmorgan.dcpp.commons.xml;

public interface PrologXml extends CommonXml {

    PrologXml dtd(String systemId);

    PrologXml dtd(String publicId, String systemId);

    PrologXml entityDef(String name, String value);

    PrologXml externalEntityDef(String name, String filePath);

    PrologXml xslt(String filePath);
}

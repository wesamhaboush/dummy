import com.google.common.collect.ImmutableMap;
import com.jpmorgan.ibtcp.dcpp.xquery.engine.XQueryEngineImpl;
import net.sf.saxon.s9api.XdmEmptySequence;
import net.sf.saxon.s9api.XdmValue;
import org.junit.After;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class TestXQueryEngineImpl {

    @After
    public void cleanUp(){
        System.setProperty("xqueryModuleBaseURL","");
        System.setProperty("xquery.engine.config","");
    }

    @Test
    public void simpleXdmNodeWithExternalVars() throws Exception {
        //given

        System.setProperty("xqueryModuleBaseURL","file:target/test-classes/xquery/");
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final Map<String, XdmValue> params = ImmutableMap.<String, XdmValue>builder()
                .put("payload", xQueryEngine.createXdmNode("<a><b>cd</b></a>"))
                .build();
        //when
        final XdmValue node = xQueryEngine.execute(
                "declare variable $payload as node() external;" +
                "$payload", params);

        //then
        assertEquals("<a>\n" +
                "   <b>cd</b>\n" +
                "</a>".trim(), node.toString().trim());
    }

    @Test
    public void simpleXdmNode() throws Exception {
        //given
        System.setProperty("xqueryModuleBaseURL","file:target/test-classes/xquery/");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute("let $a:=<a/> return $a intersect $a", new HashMap<String, XdmValue>());

        //then
        assertEquals("<a/>", node.toString());
    }

    @Test
    public void simpleXdmAtomicValue() throws Exception {
        //given
        System.setProperty("xqueryModuleBaseURL","file:target/test-classes/xquery/");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute("213", new HashMap<String, XdmValue>());

        //then
        assertEquals("213", node.toString());
    }

    @Test
    public void simpleXdmItem() throws Exception {
        //given
        System.setProperty("xqueryModuleBaseURL","file:target/test-classes/xquery/");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute("213", new HashMap<String, XdmValue>());

        //then
        assertEquals("213", node.toString());
    }

    @Test
    public void simpleXdmEmptySequence() throws Exception {
        //given
        System.setProperty("xqueryModuleBaseURL","file:target/test-classes/xquery/");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute(" ()", new HashMap<String, XdmValue>());

        //then
        assertEquals(XdmEmptySequence.getInstance(), node);
    }

    @Test(expected = IllegalArgumentException.class)
    public void simpleExceptionThrownIfBothClasspathAndFilesystemModuleBasesDefined() throws Exception {
        //given
        System.setProperty("xquery.engine.config","xquery-engine-both-defined.properties");

        //when
        new XQueryEngineImpl();

        //then
        fail();
    }

    @Test
    public void simpleInvocationSucceedsWithCorrectValueForClasspathModules() throws Exception {
        //given
        System.setProperty("xquery.engine.config","xquery-engine-classpath-defined.properties");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute("import module namespace rootmodule='rootmodule' at '/root-module.xqy'; rootmodule:modulefunction()", new HashMap<String, XdmValue>());

        //then
        assertEquals("module2", node.toString());
    }

    @Test
    public void simpleInvocationSucceedsWithCorrectValueForFileSystemModules() throws Exception {
        //given
        System.setProperty("xquery.engine.config","xquery-engine-filesystem-defined.properties");

        //when
        final XQueryEngineImpl xQueryEngine = new XQueryEngineImpl();
        final XdmValue node = xQueryEngine.execute("" +
                "import module namespace rootmodule='rootmodule' at '/root-module.xqy'; rootmodule:modulefunction()", new HashMap<String, XdmValue>());

        //then
        assertEquals("module2", node.toString());
    }

    @Test
    public void testConfigurationWorksFromClasspath() throws MalformedURLException, URISyntaxException {
        assertTrue(new UrlResource("file:./src/test/resources/xquery").exists());
        assertTrue(new FileSystemResource("./src/test/resources/xquery").exists());
        assertTrue(new ClassPathResource("/xquery").exists());
    }


}

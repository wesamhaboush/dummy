package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import static com.google.common.collect.Lists.*;
import static org.junit.Assert.assertEquals;

public class IntegersTest {
    @Test
    public void testRangeWorksForTwoNormalNumbers() throws Exception {
        //given
        final int begin = 5;
        final int end = 17;

        //when
        final Iterable<Integer> result = Integers.range(begin, end);

        //then
        assertEquals(newArrayList(5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16), newLinkedList(result));
    }

    @Test
    public void testRangeWorksForTwoReverseNumbers() throws Exception {
        //given
        final int begin = 17;
        final int end = 5;

        //when
        final Iterable<Integer> result = Integers.range(begin, end);

        //then
        assertEquals(reverse(newArrayList(6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17)), newLinkedList(result));
    }

    @Test
    public void testRangeWorksForNegativeNumbersForward() throws Exception {
        //given
        final int begin = -50;
        final int end = -40;

        //when
        final Iterable<Integer> result = Integers.range(begin, end);

        //then
        assertEquals(newArrayList(-50, -49, -48, -47, -46, -45, -44, -43, -42, -41), newLinkedList(result));
    }

    @Test
    public void testRangeWorksForNegativeNumbersBackwards() throws Exception {
        //given
        final int begin = -40;
        final int end = -50;

        //when
        final Iterable<Integer> result = Integers.range(begin, end);

        //then
        assertEquals(reverse(newArrayList(-49, -48, -47, -46, -45, -44, -43, -42, -41, -40)), newLinkedList(result));
    }

    @Test
    public void testRangeWorksForSameNumber() throws Exception {
        //given
        final int begin = -40;
        final int end = -40;

        //when
        final Iterable<Integer> result = Integers.range(begin, end);

        //then
        assertEquals(newArrayList(), newLinkedList(result));
    }
}

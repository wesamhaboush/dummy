package com.jpmorgan.ibtcp.dcpp.la.review.rules;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.Classes;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder;
import com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmSequenceIterator;
import net.sf.saxon.s9api.XdmValue;
import net.sf.saxon.trans.XPathException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

import static com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil.asString;
import static junit.framework.Assert.assertEquals;

public class TestEquitiesReviewRules {


    private static String xqueryModule = null;

    static {
        try {

            String lookupNameSpaceImport = "import module namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\" at 'src/test/resources/xquery/mockLookup.xqy';";
            String reviewGroupNameSpaceImport = "import module namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\" at 'src/test/resources/xquery/mockReviewGroup.xqy';";
            String reviewAfterEditNameSpaceImport = "import module namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\" at 'src/test/resources/xquery/mockReviewGroupAfterEdit.xqy';";
            String reviewAfterUploadNameSpaceImport = " import module namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\" at 'src/test/resources/xquery/mockReviewGroupAfterUpload.xqy';";

            xqueryModule = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Equity/review_equities.xqy"));


            xqueryModule = xqueryModule.replace("declare namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\";", lookupNameSpaceImport).
                    replace("declare namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\";", reviewAfterUploadNameSpaceImport)
                    .replace("declare namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\";", reviewAfterEditNameSpaceImport)
                    .replace("declare namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\";", reviewGroupNameSpaceImport);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testExecuteManuallyUploadOrEditReviewRuleForEDG() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "12345";
        String counterpartySPN = "arrangerSpnValue";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForRatesSignatoryRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
//        String[] results = result.toString().split("#END");
        XdmSequenceIterator results = result.iterator();
        //then
        assertEquals(asString(results.next()),"FrontOffice-5-Document Edited Online");
        assertEquals(asString(results.next()),"FrontOffice-5-Document Manually Uploaded");

    }
}

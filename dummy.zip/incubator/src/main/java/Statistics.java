public class Statistics {
    private final int number;

    public Statistics(final int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}

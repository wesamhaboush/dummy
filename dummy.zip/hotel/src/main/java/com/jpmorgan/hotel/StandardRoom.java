package com.jpmorgan.hotel;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class StandardRoom extends AbstractRoom implements Room {
    private final static double FIRST_THREE_PRICE = 3;
    private final static double ABOVE_THREE_PRICE = 6;

    public StandardRoom(final String id) {
        super(id);
    }

    @Override
    public double calculatePrice(final Facility... facilities) {
        return firstThree(facilities) * FIRST_THREE_PRICE + aboveThree(facilities) * ABOVE_THREE_PRICE;
    }

    private double aboveThree(final Facility[] facilities) {
        return max(facilities.length - 3, 0);
    }

    private int firstThree(final Facility[] facilities) {
        return min(facilities.length, 3);
    }
}

package com.jpmorgan.hotel;

import org.junit.Test;

import static org.junit.Assert.*;

public class SuiteRoomTest {

    @Test
    public void testCalculatePrice() throws Exception {
        //given

        //when
        final SuiteRoom suiteRoom = new SuiteRoom("234");
        final double price = suiteRoom.calculatePrice(Facility.values());

        //then
        assertEquals(13.0, price, 0.01);
    }
}

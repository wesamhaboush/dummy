package com.jpmorgan.dcpp.commons;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.transform.TransformerException;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class XslTest {
  @Test
  public void testApply() throws Exception {
    //given
    final String xsl =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<xsl:stylesheet\n" +
            "xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"\n" +
            "version=\"2.0\">" +
            "<xsl:template match=\"poem\">\n" +
            "<html>\n" +
            "<head>\n" +
            "<title><xsl:value-of select=\"title\"/></title>\n" +
            "</head>\n" +
            "<body>\n" +
            "<xsl:apply-templates select=\"title, author, stanza, date\"/>\n" +
            "</body>\n" +
            "</html>\n" +
            "</xsl:template>" +
            "<xsl:template match=\"title\">\n" +
            "<div align=\"center\">\n" +
            "<h1><xsl:value-of select=\".\"/></h1>\n" +
            "</div>\n" +
            "</xsl:template>" +
            "<xsl:template match=\"author\">\n" +
            "<div align=\"center\">\n" +
            "<h2>By <xsl:value-of select=\".\"/></h2>\n" +
            "</div>\n" +
            "</xsl:template>\n" +
            "<xsl:template match=\"date\">\n" +
            "<p><i><xsl:value-of select=\".\"/></i></p>\n" +
            "</xsl:template>" +
            "<xsl:template match=\"stanza\">\n" +
            "<p><xsl:apply-templates select=\"line\"/></p>\n" +
            "</xsl:template>" +
            "<xsl:template match=\"line\">\n" +
            "<xsl:if test=\"position() mod 2 = 0\">&#160;&#160;</xsl:if>\n" +
            "<xsl:value-of select=\".\"/><br/>\n" +
            "</xsl:template>" +
            "</xsl:stylesheet>";
    final String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<poem>\n" +
            "<author>Rupert Brooke</author>\n" +
            "<date>1912</date>\n" +
            "<title>Song</title>" +
            "<stanza>\n" +
            "<line>And suddenly the wind comes soft,</line>\n" +
            "<line>And Spring is here again;</line>\n" +
            "<line>And the hawthorn quickens with buds of green</line>\n" +
            "<line>And my heart with buds of pain.</line>\n" +
            "</stanza>\n" +
            "<stanza>\n" +
            "<line>My heart all Winter lay so numb,</line>\n" +
            "<line>The earth so dead and frore,</line>\n" +
            "<line>That I never thought the Spring would come again</line>\n" +
            "<line>Or my heart wake any more.</line>\n" +
            "</stanza>\n" +
            "<stanza>\n" +
            "<line>But Winter's broken and earth has woken,</line>\n" +
            "<line>And the small birds cry again;</line>\n" +
            "<line>And the hawthorn hedge puts forth its buds,</line>\n" +
            "<line>And my heart puts forth its pain.</line>\n" +
            "</stanza>\n" +
            "</poem>";
    final String expected = "<html>\n" +
            "   <head>\n" +
            "      <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
            "      <title>Song</title>\n" +
            "   </head>\n" +
            "   <body>\n" +
            "      <div align=\"center\">\n" +
            "         <h1>Song</h1>\n" +
            "      </div>\n" +
            "      <div align=\"center\">\n" +
            "         <h2>By Rupert Brooke</h2>\n" +
            "      </div>\n" +
            "      <p>And suddenly the wind comes soft,<br>&nbsp;&nbsp;And Spring is here again;<br>And the hawthorn quickens with buds of green<br>&nbsp;&nbsp;And my heart with buds of pain.<br></p>\n" +
            "      <p>My heart all Winter lay so numb,<br>&nbsp;&nbsp;The earth so dead and frore,<br>That I never thought the Spring would come again<br>&nbsp;&nbsp;Or my heart wake any more.<br></p>\n" +
            "      <p>But Winter's broken and earth has woken,<br>&nbsp;&nbsp;And the small birds cry again;<br>And the hawthorn hedge puts forth its buds,<br>&nbsp;&nbsp;And my heart puts forth its pain.<br></p>\n" +
            "      <p><i>1912</i></p>\n" +
            "   </body>\n" +
            "</html>";

    //when
    final String result = Xsl.apply(xsl, xml);

    //then
//    System.out.println(result);
    assertEquals(expected, result);
  }
}

package com.jpmorgan.dcpp.commons.csv;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;


public class MockResultSetMetaData implements ResultSetMetaData {
    String[] columnNames;
    int[] columnTypes;

    public void setColumnNames(String[] names) {
        columnNames = names;
    }

    public void setColumnTypes(int[] types) {
        columnTypes = types;
    }

    public int getColumnCount() throws SQLException {
        return columnNames.length;
    }

    public boolean isAutoIncrement(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isCaseSensitive(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isSearchable(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isCurrency(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int isNullable(int i) throws SQLException {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isSigned(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getColumnDisplaySize(int i) throws SQLException {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getColumnLabel(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getColumnName(int i) throws SQLException {
        return columnNames[i-1];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getSchemaName(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getPrecision(int i) throws SQLException {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getScale(int i) throws SQLException {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getTableName(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getCatalogName(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getColumnType(int i) throws SQLException {
        return columnTypes[i-1];
    }

    public String getColumnTypeName(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isReadOnly(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isWritable(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isDefinitelyWritable(int i) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getColumnClassName(int i) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public <T> T unwrap(Class<T> tClass) throws SQLException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isWrapperFor(Class<?> aClass) throws SQLException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }
}

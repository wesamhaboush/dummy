import junit.framework.TestCase;
import org.junit.Test;

public class HelloTest {
    @Test
    public void testA(){

    }

}
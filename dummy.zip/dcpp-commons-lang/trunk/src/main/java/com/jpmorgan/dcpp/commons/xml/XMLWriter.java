package com.jpmorgan.dcpp.commons.xml;

import java.io.*;
import java.util.List;

import static com.google.common.base.Throwables.propagate;

class XMLWriter {

    private static final int MAX_INDENT_IN_SPACES = 4;

    private final Writer writer;
    private final Version version;

    private String lineSeparator;
    private String indent = "  ";
    private String schemaVersion = "1999";

    private boolean attrOnNewLine;
    private boolean closeStream = true;
    private boolean hasContent;
    private boolean hasIndentedContent;
    private boolean isClosed;
    private boolean outputStarted;
    private boolean spaceInEmptyElements;
    private boolean verifyUsage;

    private int indentionLevel = 0;

    public XMLWriter(final Writer writer, Version version, final boolean verifyUsage) {
        this.writer = writer;
        this.verifyUsage = verifyUsage;
        this.lineSeparator = System.getProperty("line.separator");
        this.version = version;
    }

    private static String nCopies(final int count, final String stringToCopy) {
        final int capacity = count * stringToCopy.length();

        final StringBuilder sb = new StringBuilder(capacity);
        for (int idx = 0; idx < count; ++idx) {
            sb.append(stringToCopy);
        }

        return sb.toString();
    }

    public void close() {
        try {
            if (closeStream) {
                writer.close();
            } else {
                writer.flush();
            }
        } catch (IOException ioException) {
            throw propagate(ioException);
        }

        isClosed = true;
    }

    public void doNotCloseOutputStream() {
        closeStream = false;
    }

    private String getFullIndent() {
        return nCopies(indentionLevel, indent);
    }

    private String getFullIndentForChild() {
        return nCopies(indentionLevel + 1, indent);
    }

    public String getIndent() {
        return indent;
    }

    public String getLineSeparator() {
        return lineSeparator;
    }

    public String getSchemaVersion() {
        return schemaVersion;
    }

    public String getWhiteSpaceBreakForChildLevel() {
        if (isIndentDefined()) {
            final StringBuilder sb = new StringBuilder();
            sb.append(lineSeparator);
            sb.append(getFullIndentForChild());
            return sb.toString();
        } else {
            return " ";
        }
    }

    public boolean isAttrOnNewLine() {
        return attrOnNewLine;
    }

    public boolean isClosed() {
        return isClosed;
    }

    public boolean isIndentDefined() {
        return indent != null;
    }

    public boolean isSpaceInEmptyElements() {
        return spaceInEmptyElements;
    }

    public void resetContentFlags() {
        hasContent = hasIndentedContent = false;
    }

    public void setIndent(final int numSpaces) {
        if (numSpaces < 0) {
            throw new IllegalArgumentException(
                "can't indent a negative number of spaces");
        }

        if (verifyUsage && numSpaces > MAX_INDENT_IN_SPACES) {
            throw new IllegalArgumentException(numSpaces
                + " is an unreasonable indentation");
        }

        indent = "";
        for (int i = 0; i < numSpaces; i++)
            indent += ' ';
    }

    public void setIndent(final String indent) {
        if (verifyUsage) {
            boolean valid =
                indent == null
                || indent.length() == 0
                || "\t".equals(indent);

            if (!valid) {
                // It can only be valid now if every character is a space.
                valid = true; // assume
                for (int i = 0; i < indent.length(); ++i) {
                    if (indent.charAt(i) != ' ') {
                        valid = false;
                        break;
                    }
                }
            }

            if (!valid
                || (indent != null && indent.length() > MAX_INDENT_IN_SPACES)) {
                throw new IllegalArgumentException("invalid indent value");
            }
        }

        this.indent = indent;
    }

    public void setLineSeparator(final String lineSeparator) {
        if (outputStarted) {
            throw new IllegalStateException(
                "can't change CR characters after output has started");
        }

        if (verifyUsage) {
            boolean valid = Xml.MAC_LINE_SEPARATOR.equals(lineSeparator)
                || Xml.UNIX_LINE_SEPARATOR.equals(lineSeparator)
                || Xml.WINDOWS_LINE_SEPARATOR.equals(lineSeparator);
            if (!valid) {
                throw new IllegalArgumentException(
                    "invalid line separator characters");
            }
        }

        this.lineSeparator = lineSeparator;
    }

    public void setSchemaVersion(String schemaVersion) {
        this.schemaVersion = schemaVersion;
    }

    public void setSpaceInEmptyElements(boolean spaceInEmptyElements) {
        this.spaceInEmptyElements = spaceInEmptyElements;
    }

    public void setTrustMe(final boolean trustMe) {
        this.verifyUsage = !trustMe;
    }

    public void write(char chr) {
        write(String.valueOf(chr));
    }

    public void write(final String text) {
        if (isClosed) {
            throw new IllegalStateException(
                "attempting to write XML after close has been called");
        }

        try {
            writer.write(text);
            outputStarted = true;
        } catch (final IOException ioException) {
            throw propagate(ioException);
        }
    }

    public void writeAttributeEqualsValue(final String qualifiedName,
        final Object value, final boolean newLine, final boolean escape) {
        if (newLine) {
            writeLineBreakAndFullIndent();
        } else {
            write(' ');
        }

        writeNameEqualsValue(qualifiedName, value, escape);
    }

    public void writeComment(final String text, final boolean newLine) {
        if (indentionLevel > 0) writeLineBreakAndFullIndent();

        if (newLine && isIndentDefined()) {
            write("<!--");
            writeLineBreakAndFullIndentInChild();
            write(text);
            writeLineBreakAndFullIndent();
            write("-->");
        } else {
            write("<!-- ");
            write(text);
            write(" -->");
        }

        if (indentionLevel == 0 && isIndentDefined()) writeln();

        hasContent = hasIndentedContent = true;
    }

    public void writeDocType(final String rootElementName,
        final String doctypePublicId, final String doctypeSystemId,
        final List<String> entityDefs) {
        if (doctypeSystemId == null && entityDefs.isEmpty())
            return;

        write("<!DOCTYPE " + rootElementName);
        if (doctypePublicId != null) {
            write(" PUBLIC \"" + doctypePublicId + "\" \""
                + doctypeSystemId + '"');
        } else if (doctypeSystemId != null) {
            write(" SYSTEM \"" + doctypeSystemId + '"');
        }

        if (!entityDefs.isEmpty()) {
            write(" [");

            for (final String entityDef : entityDefs) {
                writeLineBreakAndFullIndentInChild();
                write("<!ENTITY " + entityDef + '>');
            }

            if (isIndentDefined()) writeln();
            write(']');
        }

        write('>');
        if (isIndentDefined()) writeln();
    }

    public void writeEndTag(final String qualifiedName,
        final boolean isCommentElement, final boolean verbose) {
        --indentionLevel;

        if (verbose)
            write('>');

        if (hasContent || verbose) {
            if (hasIndentedContent) writeLineBreakAndFullIndent();
            write("</");
            write(qualifiedName);
        } else {
            if (spaceInEmptyElements) write(' ');
            write('/');
        }

        write(isCommentElement ? "-->" : ">");

        hasContent = hasIndentedContent = true; // new setting for parent
    }

    private void writeLineBreakAndFullIndent() {
        if (isIndentDefined()) {
            writeln();
            write(getFullIndent());
        }
    }

    private void writeLineBreakAndFullIndentInChild() {
        if (isIndentDefined()) {
            writeLineBreakAndFullIndent();
            write(getIndent());
        }
    }

    public void writeln() {
        write(lineSeparator);
    }

    public void writeln(final String text) {
        write(text);
        writeln();
    }

    private void writeNameEqualsValue(final String qualifiedName,
        final Object value, final boolean escape) {
        write(qualifiedName);

        write("=\"");
        write(escape ? XMLUtil.escape(value, version) : value.toString());
        write('"');
    }

    public void writeNamespaceDeclaration(
        final String prefix, final String uri) {

        writeWhiteSpaceBreak();

        write("xmlns");
        if (XMLUtil.hasValue(prefix)) write(':' + prefix);
        write("=\"" + uri + '"');

        attrOnNewLine = true; // for the next attribute
    }

    public void writeProcessingInstruction(
        final String target, final String data) {

        if (indentionLevel > 0) writeLineBreakAndFullIndent();

        write("<?" + target + ' ' + data + "?>");

        if (indentionLevel == 0 && isIndentDefined()) writeln();

        hasContent = hasIndentedContent = true;
    }

    public void writeStartTagClose() {
        write('>');
        this.attrOnNewLine = false; // reset
    }

    public void writeStartTagOpen(
        final String qualifiedName, final boolean inCommentedStart) {

        if (indentionLevel > 0) writeLineBreakAndFullIndent();
        write(inCommentedStart ? "<!--" : "<");
        write(qualifiedName);

        ++indentionLevel;
    }

    public void writeText(
        final String text, final boolean newLine, final boolean escape) {
        if (text != null && text.length() > 0) {
            if (newLine) writeLineBreakAndFullIndent();
            write(escape ? XMLUtil.escape(text, version) : text);
        } else if (newLine) {
            writeln();
        }

        hasContent = true;
        hasIndentedContent = newLine;
    }

    private void writeWhiteSpaceBreak() {
        if (isIndentDefined()) {
            writeLineBreakAndFullIndent();
        } else {
            write(' ');
        }
    }

    public void writeXMLDeclaration(final String versionString) {
        final String encoding =
            XMLUtil.DEFAULT_ENCODING;

        writeln("<?xml version=\"" + versionString
            + "\" encoding=\"" + encoding + "\"?>");
    }
}

package com.jpmorgan.ibtcp.dcpp.xquery.engine;

import net.sf.saxon.lib.ModuleURIResolver;
import net.sf.saxon.trans.XPathException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;

import static com.google.common.base.Throwables.propagate;

public class FilepathModuleURIResolver implements ModuleURIResolver, Serializable {
    private static final long serialVersionUID = -480364471418950068L;
    private static final transient Logger LOGGER = LoggerFactory.getLogger(FilepathModuleURIResolver.class);

    private final String xqueryModuleBaseURL;

    public FilepathModuleURIResolver(final String xqueryModuleBaseURL) {
        this.xqueryModuleBaseURL = xqueryModuleBaseURL;
    }

    @Override
    public final StreamSource[] resolve(final String s, final String s1, final String[] strings)
            throws XPathException {
        LOGGER.debug("s[{}], s1[{}], strings[{}]", s, s1, Arrays.asList(strings));
        final StreamSource[] sources = new StreamSource[strings.length];
        for (int i = 0; i < strings.length; i++) {
            sources[i] = loadSource(strings[i], i);
        }
        return sources;
    }

    private StreamSource loadSource(final String string, final int i) {
        try {
            final String[] split = string.split(":");
            final String fileName = split[split.length - 1];
            LOGGER.debug("Trying to Load XQuery Module {}/{}", xqueryModuleBaseURL, fileName);
            final Resource resource = new FileSystemResource(xqueryModuleBaseURL + fileName);
            LOGGER.debug("Loaded XQuery Module {}/{}", xqueryModuleBaseURL, fileName);
            return new StreamSource(resource.getInputStream());
        } catch (IOException e) {
            throw propagate(e);
        }
    }
}

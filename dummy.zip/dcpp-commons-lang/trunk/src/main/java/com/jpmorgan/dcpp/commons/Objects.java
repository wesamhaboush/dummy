package com.jpmorgan.dcpp.commons;

import com.esotericsoftware.kryo.Kryo;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;

import java.util.Collection;

import static com.google.common.base.Throwables.propagate;
import static org.apache.commons.lang3.ObjectUtils.NULL;
import static org.apache.commons.lang3.ObjectUtils.Null;

public final class Objects {
    private Objects(){}

    public static <T> boolean isNotNull(final T t) {
        return t != null;
    }

    public static <T> T createNotIn(final Factory<Null, T> f, final Collection<T> ts){
        T result = f.create(NULL);
        while(ts.contains(result)){
            result = f.create(NULL);
        }
        return result;
    }

    public static <T> boolean isNull(final T t){
        return t == null;
    }

    /**
     * Only works with classes that have no arg constructor
     * @param t object to copy
     * @param <T> class type of object to copy
     * @return a copy of the object with same values as input but different identity
     */
    public static <T> T copy(final T t){
        final Kryo kryo = new Kryo();
        return kryo.copy(t);
    }

    /**
     * Note: this assumes the following:
     * 1- T type is not a private nor private and non-static
     * 2- T type has a no-arg constructor
     *
     * @param t object to test for null
     * @param clazz class to instantiate using no-arg constructor if t is null
     * @param <T> type of t
     * @return instance of t (either t if t is not null, or a new instance of it if not null)
     */
    public static <T> T newIfNull(final T t, final Class<T> clazz){
        try {
            Validate.notNull(clazz, "clazz cannot be null");
            return t != null ? t : clazz.newInstance();
        } catch (final InstantiationException e) {
            throw propagate(e);
        } catch (final IllegalAccessException e) {
            throw propagate(e);
        }
    }

    public static <I, O> O newIfNull(final O t, final Factory<I, O> factory){
        Validate.notNull(factory, "factory cannot be null");
        return t != null ? t : factory.create(null);
    }
}

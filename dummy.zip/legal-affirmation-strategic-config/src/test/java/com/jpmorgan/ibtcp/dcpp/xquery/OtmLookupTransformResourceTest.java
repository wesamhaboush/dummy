package com.jpmorgan.ibtcp.dcpp.xquery;

import static com.jpmorgan.dcpp.commons.Randoms.randomAlphabetic;
import static com.jpmorgan.dcpp.commons.Randoms.randomAlphanumeric;
import static com.jpmorgan.dcpp.commons.Xmls.xpathValue;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.utils.FileUtility.readFileAsString;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.T23Party;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.google.common.collect.ImmutableMap;

public class OtmLookupTransformResourceTest extends AbstractXqueryTest {

    public static final String OTM_LOOKUP_TRANSFORM_RESOURCE_XQY =
            "PaperConfirmationBusinessRules/Common/otm-lookup-transform-resource.xqy";

    @Test
    public void testPayloadPopulated() throws IOException, SaxonApiException, XPathExpressionException, SAXException,
            ParserConfigurationException {
        //given
        final String xqueryModule = loadModuleAsString(OTM_LOOKUP_TRANSFORM_RESOURCE_XQY);
        final String payload = readFileAsString("src/test/resources/TestData/payload/gdfResponse.xml");

        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(
                "2012-03-05",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'tradeDate']/propertyValue/text()"));
    }
    
    @Test
    public void testPayloadPopulated_2963() throws IOException, SaxonApiException, XPathExpressionException, SAXException,
            ParserConfigurationException {
        //given
        final String xqueryModule = loadModuleAsString(OTM_LOOKUP_TRANSFORM_RESOURCE_XQY);
        final String payload = readFileAsString("src/test/resources/TestData/payload/2963_gdfResponse.xml");

        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(
                "2013-03-05",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'tradeDate']/propertyValue/text()"));
        assertEquals(
                "Commodity",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'assetClass']/propertyValue/text()"));
        assertEquals(
                "TXN",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'transactionType']/propertyValue/text()"));
        assertEquals(
                "SETTMNT",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'settlementMethod']/propertyValue/text()"));
        assertEquals(
                "TESTPROJ",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'executionMarket']/propertyValue/text()"));
        assertEquals(
                "Delhi",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'marketerRegion']/propertyValue/text()"));
        assertEquals(
                "Pune",
                xpathValue(result.toString(),
                        "/fortressTask/customProperties/customProperty[propertyName = 'traderRegion']/propertyValue/text()"));

    }

    @Test
    public void testPayloadPopulatedWithEciOwnerAndCounterParty() throws IOException, SaxonApiException, XPathExpressionException, SAXException,
            ParserConfigurationException {
        //given
        final String ownerEci = randomAlphanumeric(5);
        final String counterpartyEci = randomAlphanumeric(5);
        final String xqueryModule = loadModuleAsString(OTM_LOOKUP_TRANSFORM_RESOURCE_XQY);
        final DsThunderheadInput inputPayload  = payload()
                .withParties(
                        new T23Party().withType("COUNTERPARTY").withEci(counterpartyEci),
                        new T23Party().withType("RISK_MANAGEMENT_OWNER").withEci(ownerEci)
                )
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder()
                        .put("payload", payloadXml)
                        .put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(counterpartyEci, xpathValue(result.toString(), "/fortressTask/customProperties/customProperty[propertyName='counterpartyEci']/propertyValue/text()"));
        assertEquals(ownerEci, xpathValue(result.toString(), "/fortressTask/customProperties/customProperty[propertyName='ownerEci']/propertyValue/text()"));
    }

    @Test
    public void testPayloadPopulatedWithOwningSubBusiness() throws IOException, SaxonApiException, XPathExpressionException, SAXException,
            ParserConfigurationException {
        //given
        final String owningSubBusiness = randomAlphabetic(5);
        final String xqueryModule = loadModuleAsString(OTM_LOOKUP_TRANSFORM_RESOURCE_XQY);
        final DsThunderheadInput inputPayload  = payload()
                .withOwningSubBusiness(owningSubBusiness)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder()
                        .put("payload", payloadXml)
                        .put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(owningSubBusiness, xpathValue(result.toString(), "/fortressTask/customProperties/customProperty[propertyName='deskName']/propertyValue/text()"));
    }


}

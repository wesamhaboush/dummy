package com.jpmorgan.ibtcp.dcpp.xquery;

import static com.jpmorgan.dcpp.commons.Xmls.xpathValue;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.ibtcp.dcpp.la.utils.FileUtility;

public class FloatingRateOptionsTest extends AbstractXqueryTest {

    public static final String FLOATING_RATE_OPTION_TRANSFORM_RESOURCE_XQY =
            "PaperConfirmationBusinessRules/Rates/floatingRateOptions_rates.xqy";
    private static final String OQL_CODE_TO_STUB = "lookup:oql($functionName, $args)";

    @Test
    public void testEnrichPayloadWithFloatingRateOptions() throws IOException, SaxonApiException,
            XPathExpressionException, SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                FileUtility
                        .readFileAsString("src/test/resources/TestData/odspages/AccrualMethod_Matrices_FloatingRateOptions.xml");

        String payload =
                "<dsThunderheadInput><gbom><trade><product><tradeLeg><legType>FLOATING_INTEREST_RATE</legType><floatingFormula><formulaType>FLOATING_INTEREST</formulaType><observation><observationType>FLOATING_RATE_RESET</observationType>"
                        + "<floatingRateIndex><domain>:fpml.floating-rate-index</domain><referenceDatakey>AUD-CPI</referenceDatakey></floatingRateIndex></observation></floatingFormula><eventDateSchedule><businessCenter><businessCenterId><domain>:fpml.business-center"
                        + "</domain><referenceDatakey>CLSA</referenceDatakey></businessCenterId></businessCenter></eventDateSchedule></tradeLeg></product></trade></gbom><productEnrichment><assetClass/></productEnrichment><businessCentres/><floatingRateOptions/></dsThunderheadInput>";

        //given
        final String xqueryModule =
                addStubs(loadModuleAsString(FLOATING_RATE_OPTION_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);

        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();
        //then
        assertEquals("AUD-CPI", xpathValue(result.toString(), "//floatingRateOption/name/text()"));
        assertEquals("GBLO", xpathValue(result.toString(), "//floatingRateOption/businessCentre/key/text()"));
        assertEquals("P0D", xpathValue(result.toString(), "//floatingRateOption/offsetDays/text()"));
    }

    @Test
    public void testEnrichPayloadWithFloatingRateOptions_forYCSO() throws IOException, SaxonApiException,
            XPathExpressionException, SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                FileUtility
                        .readFileAsString("src/test/resources/TestData/odspages/AccrualMethod_Matrices_FloatingRateOptions.xml");

        String payload = FileUtility
                .readFileAsString("src/test/resources/TestData/payload/ycso.xml");

        //given
        final String xqueryModule =
                addStubs(loadModuleAsString(FLOATING_RATE_OPTION_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);

        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();
        //then
        assertEquals("USD-ISDA-Swap Rate", xpathValue(result.toString(), "//floatingRateOption/name/text()"));
        assertEquals("GBLO", xpathValue(result.toString(), "//floatingRateOption/businessCentre/key/text()"));
        assertEquals("P0D", xpathValue(result.toString(), "//floatingRateOption/offsetDays/text()"));
    }

    @Test
    public void testEnrichPayloadWithFloatingRateOptionsNoValueInGbom() throws IOException, SaxonApiException,
            XPathExpressionException, SAXException, ParserConfigurationException {

        String OQL_STUB_CODE =
                FileUtility
                        .readFileAsString("src/test/resources/TestData/odspages/AccrualMethod_Matrices_FloatingRateOptions.xml");

        String payload =
                "<dsThunderheadInput><gbom><trade><product><tradeLeg></tradeLeg></product></trade></gbom><productEnrichment><assetClass/></productEnrichment><businessCentres/><floatingRateOptions/></dsThunderheadInput>";

        //given
        final String xqueryModule =
                addStubs(loadModuleAsString(FLOATING_RATE_OPTION_TRANSFORM_RESOURCE_XQY), OQL_STUB_CODE);
        //when
        /**
         * declare variable $payload as node() external;
         declare variable $error as xs:string external;
         declare variable $generateDocumentId as xs:string external;
         */
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).put("error", "")
                        .put("generateDocumentId", "").build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();
        //then
        assertEquals("", xpathValue(result.toString(), "//floatingRateOption"));
    }

    private String addStubs(final String rawModuleCode, final String stubcode) {
        return rawModuleCode.replace(OQL_CODE_TO_STUB, stubcode);
    }
}

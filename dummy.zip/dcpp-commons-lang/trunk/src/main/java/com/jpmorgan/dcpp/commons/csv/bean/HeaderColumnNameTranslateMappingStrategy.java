package com.jpmorgan.dcpp.commons.csv.bean;
import java.util.HashMap;
import java.util.Map;

public class HeaderColumnNameTranslateMappingStrategy<T> extends HeaderColumnNameMappingStrategy<T> {
    private Map<String, String> columnMapping = new HashMap<String, String>();
    protected String getColumnName(int col) {
        return col < header.length ? columnMapping.get(header[col].toUpperCase()) : null;
    }
    public Map<String, String> getColumnMapping() {
        return columnMapping;
    }
    public void setColumnMapping(Map<String, String> columnMapping) {
       for (String key : columnMapping.keySet()) {
          this.columnMapping.put(key.toUpperCase(), columnMapping.get(key));
       }
    }
}

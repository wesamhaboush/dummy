import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import java.util.Collection;

import static java.lang.System.out;
import static org.apache.commons.lang.ArrayUtils.contains;
import static org.apache.commons.lang3.ArrayUtils.toArray;

public class Iffy {
    private final static transient Logger LOGGER = Slf4jLoggerFactory.create();

    public String prepareName(String firstname, String middlename, String lastname) {
        if(StringUtils.isBlank(firstname)){
            throw new IllegalArgumentException(String.format("blank first names are not allowed for data set first[%s] middle[%s] last[%s]", firstname, middlename, lastname));
        }
        String result = firstname;
        if(!StringUtils.isBlank(middlename)){
            result += " " + middlename;
        }
        if(!StringUtils.isBlank(lastname)){
            result += " " + lastname;
        }
        return result;
    }

    public Collection<String> garbageCollection(Collection<String> someNames){
        if(LOGGER.isDebugEnabled()){
            LOGGER.info("I have received {} names to process. ", someNames.size());
        }
        if(someNames == null){
            return null;
        } else {
            for(String name : someNames){
                if(name != null) {
                    out.printf("I got name: %s ", name);
                    out.printf("let's see it capitalized: %s ", name.toUpperCase());
                    out.printf("let's see it small letter: %s ", name.toLowerCase());
                    out.printf("let's see how long it is: %d ", name.length());
                    out.printf("is it too short: %b ", name.length() < 2);
                    out.printf("is it too long: %b ", name.length() < 20);
                    out.printf("is it famous: %b ", contains(toArray("jesus", "obama", "rihanna"), name));
                } else {
                    out.printf("null name found, not processing that.");
                }
            }
        }
        return someNames;
    }

    private void process(final String name) {
        out.printf("I got name: %s ", name);
        out.printf("let's see it capitalized: %s ", name.toUpperCase());
        out.printf("let's see it small letter: %s ", name.toLowerCase());
        out.printf("let's see how long it is: %d ", name.length());
        out.printf("is it too short: %b ", name.length() < 2);
        out.printf("is it too long: %b ", name.length() < 20);
        out.printf("is it famous: %b ", contains(toArray("jesus", "obama", "rihanna"), name));
    }

}

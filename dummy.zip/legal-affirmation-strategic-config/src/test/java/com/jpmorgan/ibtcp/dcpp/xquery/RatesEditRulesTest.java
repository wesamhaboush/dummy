package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.commons.Xmls;
import com.jpmorgan.dcpp.commons.xml.StringXml;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.TDomain;
import com.jpmorgan.dcpp.la.model.generated.TGbomDomain;
import com.jpmorgan.dcpp.la.model.generated.TValueTypeEnum;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import java.io.IOException;
import java.util.Iterator;

import static com.jpmorgan.dcpp.commons.Randoms.*;
import static com.jpmorgan.dcpp.la.model.generated.TBooleanConditionTypeEnum.MANUAL_DRAFTING;
import static com.jpmorgan.dcpp.la.model.generated.TBooleanConditionTypeEnum.NON_STD_CONFIRM;
import static com.jpmorgan.dcpp.la.model.generated.TDomain.DCPP_EVENT_TYPE;
import static com.jpmorgan.dcpp.la.model.generated.TDomain.STS_TXN_TYPE;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.apache.commons.lang3.StringUtils.length;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class RatesEditRulesTest extends AbstractXqueryTest {

    private static final String EDIT_RULES_XQY = "PaperConfirmationBusinessRules/Rates/edit_rates.xqy";
    private static final String EDIT_REASON_CODE_TO_STUB = "editReason:addEditReason($editReason)";
    private static final String EDIT_REASON_STUB_CODE = "$editReason";
    private static final String OQL_CODE_TO_STUB = "lookup:oql($functionName, $args)";
    private static final String OQL_STUB_CODE = "if($functionName eq 'getPreviousRatesEventType' and $args eq 'tradeReference=1234,version=3,issued=true,businessEventId=1') " +
            "then  " + randomFrom("'TU' ","'TA' ") +
            " else if ($functionName eq 'getPreviousRatesEventType' and $args eq 'tradeReference=12345,version=3,issued=true,businessEventId=')" +
            "then  " + randomFrom("'ABC' ","'DEF' ","'XYZ' ") +
            "else ()";

    @Test
    public void testRatesNonStandardFromRms() throws IOException, SaxonApiException {
        //given
        final String editReason = "RMS - Non Standard Confirm Flag = true";
        final String owningBusiness = "RATES";
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withConfirmationProcessing(randomAlphanumeric(30), randomBoolean(), NON_STD_CONFIRM, true)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testRatesManualEditingFromRms() throws IOException, SaxonApiException {
        //given
        final String editReason = "RMS - Manual Drafting Flag = true";
        final String owningBusiness = "RATES";
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withConfirmationProcessing(randomAlphanumeric(30), randomBoolean(), MANUAL_DRAFTING, true)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testRatesFeeOnly() throws IOException, SaxonApiException {
        //given
        final String editReason = "FEE only trade";
        final String owningBusiness = "RATES";
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeLeg(nextInt(0, 999), TValueTypeEnum.NOTIONAL, nextInt(0, 100))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testAmendTypeWithMissingParent() throws IOException, SaxonApiException {
        //given
        final String editReason = "Missing parent event type for Amend";
        final String owningBusiness = "RATES";
        final String domain = randomFrom(DCPP_EVENT_TYPE, STS_TXN_TYPE).value();
        final String referenceDataKey = "OTH";
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withNoTradeEventType()
                .withTradeEventTypeAndReferenceDataKey(domain, referenceDataKey)
                .withTradeLeg(nextInt(0, 999), TValueTypeEnum.NOTIONAL, nextInt(0, 100))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testNonAmendTypeAfterFullUnwindEvent() throws IOException, SaxonApiException {
        //given
        final String editReason = "New Event after a TU/TA";
        final String owningBusiness = "RATES";
        final String domain = randomFrom(TDomain.DCPP_EVENT_TYPE.value(), TDomain.STS_TXN_TYPE.value());
        final String referenceDataKey = not("OTH");
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        final Integer tradeVersion = 3;
        final String coreProcessingTradeId = "1234";
        final String businessEventId = "1";
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withTradeEventTypeAndReferenceDataKey(domain, referenceDataKey)
                .withBusinessEventId(businessEventId)
                .withTradeVersion(tradeVersion,coreProcessingTradeId)
                .withCoreProcessingTradeId(coreProcessingTradeId)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());

        assertTrue("Reason not found: " + editReason , Iterators.any(reasons, hasReason(editReason)));
    }

    @Test
    public void testNonAmendTypeAfterNoFullUnwindEvent() throws IOException, SaxonApiException {
        //given
        final String editReason = "New Event after a TU/TA";
        final String owningBusiness = "RATES";
        final String domain = randomFrom(TDomain.DCPP_EVENT_TYPE.value(), TDomain.STS_TXN_TYPE.value());
        final String referenceDataKey = not("OTH");
        final String xqueryModule = addStubs(loadModuleAsString(EDIT_RULES_XQY));
        //this is hard coded above, do NOT  change unless you change both
        final Integer tradeVersion = 3;
        final String coreProcessingTradeId = "12345";
        final DsThunderheadInput inputPayload  = payload()
                .withOwningBusiness(owningBusiness)
                .withNoTradeEventType()
                .withTradeEventTypeAndReferenceDataKey(domain, referenceDataKey)
                .withTradeVersion(tradeVersion)
                .withCoreProcessingTradeId(coreProcessingTradeId)
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        //when
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        Iterator<String> reasons = Iterators.transform(result.iterator(), convertToString());
        assertFalse("Reason found and it should not : " + editReason, Iterators.any(reasons, hasReason(editReason)));
    }

    private String not(final String input) {
        final String result = randomAlphanumeric(length(input));
        return StringUtils.equals(input, result) ? not(input) : result;
    }

    private Predicate<? super String> hasReason(final String targetReason) {
        return new Predicate<String>() {
            @Override
            public boolean apply(final String currentReason) {
                return targetReason.equals(currentReason);
            }
        };
    }

    private Function<XdmItem, String> convertToString() {
        return new Function<XdmItem, String>() {
            @Override
            public String apply(final XdmItem xdmItem) {
                return xdmItem.toString();
            }
        };
    }

    private String addStubs(final String rawModuleCode){
        return rawModuleCode
                .replace(EDIT_REASON_CODE_TO_STUB, EDIT_REASON_STUB_CODE)
                .replace(OQL_CODE_TO_STUB, OQL_STUB_CODE);
    }

}

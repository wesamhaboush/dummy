
public class Hello {
    public static final void main(final String...args){
        System.out.println("hello world");
    }
}

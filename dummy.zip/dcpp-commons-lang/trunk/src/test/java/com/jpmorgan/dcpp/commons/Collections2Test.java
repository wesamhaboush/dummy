package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class Collections2Test {



  @Test
  public void testEmptyIfNull_Collection_whenNull_ReturnEmpty() {
    //given
    final Collection<String> nullCollection = null;

    //when
    final Collection<String> result = Collections2.emptyIfNull(nullCollection);

    //then
    assertTrue(result.isEmpty());
  }

  @Test
  public void testEmptyIfNull_Collection_whenNotNull_ReturnInput() {
    //given
    final Collection<String> nonNullCollection = new ArrayList<String>(){{add("a");}};

    //when
    final Collection<String> result = Collections2.emptyIfNull(nonNullCollection);

    //then
    assertEquals(result, nonNullCollection);
  }

  @Test
  public void testEmptyIfNull_Set() {
    //given
    final Set<String> nullSet = null;

    //when
    final Set<String> result = Collections2.emptyIfNull(nullSet);

    //then
    assertTrue(result.isEmpty());
  }

  @Test
  public void testEmptyIfNull_Set_whenNotNull_ReturnInput() {
    //given
    final Set<String> nonNullSet = new HashSet<String>(){{add("a");}};

    //when
    final Set<String> result = Collections2.emptyIfNull(nonNullSet);

    //then
    assertEquals(result, nonNullSet);
  }

  @Test
  public void testEmptyIfNull_List() {
    //given
    final List<String> nullList = null;

    //when
    final List<String> result = Collections2.emptyIfNull(nullList);

    //then
    assertTrue(result.isEmpty());
  }

  @Test
  public void testEmptyIfNull_List_whenNotNull_ReturnInput() {
    //given
    final List<String> nonNullList = new ArrayList<String>(){{add("a");}};

    //when
    final List<String> result = Collections2.emptyIfNull(nonNullList);

    //then
    assertEquals(result, nonNullList);
  }

  @Test
  public void testEmptyIfNull_Map() {
    //given
    final Map<String,Object> nullMap = null;

    //when
    final Map<String,Object> result = Collections2.emptyIfNull(nullMap);

    //then
    assertTrue(result.isEmpty());
  }

  @Test
  public void testEmptyIfNull_Map_whenNotNull_ReturnInput() {
    //given
    final Map<String,Object> nonNullMap = new HashMap<String,Object>(){{put("a", new Object());}};

    //when
    final Map<String, Object> result = Collections2.emptyIfNull(nonNullMap);

    //then
    assertEquals(result, nonNullMap);
  }

  @Test
  public void testEmpty(){
    final Set<String> set = Collections2.emptySet(String.class);
    final List<String> list = Collections2.emptyList(String.class);
    final Collection<String> collection = Collections2.emptyCollection(String.class);
    final Map<Integer, String> map = Collections2.emptyMap(Integer.class, String.class);


    //then
    assertTrue(set.isEmpty());
    assertTrue(list.isEmpty());
    assertTrue(collection.isEmpty());
    assertTrue(map.isEmpty());
  }
}

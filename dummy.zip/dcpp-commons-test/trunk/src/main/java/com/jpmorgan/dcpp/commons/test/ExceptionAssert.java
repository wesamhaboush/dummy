package com.jpmorgan.dcpp.commons.test;

import java.util.concurrent.Callable;
import org.junit.Assert;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

public class ExceptionAssert {
    private static final String NOT_APPLICABLE = "N/A";

    public static <T> void assertThrowsExact(final String message, final Callable<T> code, final Class<? extends Throwable> throwableClazz){
        try{
            code.call();
            Assert.fail(String.format("throwable [%s] expected but was never thrown.", throwableClazz.getName()));
        } catch(final Throwable throwable) {
            assertEquals(message, throwableClazz, throwable.getClass());
        }
    }

    public static <T> void assertThrowsExact(final Callable<T> code, final Class<? extends Throwable> throwableClazz){
        assertThrowsExact(NOT_APPLICABLE, code, throwableClazz);
    }

    public static void assertThrowsExact(final Runnable code, final Class<? extends Throwable> throwableClazz){
        final Callable<Void> callableCode = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                code.run();
                return null;
            }
        };
        assertThrowsExact(NOT_APPLICABLE, callableCode, throwableClazz);
    }

    public static void assertThrowsExact(final String message, final Runnable code, final Class<? extends Throwable> throwableClazz){
        final Callable<Void> callableCode = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                code.run();
                return null;
            }
        };
        assertThrowsExact(message, callableCode, throwableClazz);
    }

    public static <T> void assertDoesNotThrowExact(final String message, final Callable<T> code, final Class<? extends Throwable> throwableClazz){
        try{
            code.call();
        } catch(final Throwable throwable) {
            assertNotSame(message, throwableClazz, throwable.getClass());
        }
    }

    public static <T> void assertDoesNotThrowExact(final Callable<T> code, final Class<? extends Throwable> throwableClazz){
        assertDoesNotThrowExact(NOT_APPLICABLE, code, throwableClazz);
    }

    public static void assertDoesNotThrowExact(final Runnable code, final Class<? extends Throwable> throwableClazz){
        final Callable<Void> callableCode = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                code.run();
                return null;
            }
        };
        assertDoesNotThrowExact(NOT_APPLICABLE, callableCode, throwableClazz);
    }

    public static void assertDoesNotThrowExact(final String message, final Runnable code, final Class<? extends Throwable> throwableClazz){
        final Callable<Void> callableCode = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                code.run();
                return null;
            }
        };
        assertDoesNotThrowExact(message, callableCode, throwableClazz);
    }
}

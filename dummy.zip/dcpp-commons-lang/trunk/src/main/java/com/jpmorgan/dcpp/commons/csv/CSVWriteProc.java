package com.jpmorgan.dcpp.commons.csv;

public interface CSVWriteProc {
	void process(CSVWriter out);
}

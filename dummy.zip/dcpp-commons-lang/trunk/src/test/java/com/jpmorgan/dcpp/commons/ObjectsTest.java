package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.ObjectUtils;
import org.junit.Test;

import java.util.Set;

import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Randoms.*;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.lang3.ObjectUtils.Null;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

public class ObjectsTest {

    @Test
    public void testIsNotNull() throws Exception {
        //given
        final Object nullObject = null;
        final Object nonNullObject = mock(Object.class);

        //when then
        assertTrue(Objects.isNotNull(nonNullObject));
        assertFalse(Objects.isNotNull(nullObject));
    }

    @Test
    public void testCreateNotIn(){
        //given
        final Set<String> exclusions = newHashSet("0", "1", "2", "", "4");
        final String expected = "3";

        //when
        final String result = Objects.createNotIn(new IncrementalIntegerStringFactory(), exclusions);

        //then
        assertEquals(expected, result);
    }

    // utils

    private static class IncrementalIntegerStringFactory implements Factory<Null, String>{
        private int n = 0;

        @Override
        public String create(Null aNull) {
            return String.valueOf(n++);
        }
    }

    @Test
    public void testIsNull() {
        assertTrue(Objects.isNull(null));
        assertFalse(Objects.isNull(new Object()));
    }

    @Test
    public void testCopy_producesEqualObjectsButNotSame(){
        //given
        A a = a();

        //when
        A copyOfA = Objects.copy(a);

        //then
        assertEquals(a, copyOfA);
        assertNotSame(a, copyOfA);
    }

    @Test
    public void testNewIfNull(){
        //given

        final NewIfNullClassTestClass nullObject = null;
        final NewIfNullClassTestClass nonNullObject = new NewIfNullClassTestClass();

        //when
        final NewIfNullClassTestClass resultWhenNull = Objects.newIfNull(nullObject, NewIfNullClassTestClass.class);
        final NewIfNullClassTestClass resultWhenNotNull = Objects.newIfNull(nonNullObject, NewIfNullClassTestClass.class);

        //then
        assertTrue(resultWhenNull instanceof NewIfNullClassTestClass);
        assertNotNull(resultWhenNull);

        assertSame(resultWhenNotNull, nonNullObject);
    }

    @Test
    public void testNewIfNullWithFactory(){
        //given
        final class NewIfNullFactoryTestClass {};
        final NewIfNullFactoryTestClass nullObject = null;
        final NewIfNullFactoryTestClass nonNullObject = new NewIfNullFactoryTestClass();
        final Factory<Void, NewIfNullFactoryTestClass> factory = new Factory<Void, NewIfNullFactoryTestClass>() {
            @Override
            public NewIfNullFactoryTestClass create(Void vo1d) {
                return new NewIfNullFactoryTestClass();
            }
        };

        //when
        final NewIfNullFactoryTestClass resultWhenNull = Objects.newIfNull(nullObject, factory);
        final NewIfNullFactoryTestClass resultWhenNotNull = Objects.newIfNull(nonNullObject, factory);

        //then
        assertTrue(resultWhenNull instanceof NewIfNullFactoryTestClass);
        assertNotNull(resultWhenNull);

        assertSame(resultWhenNotNull, nonNullObject);
    }



    //utils
    public static final class NewIfNullClassTestClass {};

    private static class B {
        private final int number;
        private final String text;
        private final float fraction;
        private final char letter;
        private final byte data;

        public B(){
            this.number = randomInt();
            this.text = randomAlphanumeric(10);
            this.fraction = randomFloat();
            this.letter = randomChar();
            this.data = Randoms.randomByte();
        }

        public B(final int number, final String text, final float fraction, final char letter, final byte data) {
            this.number = number;
            this.text = text;
            this.fraction = fraction;
            this.letter = letter;
            this.data = data;
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            final B b = (B) o;

            if (data != b.data) return false;
            if (Float.compare(b.fraction, fraction) != 0) return false;
            if (letter != b.letter) return false;
            if (number != b.number) return false;
            if (text != null ? !text.equals(b.text) : b.text != null) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = number;
            result = 31 * result + (text != null ? text.hashCode() : 0);
            result = 31 * result + (fraction != +0.0f ? Float.floatToIntBits(fraction) : 0);
            result = 31 * result + (int) letter;
            result = 31 * result + (int) data;
            return result;
        }
    }

    private static class A {
        private final B b;
        private final int number;
        private final String text;
        private final float fraction;
        private final char letter;
        private final byte data;

        public A(){
            this.b = new B();
            this.number = randomInt();
            this.text = randomAlphanumeric(10);
            this.fraction = randomFloat();
            this.letter = randomChar();
            this.data = Randoms.randomByte();
        }
        public A(final B b, final int number, final String text, final float fraction, final char letter, final byte data) {
            this.b = b;
            this.number = number;
            this.text = text;
            this.fraction = fraction;
            this.letter = letter;
            this.data = data;
        }

        @Override
        public boolean equals(final Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            final A a = (A) o;

            if (data != a.data) return false;
            if (Float.compare(a.fraction, fraction) != 0) return false;
            if (letter != a.letter) return false;
            if (number != a.number) return false;
            if (b != null ? !b.equals(a.b) : a.b != null) return false;
            if (text != null ? !text.equals(a.text) : a.text != null) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = b != null ? b.hashCode() : 0;
            result = 31 * result + number;
            result = 31 * result + (text != null ? text.hashCode() : 0);
            result = 31 * result + (fraction != +0.0f ? Float.floatToIntBits(fraction) : 0);
            result = 31 * result + (int) letter;
            result = 31 * result + (int) data;
            return result;
        }
    }

    private static A a(){
        return new A(b(), randomInt(), randomAlphanumeric(10), randomFloat(), randomChar(), randomByte());
    }

    private static final B b(){
        return new B(randomInt(), randomAlphanumeric(10), randomFloat(), randomChar(), randomByte());
    }
}

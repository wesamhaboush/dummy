package com.jpmorgan.dcpp.commons;

public interface Factory<I, T> {
    T create(I i);
}

package com.jpmorgan.dcpp.commons;

import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import java.sql.Timestamp;
import java.util.Date;

import static com.google.common.base.Throwables.propagate;

public class Dates {
    private static final DateTimeFormatter PARSER = ISODateTimeFormat.dateTimeParser().withOffsetParsed();
    private static final DateTimeFormatter FORMATTER = ISODateTimeFormat.dateTimeNoMillis().withOffsetParsed();
    private static final DateTimeFormatter ALWAYS_OFFSET_FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZZ");
    private static final String UTC = "UTC";

    /**
     * @param isoDateString any valid iso date string
     * @return returns iso date in the format yyyy-MM-dd'T'HH:mm:ssZZ
     *         for example return values would like this:
     */
    public static String standardizeDate(final String isoDateString) {
        final DateTime dateTime = PARSER.parseDateTime(isoDateString);
        return ALWAYS_OFFSET_FORMATTER.print(dateTime);
    }

    public static DateTime toDateTime(final String isoDateString) {
        return PARSER.parseDateTime(isoDateString);
    }

    public static String toString(final DateTime dateTime) {
        return FORMATTER.print(dateTime);
    }

    public static boolean isIsoDate(final String input) {
        boolean result = true;
        try {
            toDateTime(input);
        } catch (IllegalArgumentException e) {
            result = false;
        }
        return result;
    }

    public static DateTime inTimeZone(final DateTime date, final String destinationTimeZone) {
        final DateTime dstDateTime = date.withZone(DateTimeZone.forID(destinationTimeZone));
//        return dstDateTime.toLocalDateTime().toDateTime();
        return dstDateTime.toDateTime();
    }

    public static DateTime inTimeZone(final LocalDateTime date, final String srcTimeZone, final String destinationTimeZone) {
        final DateTime srcDateTime = date.toDateTime(DateTimeZone.forID(srcTimeZone));
        final DateTime dstDateTime = srcDateTime.withZone(DateTimeZone.forID(destinationTimeZone));
        return dstDateTime;
    }

    public static XMLGregorianCalendar toXmlGregorianCalendar(final DateTime dateTime)
            throws DatatypeConfigurationException {
        final DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
        return dataTypeFactory.newXMLGregorianCalendar(dateTime.toGregorianCalendar());
    }

    public static XMLGregorianCalendar toXmlGregorianCalendar(final Date date) throws DatatypeConfigurationException {
        return toXmlGregorianCalendar(new DateTime(date));
    }

    /**
     * @param isoDateString iso string to convert ot gregorian xml
     * @return
     */
    public static XMLGregorianCalendar toXmlGregorianCalendar(final String isoDateString) {
        try {
            return toXmlGregorianCalendar(PARSER.parseDateTime(isoDateString).withZone(DateTimeZone.UTC));
        } catch (final DatatypeConfigurationException e) {
            throw propagate(e);
        }
    }

    public static String toString(final XMLGregorianCalendar xmlGregorianCalendar) {
        return ALWAYS_OFFSET_FORMATTER.print(new DateTime(xmlGregorianCalendar.toGregorianCalendar()).withZone(DateTimeZone.UTC));
    }

    public static DateTimeFormatter formatter(final String format) {
        return DateTimeFormat.forPattern(format);
    }

    public static java.sql.Date toSqlDate(Date utilDate) {
        return new java.sql.Date(utilDate.getTime());
    }


    public
    static Date noMillis(final Date date){
        return date == null ? null : new DateTime(date).withField(DateTimeFieldType.millisOfSecond(), 0).toDate();
    }

    public static Timestamp toSqlTimestamp(final Date date) {
        return date == null ? null : new Timestamp(date.getTime());
    }

    public static class Now {
        public static DateTime dateTime() {
            return DateTime.now();
        }

        public static Date date() {
            return new Date();
        }

        public static Timestamp timestamp() {
            return new Timestamp(System.currentTimeMillis());
        }
    }

    public static DateTime parseDateTime(final String dateTime) {
        return ISODateTimeFormat.dateTimeParser().withOffsetParsed().parseDateTime(dateTime);
    }

    public static String printDateTime(final DateTime dateTime) {
        return ISODateTimeFormat.dateTime().print(dateTime);
    }
}

package com.jpmorgan.hotel;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SimpleRoomBookingServiceTest {

    @Test
    public void testQuoteRoomWillRunTheEvaluateOnTheRoomRequestedWithTheGivenFacilities() throws Exception {
        //givn
        final String targetRoomId = "123";
        final Facility[] facilities = {Facility.ROOM_BREAKFAST, Facility.SWIMMINGPOOL};
        final TestRoom targetRoom = new TestRoom("123");
        final TestRoom otherRoom = new TestRoom("456");

        //when
        final SimpleRoomBookingService simpleRoomBookingService = new SimpleRoomBookingService();
        simpleRoomBookingService.addRooms(otherRoom, targetRoom);
        simpleRoomBookingService.quoteRoom(targetRoomId, facilities);

        //then
        assertEquals(asList(facilities), targetRoom.facilities);
        assertFalse(simpleRoomBookingService.getAvailableRooms().contains(targetRoom));
    }


    @Test
    public void testGetAvailableRoomsReturnsRoomsAddedToServiceCorrectly() throws Exception {
        //given
        final TestRoom room1 = new TestRoom("123");
        final TestRoom room2 = new TestRoom("456");

        //when
        final SimpleRoomBookingService simpleRoomBookingService = new SimpleRoomBookingService();
        final Set<Room> roomsBeforeAdding = simpleRoomBookingService.getAvailableRooms();
        simpleRoomBookingService.addRooms(room1, room2);
        final Set<Room> roomsAfterAdding = simpleRoomBookingService.getAvailableRooms();

        //then
        assertTrue(roomsBeforeAdding.isEmpty());
        assertEquals(new HashSet<Room>(asList(room1, room2)), roomsAfterAdding);
    }


    //utils
    private static class TestRoom implements Room{
        private final String id;
        private List<Facility> facilities = new ArrayList<Facility>();

        private TestRoom(final String id) {
            this.id = id;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public double calculatePrice(final Facility... facilities) {
            this.facilities.addAll(asList(facilities));
            return 0;
        }
    }
}

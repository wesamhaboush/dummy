package com.jpmorgan.dcpp.commons;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import static com.google.common.base.Throwables.propagate;

public class CloseableAdapter<T> implements Closeable {
    private static final String DEFAULT_CLOSE_METHOD_NAME = "close";

    private final T t;
    private final String closeMethodName;

    public CloseableAdapter(final T t) {
        this(t, DEFAULT_CLOSE_METHOD_NAME);
    }

    public CloseableAdapter(final T t, final String closeMethodName) {
        this.t = t;
        this.closeMethodName = closeMethodName;
    }

    @Override
    public void close() throws IOException {
        try {
            if (t != null) {
                t.getClass().getMethod(closeMethodName).invoke(t);
            }
        } catch (InvocationTargetException e) {
            throw propagate(e);
        } catch (NoSuchMethodException e) {
            throw propagate(e);
        } catch (IllegalAccessException e) {
            throw propagate(e);
        }
    }

    public static <T> Closeable asCloseable(final T t) {
        return new CloseableAdapter<T>(t);
    }

    public static <T> Closeable asCloseable(final T t, final String closeMethodName) {
        return new CloseableAdapter<T>(t, closeMethodName);
    }
}

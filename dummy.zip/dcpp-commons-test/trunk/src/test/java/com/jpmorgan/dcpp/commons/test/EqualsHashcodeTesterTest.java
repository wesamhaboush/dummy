package com.jpmorgan.dcpp.commons.test;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.Factory;
import com.jpmorgan.dcpp.commons.test.EqualsHashcodeTester;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import static com.google.common.collect.Maps.immutableEntry;
import static com.jpmorgan.dcpp.commons.Randoms.randomInt;

public class EqualsHashcodeTesterTest {

    @Test(expected=AssertionError.class)
    public void testRunAllTestsWhenDoesntWork() {
        final Factory<Void,NonConforming> nonConformingFactory = new Factory<Void,NonConforming>(){
            final int field1 = randomInt();
            final int field2 = randomInt();
            @Override
            public NonConforming create(Void vo1d) {
                return new NonConforming(field1, field2);
            }

        };
        new EqualsHashcodeTester<NonConforming>(nonConformingFactory, NonConforming.class).runAllTests();
    }

    @Test
    public void testRunAllTestsWorks() {
        final Factory<Void,Conforming> conformingFactory = new Factory<Void,Conforming>(){
            final int field1 = randomInt();
            final int field2 = randomInt();
            @Override
            public Conforming create(Void vo1d) {
                return new Conforming(field1, field2);
            }

        };
        new EqualsHashcodeTester<Conforming>(conformingFactory, Conforming.class).runAllTests();
    }

    @Test
    public void testRunAllTestsWorksWithEnums() {
        final Factory<Void,ClassWithEnumsAndNonFinal> classWithEnumsFactory = new Factory<Void,ClassWithEnumsAndNonFinal>(){
            @Override
            public ClassWithEnumsAndNonFinal create(Void vo1d) {
                return new ClassWithEnumsAndNonFinal(Dummy.values()[0], new ArrayList<String>());
            }
        };
        new EqualsHashcodeTester<ClassWithEnumsAndNonFinal>(classWithEnumsFactory, ClassWithEnumsAndNonFinal.class).runAllTests();
    }

    @Test(expected=RuntimeException.class)
    public void testRunAllTestsDoesNotWorkWithFinalClassesThatHasNoSuppliedFactories() {
        final Factory<Void,ClassWithFinal> classWithFinalFactory = new Factory<Void,ClassWithFinal>(){
            private final FinalClass fc = new FinalClass();
            @Override
            public ClassWithFinal create(Void vo1d) {
                return new ClassWithFinal(fc);
            }

        };
        new EqualsHashcodeTester<ClassWithFinal>(classWithFinalFactory, ClassWithFinal.class).runAllTests();
    }

    @Test
    public void testRunAllTestsWorksWithFinalClassesThatHasSuppliedFactories() {

        Class<?> aClass = FinalClass.class;
        Factory<Void,?> factory = new Factory<Void,FinalClass>(){
            @Override
            public FinalClass create(Void vo1d) {
                return new FinalClass();
            }
        };
        Map<Class<?>, Factory<Void,?>> nonStandardTypFactories =
                ImmutableMap.<Class<?>, Factory<Void,?>>builder()
                        .put(immutableEntry(aClass, factory))
                .build();

        final Factory<Void,ClassWithFinal> classWithFinalFactory = new Factory<Void,ClassWithFinal>(){
            private final FinalClass fc = new FinalClass();
            @Override
            public ClassWithFinal create(Void vo1d) {
                return new ClassWithFinal(fc);
            }
        };
        new EqualsHashcodeTester<ClassWithFinal>(classWithFinalFactory, ClassWithFinal.class, nonStandardTypFactories).runAllTests();
    }

    //utils

    private static class NonConforming{
        private final int field1;
        private final int field2;

        private NonConforming(final int field1, final int field2){
            this.field1 = field1;
            this.field2 = field2;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) { return false; }
            if (obj == this) { return true; }
            if (obj.getClass() != getClass()) {
                return false;
            }
            final NonConforming other = (NonConforming) obj;
            return new EqualsBuilder()
                    .append(this.field1, other.field1)
                    .isEquals();
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 41 * hash + this.field1;
            hash = 41 * hash + this.field2;
            return hash;
        }
    }

    private static class Conforming{
        private final int field1;
        private final int field2;

        private Conforming(final int field1, final int field2){
            this.field1 = field1;
            this.field2 = field2;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) { return false; }
            if (obj == this) { return true; }
            if (obj.getClass() != getClass()) {
                return false;
            }
            final Conforming other = (Conforming) obj;
            return new EqualsBuilder()
                    .append(this.field1, other.field1)
                    .append(this.field2, other.field2)
                    .isEquals();
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 41 * hash + this.field1;
            hash = 41 * hash + this.field2;
            return hash;
        }
    }

    private static enum Dummy { A, B, C}
    private static class ClassWithEnumsAndNonFinal{
        private final Dummy d;
        private final Collection<String> col = new ArrayList<String>();

        public ClassWithEnumsAndNonFinal(final Dummy d, final Collection<String> col){
            this.d = d;
            this.col.addAll(col);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) { return false; }
            if (obj == this) { return true; }
            if (obj.getClass() != getClass()) {
                return false;
            }
            final ClassWithEnumsAndNonFinal other = (ClassWithEnumsAndNonFinal) obj;
            return new EqualsBuilder()
                    .append(this.d, other.d)
                    .append(this.col, other.col)
                    .isEquals();
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder().
                    append(d).
                    append(col).
                    toHashCode();
        }
    }

    private static class ClassWithFinal{
        private final FinalClass f;

        public ClassWithFinal(final FinalClass f){
            this.f = f;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final ClassWithFinal other = (ClassWithFinal) obj;
            return new EqualsBuilder()
                    .append(this.f, other.f)
                    .isEquals();
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder().
                    append(f).
                    toHashCode();
        }
    }

    private static final class FinalClass{

    }
}

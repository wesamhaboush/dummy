package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import java.io.Closeable;
import java.util.concurrent.atomic.AtomicBoolean;

import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;

public class CloseableAdapterTest {
    @Test
    public void testClose() throws Exception {
        //Given
        final AtomicBoolean closeHasBeenInvoked = new AtomicBoolean(false);

        //this class is normally not closeable
        final class ClassWithCloseMethod {
            public void close(){
              closeHasBeenInvoked.set(true);
            }
        }

        //When
        CloseableAdapter<ClassWithCloseMethod> closeable = new CloseableAdapter<ClassWithCloseMethod>(new ClassWithCloseMethod());
        closeable.close();

        //Then
        assertTrue(closeHasBeenInvoked.get());
    }

  @Test
  public void testAsCloseable() throws Exception {
    //Given
    final AtomicBoolean closeHasBeenInvoked = new AtomicBoolean(false);

    //this class is normally not closeable
    final class ClassWithCloseMethod {
      public void close(){
        closeHasBeenInvoked.set(true);
      }
    }

    //When
    final Closeable closeable = CloseableAdapter.asCloseable(new ClassWithCloseMethod());
    closeable.close();

    //Then
    assertTrue(closeHasBeenInvoked.get());
  }

  @Test
  public void testCloseWorksEvenIfNullObjectSupplied() throws Exception {
    //Given
    final class ClassWithCloseMethod {
      public void close(){
        fail("will not be called in this test");
      }
    }

    final ClassWithCloseMethod nullClassWithClosedMethod = null;
    //When

    CloseableAdapter<ClassWithCloseMethod> closeable = new CloseableAdapter<ClassWithCloseMethod>(nullClassWithClosedMethod);
    closeable.close();

    //Then

  }
}

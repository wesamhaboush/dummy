package com.jpmorgan.dcpp.commons;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.*;

public class EnumsTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testStringIsIn() {
        assertTrue(Enums.isInEnumIgnoreCase("abc", TestEnum.class));
        assertTrue(Enums.isInEnumIgnoreCase("ABC", TestEnum.class));
        assertTrue(Enums.isInEnumIgnoreCase("Zz", TestEnum.class));
        assertTrue(Enums.isInEnumIgnoreCase("BDDD", TestEnum.class));

        assertFalse(Enums.isInEnumIgnoreCase(" abc", TestEnum.class));
        assertFalse(Enums.isInEnumIgnoreCase("tbc", TestEnum.class));
        assertFalse(Enums.isInEnumIgnoreCase("Zzz", TestEnum.class));
    }

    @Test
    public void testStringIsInNullClass() {
        Class<TestEnum> nullClazz = null;

        thrown.expect(RuntimeException.class);
        Enums.isInEnumIgnoreCase("Zzz", nullClazz);
    }

    @Test
    public void testStringIsInNullString() {
        //given
        String nullString = null;

        //then
        thrown.expect(RuntimeException.class);
        Enums.isInEnumIgnoreCase(nullString, TestEnum.class);
    }

    @Test
    public void testStringToEnumIgnoreCase() {
        assertEquals(TestEnum.AbC, Enums.stringToEnumIgnoreCase("abc", TestEnum.class));
        assertEquals(TestEnum.AbC, Enums.stringToEnumIgnoreCase("ABC", TestEnum.class));
        assertEquals(TestEnum.ZZ, Enums.stringToEnumIgnoreCase("Zz", TestEnum.class));
        assertEquals(TestEnum.BdDD, Enums.stringToEnumIgnoreCase("BDDD", TestEnum.class));
        assertEquals(TestEnum.BdDD, Enums.stringToEnumIgnoreCase("BDDD \t ", TestEnum.class));

        assertNull(Enums.stringToEnumIgnoreCase(" a bc", TestEnum.class));
        assertNull(Enums.stringToEnumIgnoreCase("tbc", TestEnum.class));
        assertNull(Enums.stringToEnumIgnoreCase("Zzz", TestEnum.class));
    }

    @Test
    public void testStringToEnumIgnoreCaseNullClass() {
        Class<TestEnum> nullClazz = null;

        thrown.expect(RuntimeException.class);
        Enums.stringToEnumIgnoreCase("Zzz", nullClazz);
    }

    @Test
    public void testStringToEnumIgnoreCaseNullString() {
        //given
        String nullString = null;

        //then
        thrown.expect(RuntimeException.class);
        Enums.stringToEnumIgnoreCase(nullString, TestEnum.class);
    }

    //utils

    enum TestEnum {AbC, BdDD, ZZ, abc};
}

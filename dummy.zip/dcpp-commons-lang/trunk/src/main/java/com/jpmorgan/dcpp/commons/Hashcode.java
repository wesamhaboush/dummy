package com.jpmorgan.dcpp.commons;

/**
 * Collected methods which allow easy implementation of
 * <code>hashCode</code>.
 *
* Example use case:
 * <pre>
 *  public int hashCode(){
 *    int result = HashCodeUtil.SEED;
 *    //collect the contributions of various fields
 *    result = HashCodeUtil.hash(result, fPrimitive);
 *    result = HashCodeUtil.hash(result, fObject);
 *    result = HashCodeUtil.hash(result, fArray);
 *    return result;
 *  }
 * </pre>
 */
public final class Hashcode {

    /**
     * An initial value for a
     * <code>hashCode</code>, to which is added contributions from fields. Using
     * a non-zero value decreases collisons of
     * <code>hashCode</code> values.
     */
    public static final int SEED = 23;

    public static int hash(int aSeed, boolean aBoolean) {
        return firstTerm(aSeed) + (aBoolean ? 1 : 0);
    }

    public static int hash(int aSeed, char aChar) {
        return firstTerm(aSeed) + aChar;
    }

    public static int hash(int aSeed, int aInt) {
        return firstTerm(aSeed) + aInt;
    }

    public static int hash(int aSeed, byte aByte) {
        return firstTerm(aSeed) + aByte;
    }

    public static int hash(int aSeed, short aShort) {
        return firstTerm(aSeed) + aShort;
    }

    public static int hash(int aSeed, long aLong) {
        return firstTerm(aSeed) + (int) (aLong ^ (aLong >>> 32));
    }

    public static int hash(int aSeed, float aFloat) {
        return hash(aSeed, Float.floatToIntBits(aFloat));
    }

    public static int hash(int aSeed, double aDouble) {
        return hash(aSeed, Double.doubleToLongBits(aDouble));
    }

    /**
     * <code>aObject</code> is a possibly-null object field, and possibly an
     * array.
     *
     * If
     * <code>aObject</code> is an array, then each element may be a primitive or
     * a possibly-null object.
     */
    public static <T> int hash(int aSeed, T t) {
        int result = aSeed;
        if (t == null) {
            result = hash(result, 0);
        } else {
            result = hash(result, t.hashCode());
        }
        return result;
    }

    /**
     * I have doubts over this implementation because it doesn't handle multi-dimensional arrays
     * @param <T>
     * @param aSeed
     * @param ts
     * @return
     */
    public static <T> int hashArray(int aSeed, T[] ts) {
        int result = aSeed;
        if (ts == null) {
            result = hash(result, 0);
        } else {
            for (T t : ts) {
                //recursive call!
                result = hash(result, t);
            }
        }
        return result;
    }

    public static int hashArray(int aSeed, int[] ints) {
        int result = aSeed;
        if (ints == null) {
            result = hash(result, 0);
        } else {
            for (int i : ints) {
                //recursive call!
                result = hash(result, i);
            }
        }
        return result;
    }

    //TODO add hashArrays for non Object types (primitives: int, short, byte, char, boolean, long, etc)

    private static final int fODD_PRIME_NUMBER = 37;

    private static int firstTerm(int aSeed) {
        return fODD_PRIME_NUMBER * aSeed;
    }
}


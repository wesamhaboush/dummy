package com.jpmorgan.dcpp.commons;

import static org.apache.commons.lang3.ObjectUtils.Null;

import java.util.UUID;

public class Uuids {
    public final static Factory<Null, UUID> RANDOM_UUID_FACTORY = new Factory<Null, UUID>() {
        @Override
        public UUID create(Null nothing) {
            return UUID.randomUUID();
        }
    };

    private Uuids(){}
}

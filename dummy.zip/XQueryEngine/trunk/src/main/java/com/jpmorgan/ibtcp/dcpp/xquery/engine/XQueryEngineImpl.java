package com.jpmorgan.ibtcp.dcpp.xquery.engine;

import net.sf.saxon.event.Builder;
import net.sf.saxon.lib.FeatureKeys;
import net.sf.saxon.lib.ModuleURIResolver;
import net.sf.saxon.s9api.*;
import net.sf.saxon.trace.XQueryTraceListener;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.naming.ConfigurationException;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.stream.StreamSource;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import static com.google.common.base.Throwables.propagate;
import static org.apache.commons.lang.StringUtils.*;

public class XQueryEngineImpl implements XQueryEngine, Serializable {

    private static final transient Logger LOGGER = LoggerFactory.getLogger(XQueryEngineImpl.class);
    private static final long serialVersionUID = 1536651391485089079L;
    private static final String CONFIG_FILE_NAME_PROP = "xquery.engine.config";
    private static final String CONFIG_FILE_NAME = "xquery-engine.properties";
    private static final String XQUERY_MODULE_BASE_URL_PROPERTY = "xqueryModuleBaseURL";

    private final boolean update;
    private final XQueryCompiler compiler;
    private final boolean isClasspathModuleLoadingEnabled;
    private final String xqueryModuleBaseURL;
    private final ErrorListener errorListener;
    private final ThreadLocal<Map<String, XQueryEvaluator>> xqueryEvals =
            new ThreadLocal<Map<String, XQueryEvaluator>>();
    private Processor processor;

    public XQueryEngineImpl() throws ConfigurationException, org.apache.commons.configuration.ConfigurationException, MalformedURLException {
        this(readValueOfIsClassPathLoadingAndXqueryModuleBaseUrl(),
                false,
                new LoggerXqueryErrorListener());
    }

    public XQueryEngineImpl(final String xqueryModuleBaseURL,
                            final boolean isClasspathModuleLoadingEnabled,
                            final boolean update,
                            final ErrorListener errorListener) throws ConfigurationException, org.apache.commons.configuration.ConfigurationException, MalformedURLException {
        this.xqueryModuleBaseURL = xqueryModuleBaseURL;
        this.isClasspathModuleLoadingEnabled = isClasspathModuleLoadingEnabled;
        Validate.isTrue(resource().exists(), String.format("%s URL does not exist", resource()));
        this.errorListener = errorListener;
        this.update = update;
        this.processor = new Processor(true);
        this.compiler = processor.newXQueryCompiler();
        init();
    }

    private XQueryEngineImpl(ImmutablePair<Boolean, String> classLoadingAndXqueryUrl,
                             final boolean update,
                             final ErrorListener errorListener) throws ConfigurationException, org.apache.commons.configuration.ConfigurationException, MalformedURLException {
        this(classLoadingAndXqueryUrl.getRight(),
                classLoadingAndXqueryUrl.getLeft(),
                update,
                errorListener);
    }

    @Override
    public final XdmValue execute(
            final String xquery,
            final Map<String, XdmValue> externalParams) {
        try {
            return doExecute(xquery, externalParams);
        } catch (SaxonApiException e) {
            throw propagate(e);
        }
    }


    private XdmValue doExecute(final String xquery,
                               final Map<String, XdmValue> externalParams) throws SaxonApiException {
        LOGGER.debug("starting to execute XQuery updating {}", update);

        addEvaluatorToThreadLocalsIfNeeded(xquery);

        final XQueryEvaluator evaluator = xqueryEvals.get().get(xquery);

        if (LOGGER.isDebugEnabled()) {
            XQueryTraceListener listener = new XQueryTraceListener();
            evaluator.setTraceListener(listener);
        }

        for (Map.Entry<String, XdmValue> entry : externalParams.entrySet()) {
            LOGGER.debug("Adding parameter {} -> {}", entry.getKey(), entry.getValue());
            evaluator.setExternalVariable(new QName(entry.getKey()), entry.getValue());
        }

        StopWatch sw = new StopWatch();
        sw.start();
        final XdmValue result = evaluator.evaluate();
        sw.stop();

        LOGGER.debug("XQuery Execution Time {} ms", sw.getTime());
        return result;
    }

    private void addEvaluatorToThreadLocalsIfNeeded(final String xquery) {
        if (xqueryEvals.get() == null) {
            xqueryEvals.set(new HashMap<String, XQueryEvaluator>());
        }
        if (xqueryEvals.get().get(xquery) == null) {
            LOGGER.debug("Adding Xquery to cache ", xquery);

            final XQueryExecutable exp = compileXquery(xquery, update);

            final XQueryEvaluator evaluator = exp.load();
            evaluator.setErrorListener(errorListener == null ? new LoggerXqueryErrorListener() : errorListener);

            xqueryEvals.get().put(xquery, evaluator);
        }
    }

    private XQueryExecutable compileXquery(final String xquery, final boolean update) {
        try {
            return compiler.compile(xquery);
        } catch (SaxonApiException e) {
            throw propagate(e);
        }
    }

    private Resource resource() throws MalformedURLException {
        return isClasspathModuleLoadingEnabled ? new ClassPathResource(xqueryModuleBaseURL) : new FileSystemResource(xqueryModuleBaseURL);
    }

    private void init() throws ConfigurationException, org.apache.commons.configuration.ConfigurationException, MalformedURLException {
        LOGGER.info("XQuery Engine Starting");

        processor.setConfigurationProperty(FeatureKeys.TREE_MODEL, Builder.LINKED_TREE);
        processor.setConfigurationProperty("http://saxon.sf.net/feature/compile-with-tracing", LOGGER.isDebugEnabled());

        compiler.setErrorListener(errorListener == null ? new LoggerXqueryErrorListener() : errorListener);
        compiler.setUpdatingEnabled(update);
        compiler.setModuleURIResolver(getModuleResolver());
        compiler.setCompileWithTracing(LOGGER.isDebugEnabled());

        LOGGER.info("XQuery Engine Base url [{}]", xqueryModuleBaseURL);
        LOGGER.info("Static Context base-uri set to [{}] ", compiler.getUnderlyingStaticContext().getBaseURI());
        LOGGER.info("XQuery Engine Started");
    }

    private ModuleURIResolver getModuleResolver() {
        return isClasspathModuleLoadingEnabled ? new ClasspathBasedModuleURIResolver(xqueryModuleBaseURL) : new FilepathModuleURIResolver(xqueryModuleBaseURL);
    }

    private static ImmutablePair<Boolean, String> readValueOfIsClassPathLoadingAndXqueryModuleBaseUrl() throws org.apache.commons.configuration.ConfigurationException {
        final String xqueryModuleBaseURLFromSystemProps = removeFilePrefixIfExists(System.getProperty(XQUERY_MODULE_BASE_URL_PROPERTY));
        if (isNotBlank(xqueryModuleBaseURLFromSystemProps)) {
            return ImmutablePair.of(false, xqueryModuleBaseURLFromSystemProps);
        } else {
            final Configuration config = new PropertiesConfiguration(XQueryEngineImpl.class.getClassLoader()
                    .getResource(isBlank(System.getProperty(CONFIG_FILE_NAME_PROP))
                            ? CONFIG_FILE_NAME : System.getProperty(CONFIG_FILE_NAME_PROP)));
            final String xqueryClasspathContextPath = config.getString("xquery.classpath.context");
            final String xqueryFilesystemContextPath = config.getString("xquery.filesystem.context");

            //check exactly one of the two settings is configured;
            final boolean bothAreProvided = isNotBlank(xqueryClasspathContextPath) && isNotBlank(xqueryFilesystemContextPath);
            final boolean bothAreNotProvided = isBlank(xqueryClasspathContextPath) && isBlank(xqueryFilesystemContextPath);
            Validate.isTrue(!bothAreProvided, "one of file system or classpah resource modules must be configured, NOT both");
            Validate.isTrue(!bothAreNotProvided, "both of file system or classpah resource modules are blank, please configure");

            return ImmutablePair.of(isNotBlank(xqueryClasspathContextPath), isNotBlank(xqueryClasspathContextPath) ? xqueryClasspathContextPath : xqueryFilesystemContextPath);
        }
    }

    public XdmNode createXdmNode(final String value) throws SaxonApiException {
        return processor.newDocumentBuilder().build(new StreamSource(IOUtils.toInputStream(value)));
    }

    private static String removeFilePrefixIfExists(final String property) {
        return removeStartIgnoreCase(property, "file:");
    }
}

package com.jpmorgan.ibtcp.dcpp.la.review.rules;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.jpmorgan.dcpp.commons.Classes;
import com.jpmorgan.dcpp.la.model.generated.*;
import com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder;
import com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;
import net.sf.saxon.trans.XPathException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

import static com.jpmorgan.dcpp.la.model.generated.TDomain.STS_TXN_TYPE;
import static junit.framework.Assert.assertEquals;

public class TestCommoditiesReviewRules {


    private static String xqueryModule = null;

    static {
        try {

            String lookupNameSpaceImport = "import module namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\" at 'src/test/resources/xquery/mockLookup.xqy';";
            String reviewGroupNameSpaceImport = "import module namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\" at 'src/test/resources/xquery/mockReviewGroup.xqy';";
            String reviewAfterEditNameSpaceImport = "import module namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\" at 'src/test/resources/xquery/mockReviewGroupAfterEdit.xqy';";
            String reviewAfterUploadNameSpaceImport = " import module namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\" at 'src/test/resources/xquery/mockReviewGroupAfterUpload.xqy';";

            xqueryModule = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Commodity/review_commodities.xqy"));


            xqueryModule = xqueryModule.replace("declare namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\";", lookupNameSpaceImport).
                    replace("declare namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\";", reviewAfterUploadNameSpaceImport)
                    .replace("declare namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\";", reviewAfterEditNameSpaceImport)
                    .replace("declare namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\";", reviewGroupNameSpaceImport);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testEastEuroPowerReviewRuleForEGY() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        String tradeCounterParty ="9481380";


         final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);

        TReferenceDataKey referenceDataKeyForInstrument = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Electricity")
                .withDomain(TDomain.fromValue(":endur.commodity-group"));


        TInstrument instrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrument);

        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withSourceSysId("1234").withDcppId("0").withLegType(OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.COMMODITY_FLOATING)).withInstruments(instrument);


        Trade trade = (Trade)inputPayload.getGbom().getAny();
    //    trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        trade.getProduct().withTradeLegs(tradeLeg);


        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        String[] results = result.toString().split("#END");
        assertEquals(results[0].trim(),"CreditOffice-3-East Euro Power - Credit Review");

    }


    @Test
    public void testExoticPrimaryMOReviewRuleForEGY() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        String tradeCounterParty ="9481380";


        final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);

        TReferenceDataKey referenceDataKey = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("0")
                .withDomain(TDomain.fromValue(":athena.instrument"));

        TPartyRole partyRole = OBJECT_FACTORY.createTPartyRole()
                .withRoleType(TRoleType.BROKER)
                .withPartyIds(Lists.newArrayList(referenceDataKey));

        TReferenceDataKey referenceDataKeyForInstrument = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Investor Products")
                .withDomain(TDomain.fromValue(":endur.commodity-group"));

        TReferenceDataKey referenceDataKeyForInstrumentSubgroup = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Not index swap")
                .withDomain(TDomain.fromValue(":endur.commodity-sub-group"));


        TInstrument instrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrument);
        TInstrument anotherInstrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrumentSubgroup);

        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withSourceSysId("1234").withDcppId("0").withLegType(OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.COMMODITY_FLOATING)).withInstruments(instrument).withInstruments(anotherInstrument);
        Trade trade = (Trade)inputPayload.getGbom().getAny();
        trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        trade.getProduct().withTradeLegs(tradeLeg);
        trade.withEvent(OBJECT_FACTORY.createTEvent().withEventTypes(OBJECT_FACTORY.createTReferenceDataKey().withDomain(STS_TXN_TYPE).withReferenceDatakey("CRE")));
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        String[] results = result.toString().split("#END");
        assertEquals("MiddleOffice-4-Middle Office Review - Exotic Primary", results[0].trim());

    }


}

package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.Validate;

import java.util.Iterator;

public class Iterators {

    /**
     * objects returned are NOT thread-safe, so do NOT share!
     *
     * @param from starting point
     * @param to   end point
     * @return
     */
    public static Iterable<Integer> range(final int from, final int to) {
        return new Iterable<Integer>() {
            @Override
            public Iterator<Integer> iterator() {
                return new Range(from, to, 1);
            }
        };
    }

    public static Iterable<Integer> range(final int from, final int to, final int step) {
        return new Iterable<Integer>() {
            @Override
            public Iterator<Integer> iterator() {
                return new Range(from, to, step);
            }
        };
    }

    private static class Range implements Iterator<Integer> {
        private final Integer from;
        private final Integer to;
        private final Integer step;
        private final boolean isForward;

        private Integer cursor;

        private Range(final Integer from, final Integer to, final Integer step) {
            Validate.notNull(from, "from cannot be null");
            Validate.notNull(to, "to cannot be null");
            Validate.notNull(step, "step cannot be null");
            Validate.isTrue(step > 0, "step cannot be less than zero");

            this.from = from;
            this.to = to;
            this.step = step;
            this.cursor = from;
            this.isForward = from <= to;
        }

        @Override
        public boolean hasNext() {
            return isForward
                    ? cursor.compareTo(to) <= 0
                    : to.compareTo(cursor) <= 0
                    ;
        }

        @Override
        public Integer next() {
            Integer next = cursor;
            if (isForward) {
                cursor += step;
            } else {
                cursor -= step;
            }
            return next;
        }

        public void remove() {
            throw new UnsupportedOperationException("can not remove from loop range");
        }
    }
}

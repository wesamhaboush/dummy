package com.jpmorgan.hotel;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GreatViewRoomTest {

    @Test
    public void testCalculatePriceWillHaveDoubleSuiteRoomPrice() throws Exception {
        //given
        final Facility[] facilities = Facility.values();
        final double suiteRoomPrice = new SuiteRoom("1").calculatePrice(facilities);

        //when
        final double price = new GreatViewRoom("2").calculatePrice(facilities);

        //then
        assertEquals(2 * suiteRoomPrice, price, 0.01);
    }
}

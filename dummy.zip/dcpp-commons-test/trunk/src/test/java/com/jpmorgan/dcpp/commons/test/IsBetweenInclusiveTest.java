package com.jpmorgan.dcpp.commons.test;

import com.jpmorgan.dcpp.commons.test.IsBetweenInclusive;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import static com.jpmorgan.dcpp.commons.Randoms.randomDouble;
import static org.junit.Assert.*;

public class IsBetweenInclusiveTest {

    @Test
    public void testMatchesSafely() {
        //given
        final Double lower = randomDouble(-1000000, 1000000);
        final Double upper = lower + Math.abs(randomDouble(lower + 1, lower + 10));

        final Double below = randomDouble(lower - 10, lower - 1);
        final Double between = randomDouble(lower, upper);
        final Double above = randomDouble(upper + 1, upper + 10);

        final Matcher<Double> instance = IsBetweenInclusive.isBetween(lower, upper);

        //then
        assertFalse(instance.matches(below));
        assertTrue(instance.matches(lower));
        assertTrue(instance.matches(between));
        assertTrue(instance.matches(upper));
        assertFalse(instance.matches(above));
    }

    @Test
    public void testDescribeTo() {
        //given
        final Double lower = randomDouble();
        final Double upper = randomDouble(lower + 1, lower + 10);

        final ArgumentCaptor<String> argument = ArgumentCaptor.forClass(String.class);
        final Description description = Mockito.mock(Description.class);
        final Matcher<Double> instance = IsBetweenInclusive.isBetween(lower, upper);

        //then
        instance.describeTo(description);
        Mockito.verify(description).appendText(argument.capture());
        System.out.println(argument.getValue());
    }

    @Test
    public void testIsBetween() {
        final double lower = randomDouble();
        final double upper = randomDouble(lower + 1, lower + 10);

        final Matcher<Double> result = IsBetweenInclusive.isBetween(lower, upper);

        assertNotNull(result);
    }
}

package com.jpmorgan.dcpp.commons.test;

import org.junit.Test;

import static com.jpmorgan.dcpp.commons.test.IsInstanceMatcher.isInstanceOf;
import static org.junit.Assert.assertThat;

public class IsInstanceMatcherTest {
  
  @Test
  public void isInstanceTest() {
    final Subclass firstSubclass = new Subclass();
    
    assertThat(firstSubclass.getClass(), isInstanceOf(Object.class));
  }

  @Test
  public void isInstanceTest_Subclass() {
    final SecondSubclass secondSubclass = new SecondSubclass();

    assertThat(secondSubclass.getClass(), isInstanceOf(Subclass.class));
    assertThat(secondSubclass.getClass(), isInstanceOf(Object.class));
  }

  @Test(expected = AssertionError.class)
  public void isInstanceTest_NonSubclass() {
    final NonSubclass nonSubclass = new NonSubclass();

    assertThat(nonSubclass.getClass(), isInstanceOf(Object.class));
    assertThat(nonSubclass.getClass(), isInstanceOf(Subclass.class));
  }
  
  // test stuff
  
  class Subclass {
  }
  
  class SecondSubclass extends Subclass {
  }
  
  class NonSubclass {
  }
}

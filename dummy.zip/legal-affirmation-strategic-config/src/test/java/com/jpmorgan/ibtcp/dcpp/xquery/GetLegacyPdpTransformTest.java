package com.jpmorgan.ibtcp.dcpp.xquery;

import static com.google.common.collect.Lists.transform;
import static com.jpmorgan.dcpp.commons.Randoms.randomAlphanumeric;
import static com.jpmorgan.dcpp.commons.Randoms.randomAlphanumericFactory;
import static com.jpmorgan.dcpp.commons.Randoms.randomArray;
import static com.jpmorgan.dcpp.commons.Randoms.randomBoolean;
import static com.jpmorgan.dcpp.commons.Randoms.randomInt;
import static com.jpmorgan.dcpp.commons.Xmls.xpathValue;
import static com.jpmorgan.dcpp.commons.Xmls.xpathValues;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static fj.data.Array.range;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.lang3.BooleanUtils.toStringYesNo;

import java.io.IOException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.commons.Dates;
import com.jpmorgan.dcpp.commons.Randoms;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.T21Contact;
import com.jpmorgan.dcpp.la.model.generated.T2ClientContacts;
import com.jpmorgan.dcpp.la.model.generated.T2ProductEnrichment;
import com.jpmorgan.dcpp.la.model.generated.T40IsdaStandards;
import com.jpmorgan.dcpp.la.model.generated.T41Standard;

public class GetLegacyPdpTransformTest extends AbstractXqueryTest {
    private static final String LEGACY_PDP_TRANSFORM_XQY = "PaperConfirmationBusinessRules/Common/get-legacy-pdp-transform.xqy";

    @Test
    public void vanillaCase_valuesShouldBeCopiedAsSpecifiedForIsdaValues() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(LEGACY_PDP_TRANSFORM_XQY);

        final String name = randomAlphanumeric(randomInt(5, 50));
        final String key = randomAlphanumeric(randomInt(5, 50));
        final boolean isdaCurrencyPair = randomBoolean();
        final boolean isdaCurrency = randomBoolean();
        final boolean isAdheredTo = randomBoolean();
        final String clientFirstName = "James";
        final String clientLastName = "Bond";
        final DsThunderheadInput inputPayload = payload()
                .withProductEnrichment(new T2ProductEnrichment().withIsdaStandards(
                        new T40IsdaStandards().withStandards(
                                new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(key).withName(name).withIsdaCurrency(isdaCurrency)
                        )
                )).withClientContacts(new T2ClientContacts().withContacts(new T21Contact().withContactType("PRIMARY").withFirstName(clientFirstName).withLastName(clientLastName)))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));

        final String resultItem = resultXdmItems.iterator().next().toString();
        assertEquals(name, xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/name"));
        assertEquals(key, xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/key"));
        assertEquals(toStringYesNo(isAdheredTo).toUpperCase(),xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isadheredto"));
        assertEquals(toStringYesNo(isdaCurrency).toUpperCase(),xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrency"));
        assertEquals(toStringYesNo(isdaCurrencyPair).toUpperCase(),xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrencypair"));
        assertEquals(clientFirstName.concat(" ").concat(clientLastName), xpathValue(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/clientpreferencedata/clientcontact/primary/contactname"));
    }

    @Test
    public void multipeStandards_valuesShouldBeCopiedAsSpecifiedForIsdaValues() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(LEGACY_PDP_TRANSFORM_XQY);

        final int numberOfStandards = randomInt(2,10);
        final List<String> names = asList(randomArray(String[].class, randomAlphanumericFactory(randomInt(2, 10)), numberOfStandards));
        final List<String> keys = asList(randomArray(String[].class, randomAlphanumericFactory(randomInt(2, 10)), numberOfStandards));
        final List<Boolean> isdaCurrencyPairs = asList(randomArray(Boolean[].class, Randoms.RANDOM_BOOLEAN_FACTORY, numberOfStandards));
        final List<Boolean> isdaCurrencies = asList(randomArray(Boolean[].class, Randoms.RANDOM_BOOLEAN_FACTORY, numberOfStandards));
        final List<Boolean> isAdheredTos = asList(randomArray(Boolean[].class, Randoms.RANDOM_BOOLEAN_FACTORY, numberOfStandards));

        final DsThunderheadInput inputPayload = payload()
                .withProductEnrichment(new T2ProductEnrichment().withIsdaStandards(
                        new T40IsdaStandards()
                ))
                .build();

        for(int i : range(0, numberOfStandards)){
            inputPayload.getProductEnrichment().getIsdaStandards().getStandards().add(
                    new T41Standard().withIsAdheredTo(isAdheredTos.get(i)).withIsdaCurrencyPair(isdaCurrencyPairs.get(i)).withKey(keys.get(i)).withName(names.get(i)).withIsdaCurrency(isdaCurrencies.get(i))
            );
        }

        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        assertEquals(names, xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/name/text()"));
        assertEquals(keys, xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/key/text()"));
        assertEquals(transform(isAdheredTos, toYesNoStrings()),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isadheredto/text()"));
        assertEquals(transform(isdaCurrencies, toYesNoStrings()),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrency/text()"));
        assertEquals(transform(isdaCurrencyPairs, toYesNoStrings()),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrencypair/text()"));
    }

    @Test
    public void noStandards_standardsTagMustNotBeAdded() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(LEGACY_PDP_TRANSFORM_XQY);
        final DsThunderheadInput inputPayload = payload()
                .withProductEnrichment(new T2ProductEnrichment())
                .build();


        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();

        assertEquals(emptyList(), xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/name/text()"));
        assertEquals(emptyList(), xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/key/text()"));
        assertEquals(emptyList(),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isadheredto/text()"));
        assertEquals(emptyList(),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrency/text()"));
        assertEquals(emptyList(),xpathValues(resultItem, "/dsThunderheadInput/tradeconfirmationspdp/enrichment/productenrichment/isdastandards/standard/isdacurrencypair/text()"));
    }

    public Function<Boolean, String> toYesNoStrings() {
        return new Function<Boolean, String>() {
            @Override
            public String apply(final Boolean input) {
                return toStringYesNo(input).toUpperCase();
            }
        };
    }

    //test utils
    private static void prettyPrint(final String payloadXml) throws IOException, ParserConfigurationException, TransformerException {
        //uncomment to pretty print, comment to turn off
//        Xmls.print(Xmls.toW3cDoc(payloadXml), System.out);
    }

    private static String randomDuration() throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newDuration(Dates.Now.date().getTime()).toString();
    }

    private static XMLGregorianCalendar xmlTime(final int hour, final int mins) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hour, mins, 0, 0, 0);
    }
}

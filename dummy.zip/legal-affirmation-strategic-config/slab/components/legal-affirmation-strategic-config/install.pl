#!/usr/bin/env slabperl
#
# SLAB example component installer
#
use strict;
use warnings;

use lib "$ENV{SLAB_DIR}/modules";
use GenericInstall;
use Log::Log4perl;

# Exported from GenericInstall;
our $upgradeFromVersion		= "";
our $releaseIsFullOrPatch	= "FULL";
our $has_db					= "N";
our %runOption;
our @requiredEnvironmentVariables = ();

my $os = `uname`;
my $os_slablet;
chomp $os;

if ( $os eq "Linux" ) {
        $os_slablet = "JDK16-LINUX-SLABLET";
} else {
        $os_slablet = "JDK16-SOLARIS-SLABLET";
}

our %slablets = ('app/jdk'=>{
                    'compGrp'=>"$ENV{ENVGRP}",
                    'slablet'=>"$os_slablet",
                    'version'=>'1.6.0.017',
                    'path'=>'jdk1.6.0',
                    'pkgType'=>'frozen'
                        }
                );

# Defined here and picked up scripts further down
my %componentDependency = ();
my @exUsers = ();
my @exUserGroupRights = ();

# Options to be used in a full installation
$runOption{"linkRelease"}		= "Y";
$runOption{"processTemplates"}		= "Y";
$runOption{"configureMcp"}		= "Y";
$runOption{"generateEnv"}		= "Y";
$runOption{"moveMcpConfig"}		= "Y";
$runOption{"linkSlablets"}      	= "Y";
$runOption{"componentDefinedLastStage"} = "Y";


installInit();
installComponent();


sub validatecomponentDefinedLastStage {

        my $logger = Log::Log4perl->get_logger("ComponentDefinedLastStage");

                $logger->info("ECOMP-IN-0001-I Installing Last Stage");
                return 0;
}

sub installcomponentDefinedLastStage {

        my $logger = Log::Log4perl->get_logger("ComponentDefinedLastStage");

        $logger->info("ECOMP-IN-0001-I Installing Last Stage");

        $logger->info("**************************************");
        #$logger->info("ENV_LA_CUSTOM_PROPERTY = $ENV{LA_CUSTOM_PROPERTIES}  ");
        $logger->info("COMP_HOME  = $ENV{COMP_HOME}  ");
        $logger->info("INSTALLDIR  = $ENV{INSTALLDIR}  ");
        $logger->info("**************************************");
				
        $logger->info("ECOMP-IN-0001-I Installing Last Stage");

        return 0;

}

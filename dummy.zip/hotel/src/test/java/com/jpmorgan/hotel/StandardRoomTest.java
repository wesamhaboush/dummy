package com.jpmorgan.hotel;

import org.junit.Test;

import static org.junit.Assert.*;

public class StandardRoomTest {

    @Test
    public void testCalculatePriceWillReturns3TimesFirstThreeFacilitiesPlus6TimesAnyMore() throws Exception {
        //given
        final Facility[] facilities = Facility.values();
        final double priceForFirtThreeFacilities = 3;
        final double priceForTheRest = 6;
        final double expectedPrice = 3 * priceForFirtThreeFacilities + (facilities.length - 3) * priceForTheRest;

        //when
        final StandardRoom standardRoom = new StandardRoom("123");

        //then
        assertEquals(expectedPrice, standardRoom.calculatePrice(facilities), 0.01);
    }
}

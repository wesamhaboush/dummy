package com.jpmorgan.dcpp.commons.logging.slf4j;


import org.slf4j.Logger;

import static org.slf4j.LoggerFactory.getLogger;

public final class Slf4jLoggerFactory {
    private Slf4jLoggerFactory() {
    }

    public static Logger create() {
        final Throwable t = new Throwable();
        final StackTraceElement directCaller = t.getStackTrace()[1];
        return getLogger(directCaller.getClassName());
    }
}

package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import java.io.Closeable;

import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class IOTest {
    @Test
    public void testCloseQuietly() throws Exception {
        //given
        final Closeable closeable1 = mock(Closeable.class);
        final Closeable closeable2 = mock(Closeable.class);
        final Closeable closeable3 = null;

        willThrow(new NullPointerException()).given(closeable2).close();

        //when
        IO.closeQuietly(closeable1, closeable2, closeable3);

        //then
        verify(closeable1).close();
        verify(closeable2).close();
    }

    @Test
    public void testAsCloseable() throws Exception {
        //given
        final NonCloseableWithCloseMethod nonCloseableWithCloseMethod = mock(NonCloseableWithCloseMethod.class);

        //when
        final Closeable closeable = IO.asCloseable(nonCloseableWithCloseMethod);
        closeable.close();

        //then
        verify(nonCloseableWithCloseMethod).close();
    }

    @Test
    public void testAsCloseableWithMethodName() throws Exception {
        //given
        final NonCloseableWithDisconnectMethod nonCloseableWithDisconnectMethod = mock(NonCloseableWithDisconnectMethod.class);

        //when
        final Closeable closeable = IO.asCloseable(nonCloseableWithDisconnectMethod, "disconnect");
        closeable.close();

        //then
        verify(nonCloseableWithDisconnectMethod).disconnect();
    }

    //utils
    private static class NonCloseableWithCloseMethod {
        public void close() {
        }

        ;
    }

    private static class NonCloseableWithDisconnectMethod {
        public void disconnect() {
        }

        ;
    }
}

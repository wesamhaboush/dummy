package com.jpmorgan.ibtcp.dcpp.la.utils;

import com.jpmorgan.dcpp.la.model.generated.SignatureDetails;

public class NullSignatureDetails extends SignatureDetails {



}

package com.jpmorgan.ibtcp.dcpp.la.review.rules;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.Classes;
import com.jpmorgan.dcpp.la.model.generated.*;
import com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder;
import com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil;
import net.sf.saxon.s9api.*;
import net.sf.saxon.trans.XPathException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

import static com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil.asString;
import static junit.framework.Assert.assertEquals;


public class TestRatesReviewRules {


    private static String xqueryModule = null;

    static {
        try {

            String lookupNameSpaceImport = "import module namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\" at 'src/test/resources/xquery/mockLookup.xqy';";
            String reviewGroupNameSpaceImport = "import module namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\" at 'src/test/resources/xquery/mockReviewGroup.xqy';";
            String reviewAfterEditNameSpaceImport = "import module namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\" at 'src/test/resources/xquery/mockReviewGroupAfterEdit.xqy';";
            String reviewAfterUploadNameSpaceImport = " import module namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\" at 'src/test/resources/xquery/mockReviewGroupAfterUpload.xqy';";

            xqueryModule = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Rates/review_rates.xqy"));


            xqueryModule = xqueryModule.replace("declare namespace lookup = \"com.jpmorgan.dcpp.gdf.lookup\";", lookupNameSpaceImport).
                    replace("declare namespace reviewGroupAfterupload = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterupload\";", reviewAfterUploadNameSpaceImport)
                    .replace("declare namespace reviewGroupAfterEdit = \"com.jpmorgan.dcpp.gdf.reviewGroupAfterEdit\";", reviewAfterEditNameSpaceImport)
                    .replace("declare namespace reviewGroup = \"com.jpmorgan.dcpp.gdf.reviewGroup\";", reviewGroupNameSpaceImport);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testExecuteTraderReviewForRates() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        String tradeCounterParty ="9481380";


         final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);

        TReferenceDataKey referenceDataKeyForInstrument = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Electricity")
                .withDomain(TDomain.fromValue(":endur.commodity-group"));


        TInstrument instrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrument);
        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withSourceSysId("1234").withDcppId("0").withLegType(OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.COMMODITY_FLOATING)).withInstruments(instrument);


        Trade trade = (Trade)inputPayload.getGbom().getAny();
    //    trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        trade.getProduct().withTradeLegs(tradeLeg);

        trade.getTradeHeader().getPartyTradeData().withConfirmationProcessing(OBJECT_FACTORY.createTConfirmData().withBooleanConditions(OBJECT_FACTORY.createTBooleanCondition().withBoolean(true).withBooleanConditionType(TBooleanConditionTypeEnum.TRADER_REVIEW)));


        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        String[] results = result.toString().split("#END");
        assertEquals("FrontOffice-5-Trader Review" ,results[0].trim());

    }



    @Test
    public void testExecuteMarketerReviewForRates() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        String tradeCounterParty ="9481380";


        final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);

        TReferenceDataKey referenceDataKeyForInstrument = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Electricity")
                .withDomain(TDomain.fromValue(":endur.commodity-group"));


        TInstrument instrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrument);
        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withSourceSysId("1234").withDcppId("0").withLegType(OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.COMMODITY_FLOATING)).withInstruments(instrument);


        Trade trade = (Trade)inputPayload.getGbom().getAny();
        //    trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        trade.getProduct().withTradeLegs(tradeLeg);

        trade.getTradeHeader().getPartyTradeData().withConfirmationProcessing(OBJECT_FACTORY.createTConfirmData().withBooleanConditions(OBJECT_FACTORY.createTBooleanCondition().withBoolean(true).withBooleanConditionType(TBooleanConditionTypeEnum.MARKETER_REVIEW)));


        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        String[] results = result.toString().split("#END");
        assertEquals("Marketer-7-Marketer Review" ,results[0].trim());

    }


    @Test
    public void testExecuteMiddleOfficeReviewRuleForRates() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        String tradeCounterParty ="9481380";


        final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);

        TReferenceDataKey referenceDataKeyForInstrument = OBJECT_FACTORY.createTReferenceDataKey()
                .withReferenceDatakey("Electricity")
                .withDomain(TDomain.fromValue(":endur.commodity-group"));


        TInstrument instrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKeyForInstrument);
        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withSourceSysId("1234").withDcppId("0").withLegType(OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.COMMODITY_FLOATING)).withInstruments(instrument);


        Trade trade = (Trade)inputPayload.getGbom().getAny();
        //    trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        trade.getProduct().withTradeLegs(tradeLeg);

        trade.getTradeHeader().getPartyTradeData().withConfirmationProcessing(OBJECT_FACTORY.createTConfirmData().withBooleanConditions(OBJECT_FACTORY.createTBooleanCondition().withBoolean(true).withBooleanConditionType(TBooleanConditionTypeEnum.MIDDLE_OFFICE_REVIEW)));


        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        //when
        final XdmValue result = qe.evaluate();
        String[] results = result.toString().split("#END");
        assertEquals("Deal-6-Middle Office Review" ,results[0].trim());

    }




    @Test
    public void testExecuteManuallyUploadedOrEditedReviewRuleForRates04() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        final ObjectFactory OBJECT_FACTORY = new ObjectFactory();
        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);
        Trade trade = (Trade)inputPayload.getGbom().getAny();
        trade.getTradeHeader().withTradeDomain("04");
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        final XdmValue result = qe.evaluate();
        XdmSequenceIterator results = result.iterator();
        assertEquals("Deal-6-Document Manually Edited" ,asString(results.next()));
        assertEquals("Deal-6-Document Manually Uploaded" ,asString(results.next()));

    }


    @Test
    public void testExecuteManuallyUploadedOrEditedReviewRuleForRates05() throws SaxonApiException, IOException, XPathExpressionException, XPathException {
        //Given
        final String id = "N003177";
        String arrangerCountry = "";
        String ownerCity = "";
        String ownerCaid = "A102942424";
        String ownerSPN = "9505415";
        String counterpartySPN = "9481380";
        String arrangerDeskCaid = "A102765815456";
        String ownerLegalEntity = "0101";
        String deliveryMedium = "";
        String counterPartyLegalEntity = "";
        final ObjectFactory OBJECT_FACTORY = new ObjectFactory();
        DsThunderheadInput inputPayload = PayloadBuilder.createPayloadForCommodReviewRules(arrangerCountry, ownerCity, ownerCaid, ownerSPN, counterpartySPN, arrangerDeskCaid, ownerLegalEntity, deliveryMedium, counterPartyLegalEntity);
        Trade trade = (Trade)inputPayload.getGbom().getAny();
        trade.getTradeHeader().withTradeDomain("05");
        final String payloadXml = XqueryUtil.removePrelog(XqueryUtil.getStringFromPayload(inputPayload));
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = XqueryUtil.xqueryEvaluator(xqueryModule, varValueMap);
        final XdmValue result = qe.evaluate();
         XdmSequenceIterator results = result.iterator();
        assertEquals("Deal-6-Document Manually Edited", asString(results.next()));
        assertEquals("Deal-6-Document Manually Uploaded" ,asString(results.next()));

    }



}

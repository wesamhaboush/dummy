import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.slf4j.Logger;

import java.io.IOException;

public class ExceptionHandlingLoveStory {
    private final static transient Logger LOGGER = Slf4jLoggerFactory.create();

    private void parenting() throws ParentingException {
        parentingLogic();
    }

    private void accounting() throws AccountingException {
        final String id = "someid";
        try {
            accountingLogic();
        } catch (IOException e) {
            throw new AccountingException("IO occurred while processing accounting for entity " + id, e);
        }
    }

    private void sporting() {
        final boolean freeToPlaySport = false;
        if (freeToPlaySport) {
            //play sports
        } else {
            //don't play sport
        }
    }

    private void logging() {
        final String businessId = "12345";
        try {
            process(businessId);
        } catch (LoggingException e) {
            LOGGER.error("error occurred {} {}", businessId, e);
        }
    }

    private void logging2() throws LoggingException {
        final String businessId = "12345";
        process(businessId);
    }

    private Feels nightlife() {
        layGoingOutFoundations();
        if (doFeelHorrendousAfterGoingOut()) {
            return Feels.Horrendous;
        } else {
            findAWayToGetHome();
            tryDoSomeworkNextDay();
            return Feels.Good;
        }
    }

    private void layGoingOutFoundations() {
        drinkABit();
        drinkMore();
        dressUp();
    }

    private void tryDoSomeworkNextDay() {
        try {
            doWorkNextDay();
        } catch (HangOverException theTowel) {
            throw theTowel;
        }
    }

    private boolean doFeelHorrendousAfterGoingOut() {
        try {
            club();
            clubHarder();
            getLost();
            return false;
        } catch (Exception e) {
            handleDrinkingIncompetenceIssues(e);
            return true;
        }
    }

    private void catchAllPlease() {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(final Thread t, final Throwable e) {
                if (e instanceof UnTestedCodeException) {
                    phoneSimonCooperImmediately();
                }
            }

            private void phoneSimonCooperImmediately() {
            }
        });
    }

    private String anatomy() throws UnbelievableException {
        try {
            if (System.currentTimeMillis() < 0) {
                throw new UnbelievableException("time machine has been invented!!");
            }
            return "good";
        } catch (UnbelievableException ex) {
            throw ex;
        }
    }

    //utils

    private void doWorkNextDay() {
        //are you joking?
    }

    private void findAWayToGetHome() {
        //or somewhere else
    }

    private void handleDrinkingIncompetenceIssues(final Exception e) {
        //badly handling such issues
    }

    private void clubHarder() {
    }

    private void club() {
    }

    private void dressUp() {
    }

    private void drinkMore() {
    }

    private void drinkABit() {
    }

    private Exception away(final Exception e) throws Exception {
        throw new Exception(e.getMessage());
    }


    public Object getLost() {
        return null;
    }

    private static class ParentingException extends RuntimeException {

        public ParentingException(final String s) {
            super(s);
        }

    }

    private static class AccountingException extends RuntimeException {

        public AccountingException(final String msg) {
            super(msg);
        }

        public AccountingException(final String msg, final Throwable e) {
            super(msg, e);
        }
    }

    private static class NotFreeToSportTodayException extends RuntimeException {

        public NotFreeToSportTodayException(final String s) {
            super(s);
        }

    }

    private void parentingLogic() throws ParentingException {
        throw new ParentingException("quite often");
    }

    private void accountingLogic() throws AccountingException, IOException {
        if (true)
            throw new AccountingException("I can always do with more money");
        else
            throw new IOException();
    }


    private enum Feels {Good, Bad, Ugly, Horrendous, Ecstatic;}

    private class HangOverException extends RuntimeException {
    }

    private class LoggingException extends RuntimeException {

    }

    private void process(final String businessId) {
    }

    private class UnTestedCodeException extends RuntimeException {
    }

    private class UnbelievableException extends Throwable {
        public UnbelievableException(final String s) {
        }
    }

    private static interface RTEI {
        void thrower() throws IllegalArgumentException;
    }
}

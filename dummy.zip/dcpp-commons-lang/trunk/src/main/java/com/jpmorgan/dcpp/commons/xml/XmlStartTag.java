package com.jpmorgan.dcpp.commons.xml;

public interface XmlStartTag extends XmlElement {

    XmlStartTag attr(String name, Object value);
    XmlStartTag attr(String prefix, String name, Object value);
    XmlStartTag attr(
        String prefix, String name, Object value, boolean newLine);
    XmlStartTag defaultNamespace(String uri);
    XmlStartTag defaultNamespace(String uri, String schemaPath);
    XmlStartTag defaultNS(String uri);
    XmlStartTag defaultNS(String uri, String schemaPath);
    XmlStartTag namespace(String prefix, String uri);
    XmlStartTag namespace(String prefix, String uri, String schemaPath);
    XmlStartTag ns(String prefix, String uri);
    XmlStartTag ns(String prefix, String uri, String schemaPath);
    XmlStartTag unescapedAttr(String name, Object value);
    XmlStartTag unescapedAttr(String prefix, String name, Object value);
    XmlStartTag unescapedAttr(
        String prefix, String name, Object value, boolean newLine);
}

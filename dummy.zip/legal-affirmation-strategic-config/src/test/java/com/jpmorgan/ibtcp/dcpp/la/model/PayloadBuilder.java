package com.jpmorgan.ibtcp.dcpp.la.model;

import com.google.common.collect.Lists;
import com.jpmorgan.dcpp.commons.Dates;
import com.jpmorgan.dcpp.la.model.generated.*;

import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;

import static com.google.common.base.Objects.firstNonNull;
import static com.google.common.collect.Lists.newArrayList;
import static com.jpmorgan.dcpp.commons.Randoms.randomFrom;
import static java.math.BigDecimal.valueOf;
import static org.apache.commons.lang.math.RandomUtils.nextInt;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

public class PayloadBuilder {
    protected static final ObjectFactory OBJECT_FACTORY = new ObjectFactory();
    private DsThunderheadInput dsThunderheadInput = OBJECT_FACTORY.createDsThunderheadInput().withGbom(
            OBJECT_FACTORY.createGbom());

    private PayloadBuilder() {
    }

    public static PayloadBuilder payload() {
        return new PayloadBuilder();
    }

    public static T2PersonDetails personalDetails(String type, String id, String firstName, String middleName,
            String lastname) {
        return OBJECT_FACTORY.createT2PersonDetails().withPersonDetails(
                OBJECT_FACTORY.createT25PersonDetail().withType(type).withId(id).withFirstName(firstName)
                        .withSecondName(middleName).withSurname(lastname));
    }

    public static DsThunderheadInput payload(final String owningBusiness, final String arrangerSpn,
            final String arrangingDesk, final String counterPartyCountry, final String ownerLegalEntity) {
        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withReferenceDatakey(arrangerSpn)
                        .withDomain(randomFrom(TDomain.class));
        TPartyRole partyRole =
                OBJECT_FACTORY.createTPartyRole().withRoleType(TRoleType.COUNTERPARTY)
                        .withPartyIds(newArrayList(referenceDataKey));
        TBookingData bookingData = OBJECT_FACTORY.createTBookingData().withPartyRoles(partyRole);
        TBusinessId businessId =
                OBJECT_FACTORY.createTBusinessId().withIdentifierType(TIdentifierType.ACM_EXTERNALISED)
                        .withIdentifierValue("abc").withVersion(BigInteger.valueOf(1));
        TPartyTradeData partyTradeData =
                OBJECT_FACTORY.createTPartyTradeData().withPartyViews(new TPartyView()).withBusinessIds(businessId)
                        .withBookingData(bookingData);
        TTradeHeader tradeHeader =
                OBJECT_FACTORY.createTTradeHeader().withPartyTradeData(partyTradeData).withTradeDomain("11")
                        .withTradeDate(Dates.toXmlGregorianCalendar("2014-01-10T00:00:00Z"));
        TEvent event = OBJECT_FACTORY.createTEvent().withEventTypes(referenceDataKey);
        TProduct product = OBJECT_FACTORY.createTProduct().withProductClasses(referenceDataKey);
        Trade trade = OBJECT_FACTORY.createTrade().withEvent(event).withProduct(product).withTradeHeader(tradeHeader);
        Gbom gbom = OBJECT_FACTORY.createGbom().withAny(trade);
        T23Party party1 =
                StringUtils.isNotBlank(arrangingDesk) ? OBJECT_FACTORY.createT23Party().withType("ARRANGING_DESK")
                        .withCaid(arrangingDesk) : null;
        T23Party party2 =
                StringUtils.isNotBlank(counterPartyCountry) ? OBJECT_FACTORY.createT23Party().withType("COUNTERPARTY")
                        .withCountryDomicile(counterPartyCountry) : null;
        T23Party party3 =
                OBJECT_FACTORY.createT23Party().withType("RISK_MANAGEMENT_OWNER").withLegalEntity(ownerLegalEntity);
        T2Parties parties =
                OBJECT_FACTORY.createT2Parties().withParties(party1).withParties(party2).withParties(party3);
        DsThunderheadInput inputPayload =
                OBJECT_FACTORY.createDsThunderheadInput().withGbom(gbom).withParties(parties)
                        .withOwningBusiness(owningBusiness);
        return inputPayload;
    }

    public static DsThunderheadInput createPayloadForCommodReviewRules(String arrangerCountry, String ownerCity,
            String ownerCaid, String ownerSPN, String counterpartySPN, String arrangerDeskCaid,
            String ownerLegalEntity, String deliveryMedium, String counterpartyLegalEntity) {
        final String owningBusiness = "RATES";
        final DsThunderheadInput inputPayload =
                PayloadBuilder.payload(owningBusiness, counterpartySPN, arrangerDeskCaid, "BERMUDA123",
                        ownerLegalEntity, ownerCaid, ownerCity, arrangerCountry, counterpartyLegalEntity);

        Trade trade = (Trade) inputPayload.getGbom().getAny();

        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withReferenceDatakey(ownerSPN)
                        .withDomain(randomFrom(TDomain.class));

        TPartyRole partyRole =
                OBJECT_FACTORY.createTPartyRole().withRoleType(TRoleType.RISK_MANAGEMENT_OWNER)
                        .withPartyIds(Lists.newArrayList(referenceDataKey));

        trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        inputPayload.withClientContacts(new T2ClientContacts().withContacts(Lists.newArrayList(new T21Contact()
                .withDocumentDeliveryMedium(deliveryMedium).withContactType("PRIMARY"))));
        return inputPayload;
    }

    public static DsThunderheadInput payload(final String owningBusiness, final String arrangerSpn,
            final String arrangingDesk, final String counterPartyCountry, final String ownerLegalEntity,
            final String riskManagementOwnerCaid, final String riskManagementOwnerCity, final String arrangerCountry,
            final String counterpartyLegalEntity

    ) {
        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withReferenceDatakey(arrangerSpn)
                        .withDomain(randomFrom(TDomain.class));

        TPartyRole partyRole =
                OBJECT_FACTORY.createTPartyRole().withRoleType(TRoleType.COUNTERPARTY)
                        .withPartyIds(Lists.newArrayList(referenceDataKey));

        TBookingData bookingData = OBJECT_FACTORY.createTBookingData().withPartyRoles(partyRole);
        TBusinessId businessId =
                OBJECT_FACTORY.createTBusinessId().withIdentifierType(TIdentifierType.ACM_EXTERNALISED)
                        .withIdentifierValue("abc").withVersion(BigInteger.valueOf(1));
        TPartyTradeData partyTradeData =
                OBJECT_FACTORY.createTPartyTradeData().withBusinessIds(businessId).withPartyViews(new TPartyView())
                        .withBookingData(bookingData);
        TTradeHeader tradeHeader =
                OBJECT_FACTORY.createTTradeHeader().withPartyTradeData(partyTradeData).withTradeDomain("11")
                        .withTradeDate(Dates.toXmlGregorianCalendar("2014-01-10T00:00:00Z"));
        TEvent event = OBJECT_FACTORY.createTEvent().withEventTypes(referenceDataKey);
        TProduct product = OBJECT_FACTORY.createTProduct().withProductClasses(referenceDataKey);
        Trade trade = OBJECT_FACTORY.createTrade().withEvent(event).withProduct(product).withTradeHeader(tradeHeader);
        Gbom gbom = OBJECT_FACTORY.createGbom().withAny(trade);
        T23Party party1 =
                OBJECT_FACTORY.createT23Party().withType("ARRANGING_DESK").withCaid(arrangingDesk)
                        .withCountryDomicile(arrangerCountry);
        T23Party party2 =
                OBJECT_FACTORY.createT23Party().withType("COUNTERPARTY").withCountryDomicile(counterPartyCountry)
                        .withLegalEntity(counterpartyLegalEntity);
        T23Party party3 =
                OBJECT_FACTORY.createT23Party().withType("RISK_MANAGEMENT_OWNER").withLegalEntity(ownerLegalEntity)
                        .withCity(riskManagementOwnerCity).withCaid(riskManagementOwnerCaid);

        T2Parties parties = OBJECT_FACTORY.createT2Parties().withParties(party1, party2, party3);
        DsThunderheadInput inputPayload =
                OBJECT_FACTORY.createDsThunderheadInput().withGbom(gbom).withParties(parties)
                        .withOwningBusiness(owningBusiness);
        return inputPayload;
    }

    public static SignatureDetails signatureDetails(final String first, final String middle, final String surname) {
        TName name = OBJECT_FACTORY.createTName().withFirst(first).withMiddle(middle).withLast(surname);
        TWorkerData workData = OBJECT_FACTORY.createTWorkerData().withName(name);
        SignatureReferenceData referenceData = OBJECT_FACTORY.createSignatureReferenceData().withWorkerData(workData);
        return OBJECT_FACTORY.createSignatureDetails().withReferenceData(referenceData);
    }

    public static DsThunderheadInput createPayloadForRatesSignatoryRules(String arrangerCountry, String ownerCity,
            String ownerCaid, String ownerSPN, String counterpartySPN, String arrangerDeskCaid,
            String ownerLegalEntity, String deliveryMedium, String counterpartyLegalEntity) {
        final String owningBusiness = "RATES";
        final DsThunderheadInput inputPayload =
                PayloadBuilder.payload(owningBusiness, counterpartySPN, arrangerDeskCaid, "BERMUDA123",
                        ownerLegalEntity, ownerCaid, ownerCity, arrangerCountry, counterpartyLegalEntity);

        Trade trade = (Trade) inputPayload.getGbom().getAny();

        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withReferenceDatakey(ownerSPN)
                        .withDomain(randomFrom(TDomain.class));

        TPartyRole partyRole =
                OBJECT_FACTORY.createTPartyRole().withRoleType(TRoleType.RISK_MANAGEMENT_OWNER)
                        .withPartyIds(Lists.newArrayList(referenceDataKey));

        trade.getTradeHeader().getPartyTradeData().getBookingData().withPartyRoles(partyRole);
        inputPayload.withClientContacts(new T2ClientContacts().withContacts(Lists.newArrayList(new T21Contact()
                .withDocumentDeliveryMedium(deliveryMedium).withContactType("PRIMARY"))));
        return inputPayload;
    }

    public PayloadBuilder withSettlementType(final String settlementType) {
        establishProductEnrichment();
        dsThunderheadInput.getProductEnrichment().setSettlementType(settlementType);
        return this;
    }

    public PayloadBuilder withSubProduct(String subProduct) {
        establishProductEnrichment();
        dsThunderheadInput.getProductEnrichment().setSubProduct(subProduct);
        return this;
    }

    public PayloadBuilder withInstrument(String domain, String instrument) {
        final Trade originalTrade = getTradeIfPresent(firstNonNull(dsThunderheadInput.getGbom(), new Gbom()));
        final Trade trade = firstNonNull(originalTrade, getSkeletonTrade());
        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withDomain(TDomain.fromValue(domain))
                        .withReferenceDatakey(instrument);

        TLegType tLegType =
                OBJECT_FACTORY.createTLegType().withValue(TLegTypeEnum.values()[nextInt(TLegTypeEnum.values().length)]);

        TInstrument tInstrument = OBJECT_FACTORY.createTInstrument().withInstrumentIds(referenceDataKey);
        TProduct product = firstNonNull(trade.getProduct(), OBJECT_FACTORY.createTProduct());
        trade.setProduct(product);
        dsThunderheadInput.getGbom().setAny(trade);

        TTradeLeg tradeLeg = OBJECT_FACTORY.createTTradeLeg().withInstruments(tInstrument).withLegType(tLegType);
        product.getTradeLegs().add(tradeLeg);

        return this;
    }

    public PayloadBuilder withBaseProduct(String baseProduct) {
        establishProductEnrichment();
        dsThunderheadInput.getProductEnrichment().setBaseProduct(baseProduct);
        return this;
    }

    public PayloadBuilder withAgreementPending(final boolean agreementPending) {
        final Trade trade = establishTrade();

        final TAgreement agreement =
                firstNonNull(trade.getAgreement(), new TAgreement()).withAgreementPending(agreementPending);
        trade.setAgreement(agreement);
        return this;
    }

    public PayloadBuilder withAgreementForm(String agreementForm) {
        final Trade trade = establishTrade();

        final TAgreement agreement =
                firstNonNull(trade.getAgreement(), new TAgreement()).withAgreementForm(agreementForm);
        trade.setAgreement(agreement);
        return this;
    }

    public PayloadBuilder withParties(T23Party... parties) {
        final T2Parties originalParties =
                firstNonNull(dsThunderheadInput.getParties(), OBJECT_FACTORY.createT2Parties()).withParties(parties);
        dsThunderheadInput.setParties(originalParties);
        return this;
    }

    private Trade getTradeIfPresent(Gbom gbom) {
        return gbom.getAny() instanceof Trade ? Trade.class.cast(gbom.getAny()) : null;
    }

    private static Trade getSkeletonTrade() {
        TReferenceDataKey referenceDataKey =
                OBJECT_FACTORY.createTReferenceDataKey().withReferenceDatakey(randomAlphanumeric(10))
                        .withDomain(randomFrom(TDomain.class));
        TPartyRole partyRole =
                OBJECT_FACTORY.createTPartyRole().withRoleType(TRoleType.COUNTERPARTY)
                        .withPartyIds(Lists.newArrayList(referenceDataKey));
        TBookingData bookingData = OBJECT_FACTORY.createTBookingData().withPartyRoles(partyRole);
        TBusinessId businessId =
                OBJECT_FACTORY.createTBusinessId().withIdentifierType(TIdentifierType.ACM_EXTERNALISED)
                        .withIdentifierValue("abc").withVersion(BigInteger.valueOf(1));
        TPartyTradeData partyTradeData =
                OBJECT_FACTORY.createTPartyTradeData().withBusinessIds(businessId).withPartyViews(new TPartyView())
                        .withBookingData(bookingData);
        TTradeHeader tradeHeader =
                OBJECT_FACTORY.createTTradeHeader().withPartyTradeData(partyTradeData).withTradeDomain("11")
                        .withTradeDate(Dates.toXmlGregorianCalendar("2014-01-10T00:00:00Z"));
        TEvent event = OBJECT_FACTORY.createTEvent().withEventTypes(referenceDataKey);
        TProduct product = OBJECT_FACTORY.createTProduct().withProductClasses(referenceDataKey);
        return OBJECT_FACTORY.createTrade().withEvent(event).withProduct(product).withTradeHeader(tradeHeader);
    }

    public PayloadBuilder withPersonDetail(String id, String type, String city) {
        T25PersonDetail personDetail =
                OBJECT_FACTORY.createT25PersonDetail().withFirstName(randomAlphabetic(5))
                        .withSecondName(randomAlphabetic(6)).withSurname(randomAlphabetic(7)).withType(type).withId(id)
                        .withCity(city);
        dsThunderheadInput.setPersonDetails(firstNonNull(dsThunderheadInput.getPersonDetails(),
                OBJECT_FACTORY.createT2PersonDetails()));
        dsThunderheadInput.getPersonDetails().getPersonDetails().add(personDetail);
        return this;
    }

    public PayloadBuilder withOwningBusiness(final String owningBusiness) {
        this.dsThunderheadInput.setOwningBusiness(owningBusiness);
        return this;
    }

    public PayloadBuilder withTradeDomain(final String tradeDomain) {
        final Trade originalTrade = getTradeIfPresent(firstNonNull(dsThunderheadInput.getGbom(), new Gbom()));
        final Trade trade = firstNonNull(originalTrade, getSkeletonTrade());
        this.dsThunderheadInput.getGbom().setAny(trade);

        final TTradeHeader originalTradeHeader = trade.getTradeHeader();
        final TTradeHeader tradeHeader = firstNonNull(originalTradeHeader, new TTradeHeader());
        trade.setTradeHeader(tradeHeader);

        tradeHeader.setTradeDomain(tradeDomain);
        return this;
    }

    public PayloadBuilder noAgreements() {
        final Trade trade = firstNonNull(getTradeIfPresent(dsThunderheadInput.getGbom()), new Trade());
        trade.setAgreement(null);
        return this;
    }

    public PayloadBuilder emptyAgreement() {
        final Trade trade = firstNonNull(getTradeIfPresent(dsThunderheadInput.getGbom()), new Trade());
        this.dsThunderheadInput.getGbom().setAny(trade);
        trade.setAgreement(new TAgreement());
        return this;
    }

    public PayloadBuilder withConfirmationProcessing(String comments, boolean breakStp,
            TBooleanConditionTypeEnum booleanConditionType, boolean booleanCondition) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom())
                .getTradeHeader()
                .getPartyTradeData()
                .withConfirmationProcessing(
                        OBJECT_FACTORY
                                .createTConfirmData()
                                .withBreakSTP(breakStp)
                                .withProcessingComments(
                                        OBJECT_FACTORY
                                                .createTProcessingComments()
                                                .withOperationalPurpose(
                                                        randomFrom(TOprationalProcessingPurposeEnum.class))
                                                .withProcessingPurpose(TProcessingPurposeEnum.RM_INTERNAL)
                                                .withCommentText(comments))
                                .withBooleanConditions(
                                        OBJECT_FACTORY.createTBooleanCondition()
                                                .withBooleanConditionType(booleanConditionType)
                                                .withBoolean(booleanCondition)));
        return this;
    }

    public PayloadBuilder withTradeLeg(final int offsetDays, final TValueTypeEnum valueType,
            final int contractInitialValue) {
        establishTrade();
        final Trade trade = getTradeIfPresent(dsThunderheadInput.getGbom());
        final TProduct product = firstNonNull(trade.getProduct(), new TProduct());
        trade.setProduct(product);

        final TTradeLeg tradeLeg =
                OBJECT_FACTORY
                        .createTTradeLeg()
                        .withContractValues(
                                OBJECT_FACTORY.createTContractValue()
                                        .withValueType(OBJECT_FACTORY.createTValueType().withValue(valueType))
                                        .withInitialValue(valueOf(contractInitialValue)))
                        .withEventDateSchedules(
                                OBJECT_FACTORY.createTEventDateSchedule()
                                        .withOffsetDays(BigInteger.valueOf(offsetDays)).withDayType("Business")

                        ).withLegType(OBJECT_FACTORY.createTLegType().withValue(randomFrom(TLegTypeEnum.class)));
        product.getTradeLegs().add(tradeLeg);
        return this;
    }

    public PayloadBuilder withAutomaticExercise(boolean automaticExercise) {
        establishTrade();
        final Trade trade = getTradeIfPresent(dsThunderheadInput.getGbom());
        final TProduct product =
                firstNonNull(trade.getProduct(), new TProduct()).withOptions(
                        OBJECT_FACTORY.createTOption().withOptionType(TOptionType.AVERAGING)
                                .withAutomaticExercise(automaticExercise));
        trade.setProduct(product);

        return this;
    }

    public PayloadBuilder withNoTradeEventType() {
        this.dsThunderheadInput.setTradeEventType(null);
        return this;
    }

    public PayloadBuilder withTradeEventTypeAndReferenceDataKey(final String domain, final String referenceDataKey) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom()).getEvent().withEventTypes(
                OBJECT_FACTORY.createTReferenceDataKey().withDomain(TDomain.fromValue(domain))
                        .withReferenceDatakey(referenceDataKey));
        return this;
    }

    public PayloadBuilder withBusinessEventId(final String businessEventId) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom()).getEvent().withPartyEventData(
                OBJECT_FACTORY.createTPartyEventData().withBusinessIds(
                        OBJECT_FACTORY.createTBusinessId().withIdentifierType(TIdentifierType.RM_EVENT)
                                .withIdentifierValue(businessEventId)));
        return this;
    }

    public PayloadBuilder withCoreProcessingTradeId(final String coreProcessingTradeId) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom()).getTradeHeader().withCoreProcessingTradeId(
                coreProcessingTradeId);
        return this;
    }

    public PayloadBuilder withTradeVersion(final Integer version) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom()).getTradeHeader().withVersion(BigInteger.valueOf(version));
        return this;
    }

    public PayloadBuilder withTradeVersion(final Integer version, String tradeReference) {
        establishTrade();
        getTradeIfPresent(dsThunderheadInput.getGbom())
                .getTradeHeader()
                .getPartyTradeData()
                .withBusinessIds(
                        OBJECT_FACTORY.createTBusinessId().withVersion(new BigInteger(version.toString()))
                                .withIdentifierType(TIdentifierType.CORE_PROCESSING_TRADE)
                                .withIdentifierValue(tradeReference));
        return this;
    }

    public PayloadBuilder withTrade(final Trade trade) {
        this.dsThunderheadInput.getGbom().setAny(trade);
        return this;
    }

    public PayloadBuilder withProductEnrichment(final T2ProductEnrichment productEnrichment) {
        this.dsThunderheadInput.setProductEnrichment(productEnrichment);
        return this;
    }

    public PayloadBuilder withClientContacts(T2ClientContacts value) {
        this.dsThunderheadInput.setClientContacts(value);
        return this;
    }

    public DsThunderheadInput build() {
        return dsThunderheadInput;
    }

    private Trade establishTrade() {
        final Trade originalTrade = getTradeIfPresent(firstNonNull(dsThunderheadInput.getGbom(), new Gbom()));
        final Trade trade = firstNonNull(originalTrade, getSkeletonTrade());
        dsThunderheadInput.getGbom().setAny(trade);
        return trade;
    }

    private void establishProductEnrichment() {
        dsThunderheadInput.setProductEnrichment(firstNonNull(dsThunderheadInput.getProductEnrichment(),
                OBJECT_FACTORY.createT2ProductEnrichment()));
    }

    public static TReferenceDataKey referenceDataKey(final String domain, final String referenceDatakey) {
        return referenceDataKey(TDomain.fromValue(domain), referenceDatakey);
    }

    public static TReferenceDataKey referenceDataKey(final TDomain domain, final String referenceDatakey) {
        return new TReferenceDataKey().withDomain(domain).withReferenceDatakey(referenceDatakey);
    }

    public PayloadBuilder withGbom(final Gbom gbom) {
        this.dsThunderheadInput.withGbom(gbom);
        return this;
    }

    public PayloadBuilder withOwningSubBusiness(String owningSubBusiness) {
        this.dsThunderheadInput.setOwningSubBusiness(owningSubBusiness);
        return this;
    }
}

package com.jpmorgan.dcpp.commons.test;

import com.jpmorgan.dcpp.commons.Factory;
import com.jpmorgan.dcpp.commons.test.GetterAndSetterTester;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jpmorgan.dcpp.commons.Randoms.randomInt;


public class GetterAndSetterTesterTest {

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void testRunWithGoodBean() throws Exception {
        final Factory<Void, GoodBean> goodBeanFactory = new Factory<Void, GoodBean>() {
            @Override
            public GoodBean create(Void vo1d) {
                return new GoodBean();
            }
        };

        new GetterAndSetterTester<GoodBean>(goodBeanFactory).run();
    }

    @Test(expected = AssertionError.class)
    public void testRunWithBadBean() throws Exception {
        final Factory<Void, BadBean> badBeanFactory = new Factory<Void, BadBean>() {
            @Override
            public BadBean create(Void vo1d) {
                return new BadBean();
            }
        };

        new GetterAndSetterTester<BadBean>(badBeanFactory).run();
    }

    @Test
    public void testRunWithNoSettersBean() throws Exception {
        final Factory<Void, NoSettersBean> noSettersBeanFactory = new Factory<Void, NoSettersBean>() {
            @Override
            public NoSettersBean create(Void vo1d) {
                return new NoSettersBean();
            }
        };

        new GetterAndSetterTester<NoSettersBean>(noSettersBeanFactory).run();
    }

    @Test
    public void testRunWithNoGettersBean() throws Exception {
        final Factory<Void, NoGettersBean> noGettersBeanFactory = new Factory<Void, NoGettersBean>() {
            @Override
            public NoGettersBean create(Void vo1d) {
                return new NoGettersBean();
            }
        };

        new GetterAndSetterTester<NoGettersBean>(noGettersBeanFactory).run();
    }

    @Test
    public void testRunWithComplexObjectsBean() throws Exception {
        final Factory<Void, ComplexObjectsBean> complexObjectsBeanFactory = new Factory<Void, ComplexObjectsBean>() {
            @Override
            public ComplexObjectsBean create(Void vo1d) {
                return new ComplexObjectsBean();
            }
        };
        final Factory<Void, int[]> intArrayFactory = new Factory<Void, int[]>() {
            @Override
            public int[] create(Void vo1d) {
                return new int[]{randomInt()};
            }
        };
        Map<Class<?>, Factory<Void, ?>> nonStandardFactories = new HashMap<Class<?>, Factory<Void, ?>>() {
            {
                put(int[].class, intArrayFactory);
            }
        };
        new GetterAndSetterTester<ComplexObjectsBean>(complexObjectsBeanFactory,
                Collections.<String>emptyList(), nonStandardFactories).run();
    }

    //utils
    private static class GoodBean {
        private int a;
        private long b;

        public long getB() {
            return b;
        }

        public void setB(long b) {
            this.b = b;
        }

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }
    }

    private static class BadBean {
        private int a;
        private int b;

        public int getB() {
            //here it is misbehaving, this is why it is a bad bean
            return a;
        }

        public void setB(int b) {
            this.b = b;
        }

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }
    }

    private static class NoSettersBean {
        private int a;
        private int b;

        public int getB() {
            return b;
        }

        public int getA() {
            return a;
        }
    }

    private static class NoGettersBean {
        private int a;
        private long b;

        public void setB(long b) {
            this.b = b;
        }

        public void setA(int a) {
            this.a = a;
        }
    }

    private static class ComplexObjectsBean {
        private GoodBean a;
        private long b;
        private List<String> c;
        private int[] d;
        private byte[] bs;
        private String[] ss;

        public int[] getD() {
            return d;
        }

        public void setD(int[] d) {
            this.d = d;
        }

        public List<String> getC() {
            return c;
        }

        public void setC(List<String> c) {
            this.c = c;
        }

        public long getB() {
            return b;
        }

        public void setB(long b) {
            this.b = b;
        }

        public GoodBean getA() {
            return a;
        }

        public void setA(GoodBean a) {
            this.a = a;
        }

        public byte[] getBs() {
            return bs;
        }

        public void setBs(final byte[] bs) {
            this.bs = bs;
        }

        public String[] getSs() {
            return ss;
        }

        public void setSs(final String[] ss) {
            this.ss = ss;
        }
    }

}

package com.jpmorgan.dcpp.commons.caching.impl;

import com.jpmorgan.dcpp.commons.caching.CacheService;
import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
import org.slf4j.Logger;

import java.util.UUID;

import static com.jpmorgan.dcpp.commons.Objects.isNotNull;


public class CacheServiceImpl<K,V> implements CacheService<K, V> {

    private static final String DEFAULT_EHCACHE_CACHE_NAME = "default-ehcache";

    private static final transient Logger LOG = Slf4jLoggerFactory.create();

    private final Cache cache;

    /**
     * @param cacheName
     */
    public CacheServiceImpl(final String cacheName) {
        LOG.info("creating cache {}", cacheName);
        CacheConfiguration cacheConfiguration = new CacheConfiguration()
                .name(cacheName)
                .maxEntriesLocalHeap(1000)
                .timeToIdleSeconds(240)
                .timeToLiveSeconds(48)
                .persistence(new PersistenceConfiguration().strategy(PersistenceConfiguration.Strategy.NONE))
                .memoryStoreEvictionPolicy(MemoryStoreEvictionPolicy.LRU);
        cache = new Cache(cacheConfiguration);
        CacheManager.create().addCacheIfAbsent(cache);
    }

    public CacheServiceImpl(){
        this(DEFAULT_EHCACHE_CACHE_NAME + UUID.randomUUID());
    }

    @Override
    public void put(final K key, final V value) {
        final Element e = new Element(key, value);
        cache.put(e);
        LOG.debug("Cache Item Added {}", cache.getName());
    }

    @Override
    public void clear() {
        cache.removeAll();
        LOG.debug("Cache Cleared {}", cache.getName());
    }

    @Override
    public V get(final K key) {
            final Element element = cache.get(key);
            return isNotNull(element) ? (V)element.getObjectValue() : null;
    }

    @Override
    public boolean remove(final Object key) {
        return cache.remove(key);
    }
}

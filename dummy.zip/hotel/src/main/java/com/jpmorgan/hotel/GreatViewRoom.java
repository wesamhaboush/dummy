package com.jpmorgan.hotel;

public class GreatViewRoom extends AbstractRoom implements Room {
    private final static Room SUITE_ROOM = new SuiteRoom(null);

    public GreatViewRoom(final String id) {
        super(id);
    }

    @Override
    public double calculatePrice(final Facility... facilities) {
        return 2 * SUITE_ROOM.calculatePrice(facilities);
    }
}

package com.jpmorgan.dcpp.commons;

import static com.jpmorgan.dcpp.commons.Randoms.*;
import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.junit.Assert.assertEquals;

import com.jpmorgan.dcpp.commons.Hashcode;
import org.junit.Test;

public class HashcodeTest {

    @Test
    public void testHashForBoolean() {
        final boolean bool1 = true;
        final boolean bool2 = false;

        assertEquals(Hashcode.hash(Hashcode.SEED, bool1), Hashcode.hash(Hashcode.SEED, bool1));
        assertEquals(Hashcode.hash(Hashcode.SEED, bool2), Hashcode.hash(Hashcode.SEED, bool2));
    }

    @Test
    public void testHashForChar() {
        final char char1 = randomChar();

        assertEquals(Hashcode.hash(Hashcode.SEED, char1), Hashcode.hash(Hashcode.SEED, char1));
    }

    @Test
    public void testHashForInt() {
        final char char1 = randomChar();

        assertEquals(Hashcode.hash(Hashcode.SEED, char1), Hashcode.hash(Hashcode.SEED, char1));
    }

    @Test
    public void testHashForByte() {
        final byte byte1 = randomByte();

        assertEquals(Hashcode.hash(Hashcode.SEED, byte1), Hashcode.hash(Hashcode.SEED, byte1));
    }

    @Test
    public void testHashForShort() {
        final short short1 = randomShort();

        assertEquals(Hashcode.hash(Hashcode.SEED, short1), Hashcode.hash(Hashcode.SEED, short1));
    }

    @Test
    public void testHashForLong() {
        final long long1 = randomLong();

        assertEquals(Hashcode.hash(Hashcode.SEED, long1), Hashcode.hash(Hashcode.SEED, long1));
    }

    @Test
    public void testHashForFloat() {
        final float float1 = randomFloat();

        assertEquals(Hashcode.hash(Hashcode.SEED, float1), Hashcode.hash(Hashcode.SEED, float1));
    }

    @Test
    public void testHashWithIntAndDouble() {
        final double double1 = randomDouble();

        assertEquals(Hashcode.hash(Hashcode.SEED, double1), Hashcode.hash(Hashcode.SEED, double1));
    }

    @Test
    public void testHashWithIntAndGenericType() {
        final Object object1 = new Object();

        assertEquals(Hashcode.hash(Hashcode.SEED, object1), Hashcode.hash(Hashcode.SEED, object1));
        assertEquals(Hashcode.hash(Hashcode.SEED, null), Hashcode.hash(Hashcode.SEED, null));
    }

    @Test
    public void testHashArray() {
        //given
        final String[] nullArray1 = null;
        final String[] nullArray2 = null;

        final String[] emptyArray1 = new String[]{};
        final String[] emptyArray2 = new String[]{};

        final String[] nonEmptyArray1 = randomArray(String[].class, randomStringFactory(nextInt(1,10)), nextInt(1,10));
        final String[] nonEmptyArray2 = new String[nonEmptyArray1.length];
        System.arraycopy(nonEmptyArray1, 0, nonEmptyArray2, 0, nonEmptyArray1.length);

        //then
        assertEquals(Hashcode.hashArray(Hashcode.SEED, nullArray1), Hashcode.hashArray(Hashcode.SEED, nullArray2));
        assertEquals(Hashcode.hashArray(Hashcode.SEED, emptyArray1), Hashcode.hashArray(Hashcode.SEED, emptyArray2));
        assertEquals(Hashcode.hashArray(Hashcode.SEED, nonEmptyArray1), Hashcode.hashArray(Hashcode.SEED, nonEmptyArray2));
    }

}

package com.jpmorgan.ibtcp.dcpp.xquery;

import org.apache.commons.io.IOUtils;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLUnit;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.oxm.UnmarshallingFailureException;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.xml.sax.SAXException;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringWriter;

import static com.jpmorgan.dcpp.commons.Xmls.xml;
import static junit.framework.TestCase.assertEquals;
import static org.apache.commons.lang3.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang3.builder.HashCodeBuilder.reflectionHashCode;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class XStreamTest {
    @Test
    public void testNonTolerantXStreamWithAllFieldsCovered() throws IOException, SAXException {
        //given
        final String fullXmlForPerson =
                xml()
                        .start("person")
                            .start("address")
                                .child("city", "bournemouth")
                            .end()
                        .child("age", "100000")
                .closeAndGet();


        //when
        final XStreamMarshaller xStream = new XStreamMarshaller();
        xStream.getXStream().alias(Person.class.getSimpleName().toLowerCase(), Person.class);
        xStream.getXStream().alias(Address.class.getSimpleName().toLowerCase(), Address.class);
        final Person person = Person.class.cast(xStream.unmarshal(new StreamSource(IOUtils.toInputStream(fullXmlForPerson))));

        //then
        assertNotNull(person);
        assertEquals(person("bournemouth", 100000), person);
        final StringWriter writer = new StringWriter();
        xStream.marshal(person("bournemouth", 100000), new StreamResult(writer));
        final String result = writer.toString();
        final Diff diff = new Diff(fullXmlForPerson, result);
        assertTrue(diff.similar());
    }

    @Test(expected = UnmarshallingFailureException.class)
    public void testNonTolerantXStreamWithExtraElements() throws IOException {
        //given
        final String fullXmlForPerson =
                xml()
                    .start("person")
                       .start("address")
                           .child("city", "bournemouth")
                       .end()
                            .child("age", "100000")
                        .closeAndGet();

        final String partialXmlForPerson =
                    xml()
                        .start("person")
                            .child("age", "100000")
                        .closeAndGet();


        //when
        final XStreamMarshaller xStream = new XStreamMarshaller();
        xStream.getXStream().alias(Person.class.getSimpleName().toLowerCase(), PartialPerson.class);
        final PartialPerson partialPerson = PartialPerson.class.cast(xStream.unmarshal(new StreamSource(IOUtils.toInputStream(fullXmlForPerson))));

        //then
        assertNotNull(partialPerson);
        assertEquals(partialPerson(100000), partialPerson);
        final StringWriter writer = new StringWriter();
        xStream.marshal(partialPerson(100000), new StreamResult(writer));
        assertEquals(removeWhitespace(partialXmlForPerson), removeWhitespace(writer.toString()));
    }

    @Test
    public void testTolerantXStreamWithExtraElements() throws IOException {
        //given
        final String fullXmlForPerson =
                xml()
                        .start("person")
                        .start("address")
                        .child("city", "bournemouth")
                        .end()
                        .child("age", "100000")
                        .closeAndGet();

        final String partialXmlForPerson =
                xml()
                        .start("person")
                        .child("age", "100000")
                        .closeAndGet();


        //when
        final XStreamMarshaller xStream = new XStreamMarshaller();
        xStream.getXStream().ignoreUnknownElements();
        xStream.getXStream().alias(Person.class.getSimpleName().toLowerCase(), PartialPerson.class);
        final PartialPerson partialPerson = PartialPerson.class.cast(xStream.unmarshal(new StreamSource(IOUtils.toInputStream(fullXmlForPerson))));

        //then
        assertNotNull(partialPerson);
        assertEquals(partialPerson(100000), partialPerson);
        final StringWriter writer = new StringWriter();
        xStream.marshal(partialPerson(100000), new StreamResult(writer));
        assertEquals(removeWhitespace(partialXmlForPerson), removeWhitespace(writer.toString()));
    }

    //utils

    private PartialPerson partialPerson(final int age) {
        return new PartialPerson(age);
    }

    private String removeWhitespace(final String s) {
        return s.replaceAll("\\s+", "");
    }

    private Person person(final String city, final int age) {
        final Address address = new Address(city);
        return new Person(address, age);
    }

    private static class Address {

        private String city;

        Address(final String city) {
            this.city = city;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Address{" +
                    "city='" + city + '\'' +
                    '}';
        }

    }
    private static class Person {

        private Address address;
        private int age;
        Person(final Address address, final int age) {
            this.address = address;
            this.age = age;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Person{" +
                    "address=" + address +
                    ", age=" + age +
                    '}';
        }

    }
    private static class PartialPerson {

        private int age;
        PartialPerson(final int age) {
            this.age = age;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Person{" +
                    "age=" + age +
                    '}';
        }

    }

    @BeforeClass
    public static void setUp() {
        XMLUnit.setIgnoreWhitespace(true);
    }
}

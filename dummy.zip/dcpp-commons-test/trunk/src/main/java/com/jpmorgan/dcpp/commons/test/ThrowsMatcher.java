package com.jpmorgan.dcpp.commons.test;

import org.apache.commons.lang3.Validate;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

import static com.jpmorgan.dcpp.commons.test.ExceptionAssert.assertThrowsExact;
import static java.lang.String.format;

public class ThrowsMatcher extends TypeSafeMatcher<Class<? extends Throwable>> {

    private final Runnable runnable;

    private ThrowsMatcher(final Runnable runnable) {
        Validate.notNull(runnable, "runnable is null and should not be");

        this.runnable = runnable;
    }

    @Override
    protected boolean matchesSafely(final Class<? extends Throwable> throwableClass) {
        try {
            assertThrowsExact(runnable, throwableClass);
            return true;
        } catch (AssertionError error) {
            return false;
        }
    }

    @Override
    public void describeTo(final Description description) {
        description.appendText(format("was not thrown by [%s]", runnable));
    }

    @Factory
    public static Matcher<Class<? extends Throwable>> isThrownBy(final Runnable runnable) {
        return new ThrowsMatcher(runnable);
    }
}

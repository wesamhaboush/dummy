package com.jpmorgan.dcpp.commons.xml;

import java.util.ArrayList;
import java.util.List;

/* package */ class DocType {

    private final List<String> entityDefs = new ArrayList<String>();
    private String publicId;
    private String systemId;

    public DocType(final String publicId, final String systemId) {
        this.publicId = publicId;
        this.systemId = systemId;
    }

    public void write(final XMLWriter out, final String rootElementName) {
        out.writeDocType(
            rootElementName, publicId, systemId, entityDefs);
    }

    public void entityDef(final String name, final String value) {
        entityDefs.add(name + " \"" + value + '"');
    }
}

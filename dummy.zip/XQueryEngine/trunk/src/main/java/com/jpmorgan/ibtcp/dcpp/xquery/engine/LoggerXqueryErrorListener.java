package com.jpmorgan.ibtcp.dcpp.xquery.engine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

public class LoggerXqueryErrorListener implements ErrorListener {
    private static final transient Logger LOGGER = LoggerFactory.getLogger(XQueryEngineImpl.class);
    @Override
    public void warning(TransformerException exception) throws TransformerException {
        LOGGER.warn("Warning in XQueryEngine", exception);
    }

    @Override
    public void error(TransformerException exception) throws TransformerException {
        LOGGER.error("Error in XQueryEngine", exception);
    }

    @Override
    public void fatalError(TransformerException exception) throws TransformerException {
        LOGGER.error("Fatal in XQueryEngine", exception);
    }

}

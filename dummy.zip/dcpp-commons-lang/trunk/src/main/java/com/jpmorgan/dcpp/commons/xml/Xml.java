package com.jpmorgan.dcpp.commons.xml;

import java.io.*;
import java.util.regex.Pattern;

import static com.google.common.base.Throwables.propagate;

public class Xml implements PrologOrXmlElement, XmlStartTag {

    public static final String MAC_LINE_SEPARATOR = "\n";
    public static final String UNIX_LINE_SEPARATOR = "\n";
    public static final String WINDOWS_LINE_SEPARATOR = "\r\n";

    private enum State { IN_PROLOG, IN_START_TAG, IN_ELEMENT, AFTER_ROOT }

    private final XMLWriter out;

    private ElementMetadata currentElementMetadata;

    private DocType docType;

    private State state = State.IN_PROLOG;

    private boolean xsltSpecified;

    private boolean verifyUsage = true;

    private boolean addFinalNewline;

    public Xml() { this(Version.UNSPECIFIED); }
    public Xml(Version version) {
        this(System.out, version);
        out.doNotCloseOutputStream(); // Don't close 'System.out'.
    }

    public Xml(OutputStream os) { this(os, Version.UNSPECIFIED); }
    public Xml(OutputStream os, Version version) {
        this(new OutputStreamWriter(os), version);
    }

    public Xml(String filePath) { this(filePath, Version.UNSPECIFIED); }
    public Xml(String filePath, Version version) {
        this(makeWriter(filePath), version);
    }

    public Xml(Writer writer) { this(writer, Version.UNSPECIFIED); }
    public Xml(Writer writer, Version version) {
        out = new XMLWriter(writer, version, verifyUsage);
        writeXMLDeclaration(version);
    }

    public Xml includeFinalNewline() { addFinalNewline = true; return this; }

    public Xml excludeFinalNewline() { addFinalNewline = false; return this; }

    public XmlStartTag attr(String name, Object value) {
        return attr(null, name, value);
    }

    public XmlStartTag attr(String prefix, String name, Object value) {
        return attr(prefix, name, value, out.isAttrOnNewLine());
    }

    public XmlStartTag attr(
        String prefix, String name, Object value, boolean newLine) {
        attr(prefix, name, value, newLine, true);
        return this;
    }

    private void attr(
        String prefix, String name, Object value,
        boolean newLine, boolean escape) {

        if (state != State.IN_START_TAG) badState("attr");

        currentElementMetadata.writeAttributeEqualsValue(prefix, name, value,
                newLine, escape);
    }

    private void badState(String methodName) {
        throw new IllegalStateException(
            "can't call " + methodName + " when state is " + state);
    }

    public XmlElement blankLine() {
        return text("", true);
    }

    public XmlElement cdata(String text) {
        return cdata(text, false);
    }

    public XmlElement cdata(String text, boolean newLine) {
        if (state == State.IN_PROLOG || state == State.AFTER_ROOT) {
            badState("cdata");
        }

        final String start = "<![CDATA[";
        final String end = "]]>";
        final String middle = text.replaceAll(
            Pattern.quote(end), "]]" + end + start + ">");
        text(start + middle + end, newLine, false);
        return this;
    }

    public XmlElement child(String name) {
        return start(name).end();
    }

    public XmlElement child(String name, String text) {
        return child(null, name, text);
    }

    public XmlElement child(String prefix, String name, String text) {
        if (state == State.AFTER_ROOT) badState("child");
        return start(prefix, name).text(text).end();
    }

    public void close() {
        if (out.isClosed()) throw new IllegalStateException("already closed");

        // Verify that a root element has been written and not yet ended.
        if (state == State.IN_PROLOG) badState("close");

        // End all the unended elements.
        while (currentElementMetadata != null) {
            end();
        }

        if ( addFinalNewline ) { out.writeln(); }

        out.close();
    }

    private void closeStartTag() {
        verifyOutstandingNamespacePrefixes();
        if (state != State.IN_START_TAG) return;

        currentElementMetadata.closeStartTag();
        state = State.IN_ELEMENT;
    }

    public PrologOrXmlElement comment(String text) {
        return comment(text, false);
    }

    public PrologOrXmlElement comment(String text, boolean newLine) {
        // Comments can be output in any state.
        if (verifyUsage) XMLUtil.verifyComment(text);

        closeStartTag();
        out.writeComment(text, newLine);
        return this;
    }

    public XmlStartTag commentedStart(String name) {
        return commentedStart(null, name);
    }

    public XmlStartTag commentedStart(String prefix, String name) {
        start(prefix, name, true);
        return this;
    }

    public XmlStartTag defaultNamespace(String uri) {
        return namespace("", uri);
    }

    public XmlStartTag defaultNamespace(String uri, String schemaPath) {
        return namespace("", uri, schemaPath);
    }

    public XmlStartTag defaultNS(String uri) {
        return defaultNamespace(uri);
    }

    public XmlStartTag defaultNS(String uri, String schemaPath) {
        return defaultNamespace(uri, schemaPath);
    }

    public PrologXml dtd(String systemId) {
        return dtd(null, systemId);
    }

    public PrologXml dtd(String publicId, String systemId) {
        if (docType != null) {
            throw new IllegalStateException("can't specify more than one DTD");
        }

        if (state != State.IN_PROLOG) badState("dtd");

        if (systemId == null) {
            throw new IllegalArgumentException(
                    "DTD 'system identifier' parameter must not be null.");
        }

        if (verifyUsage) XMLUtil.verifyURI(systemId);

        docType = new DocType(publicId, systemId);
        return this;
    }

    public XmlElement end() {
        return end(false);
    }

    public XmlElement end(boolean verbose) {
        if (state == State.IN_PROLOG || state == State.AFTER_ROOT) {
            badState("end");
        }

        if (state == State.IN_START_TAG) {
            verifyOutstandingNamespacePrefixes();
        }

        currentElementMetadata.writeEndTag(verbose);

        currentElementMetadata = currentElementMetadata.getParent();
        state = currentElementMetadata == null ?
            State.AFTER_ROOT : State.IN_ELEMENT;
        return this;
    }

    public PrologXml entityDef(String name, String value) {
        if (state != State.IN_PROLOG) badState("entity");

        if (docType == null) docType = new DocType(null, null);
        docType.entityDef(name, value);
        return this;
    }

    public PrologXml externalEntityDef(String name, String filePath) {
        return entityDef(name + " SYSTEM", filePath);
    }

    public String getIndent() {
        return out.getIndent();
    }

    public String getLineSeparator() {
        return out.getLineSeparator();
    }

    public String getSchemaVersion() {
        return out.getSchemaVersion();
    }

    public boolean isSpaceInEmptyElements() {
        return out.isSpaceInEmptyElements();
    }

    public boolean isTrustMe() {
        return !verifyUsage;
    }

    private static Writer makeWriter(String filePath) {
        try {
            return new FileWriter(filePath);
        } catch (IOException ioException) {
            throw propagate(ioException);
        }
    }

    public XmlStartTag namespace(String prefix, String uri) {
        return namespace(prefix, uri, null);
    }

    public XmlStartTag namespace(
        String prefix, String uri, String schemaPath) {

        if (state != State.IN_START_TAG) badState("namespace");

        currentElementMetadata.writeNamespaceDeclaration(
            prefix, uri, schemaPath);
        return this;
    }

    public XmlStartTag ns(String prefix, String uri) {
        return namespace(prefix, uri);
    }

    public XmlStartTag ns(
        String prefix, String uri, String schemaPath) {
        return namespace(prefix, uri, schemaPath);
    }

    public PrologOrXmlElement pi(String target, String data) {
        return processingInstruction(target, data);
    }

    public PrologOrXmlElement processingInstruction(
        String target, String data) {
        // Processing instructions can go anywhere
        // except inside element start tags and attribute values.

        // Provide special handling for the
        // "xml-stylesheet" processing instruction
        // since starting with "xml" is reserved.
        if (verifyUsage && !("xml-stylesheet").equals(target)) {
            XMLUtil.verifyName(target);
        }

        closeStartTag();
        out.writeProcessingInstruction(target, data);
        return this;
    }

    public void setIndent(String indent) {
        out.setIndent(indent);
    }

    public void setIndent(int numSpaces) {
        out.setIndent(numSpaces);
    }

    public void noIndentsOrLineSeparators() {
        setIndent(null);
    }

    public void setLineSeparator(String lineSeparator) {
        out.setLineSeparator(lineSeparator);
    }

    public void setSchemaVersion(String version) {
        out.setSchemaVersion(version);
    }

    public void setSpaceInEmptyElements(boolean spaceInEmptyElements) {
        out.setSpaceInEmptyElements(spaceInEmptyElements);
    }

    public void setTrustMe(boolean trustMe) {
        this.verifyUsage = !trustMe;
        out.setTrustMe(trustMe);
        if (currentElementMetadata != null)
            currentElementMetadata.setTrustMe(trustMe);
    }

    public XmlStartTag start(String name) {
        return start(null, name);
    }

    public XmlStartTag start(String prefix, String name) {
        start(prefix, name, false);
        return this;
    }

    private void start(String prefix, String name, boolean inCommentedStart) {
        closeStartTag();
        out.resetContentFlags();

        if (state == State.AFTER_ROOT) badState("start");

        final boolean isTheRootElement = (currentElementMetadata == null);
        if (isTheRootElement) writeDocType(name);

        currentElementMetadata = new ElementMetadata(
            out, verifyUsage, currentElementMetadata,
            prefix, name, inCommentedStart);
        currentElementMetadata.writeStartTagOpen(inCommentedStart);

        state = State.IN_START_TAG;
    }

    public XmlElement text(String text) {
        return text(text, false);
    }

    public XmlElement text(String text, boolean newLine) {
        text(text, newLine, true);
        return this;
    }

    private void text(String text, boolean newLine, boolean escape) {
        if (state == State.IN_PROLOG || state == State.AFTER_ROOT) {
            badState("text");
        }

        closeStartTag();
        out.writeText(text, newLine, escape);
    }

    public XmlStartTag unescapedAttr(String name, Object value) {
        return unescapedAttr("", name, value);
    }

    public XmlStartTag unescapedAttr(String prefix, String name, Object value) {
        return unescapedAttr(prefix, name, value, false);
    }

    public XmlStartTag unescapedAttr(
        String prefix, String name, Object value, boolean newLine) {
        attr(prefix, name, value, newLine, false);
        return this;
    }

    public XmlElement unescapedText(String text) {
        return unescapedText(text, false);
    }

    public XmlElement unescapedText(String text, boolean newLine) {
        text(text, newLine, false);
        return this;
    }

    private void verifyOutstandingNamespacePrefixes() {
        if (verifyUsage && currentElementMetadata != null) {
            currentElementMetadata.verifyOutstandingNamespacePrefixes();
        }
    }

    private void writeDocType(String rootElementName) {
        if (docType != null) {
            docType.write(out, rootElementName);
            docType = null; // release memory
        }
    }

    private void writeXMLDeclaration(Version version) {
        if (version == null) {
            throw new IllegalArgumentException("unsupported XML version");
        }

        if (version != Version.UNSPECIFIED) {
            out.writeXMLDeclaration(version.getVersionNumberString());
        }
    }

    public PrologXml xslt(String filePath) {
        if (xsltSpecified) {
            throw new IllegalStateException("can't specify more than one XSLT");
        }

        if (state != State.IN_PROLOG) badState("xslt");

        if (verifyUsage) XMLUtil.verifyURI(filePath);

        xsltSpecified = true;
        return processingInstruction(
            "xml-stylesheet", "type=\"text/xsl\" href=\"" + filePath + "\"");
    }
}

package com.jpmorgan.hotel;

import java.util.EnumMap;
import java.util.Map;

import static com.jpmorgan.hotel.Facility.*;

public class SuiteRoom extends AbstractRoom implements Room {
    private static final Map<Facility, Double> FACILITY_PRICE_MAP = new EnumMap<Facility, Double>(Facility.class){{
       put(ROOM_BREAKFAST, 5.0);
       put(ENSUITE_BATHROOM, 4.0);
       put(INTERNET, 2.0);
       put(LATE_CHECKOUT, 1.0);
       put(SWIMMINGPOOL, 1.0);
    }};

    public SuiteRoom(final String id) {
        super(id);
    }

    @Override
    public double calculatePrice(final Facility... facilities) {
        double fee = 0;
        for (Facility facility : facilities) {
            fee += calculatePriceFrom(facility);
        }
        return fee;
    }

    private double calculatePriceFrom(final Facility facility) {
        return firstNonNull( FACILITY_PRICE_MAP.get(facility), Double.valueOf(0.0) );
    }

    private static <T> T firstNonNull(final T t1, final T t2) {
        return t1 == null ? t2 : t1;
    }
}

package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.commons.Dates;
import com.jpmorgan.dcpp.commons.Xmls;
import com.jpmorgan.dcpp.la.model.generated.*;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.transform;
import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Dates.toXmlGregorianCalendar;
import static com.jpmorgan.dcpp.commons.Randoms.*;
import static com.jpmorgan.dcpp.la.model.generated.TCashSettlementMethod.CROSS_CURRENCY_METHOD;
import static com.jpmorgan.dcpp.la.model.generated.TDomain.PRODUCT_CLASSIFICATION;
import static com.jpmorgan.dcpp.la.model.generated.TLegTypeEnum.*;
import static com.jpmorgan.dcpp.la.model.generated.TValueTypeEnum.NOTIONAL;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.referenceDataKey;
import static java.util.Arrays.asList;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.lang3.StringUtils.join;
import static org.joda.time.DateTime.now;
import static org.junit.Assert.assertNull;

public class CcsEtMatrixRatesTest extends AbstractXqueryTest {
    private static final String CCS_ET_MATRIX_RATES_XQY = "PaperConfirmationBusinessRules/Rates/ccs-et-matrix-rates.xqy";
    private static final Set<? extends Set<String>> CURRENCY_PAIRS = newHashSet(
            newHashSet("CAD", "USD"),
            newHashSet("MXN", "USD"),
            newHashSet("AUD", "EUR"),
            newHashSet("AUD", "USD"),
            newHashSet("CHF", "EUR"),
            newHashSet("CHF", "PLN"),
            newHashSet("CHF", "USD"),
            newHashSet("CNY", "EUR"),
            newHashSet("CZK", "EUR"),
            newHashSet("CZK", "USD"),
            newHashSet("DKK", "EUR"),
            newHashSet("DKK", "USD"),
            newHashSet("EUR", "USD"),
            newHashSet("GBP", "EUR"),
            newHashSet("GBP", "USD"),
            newHashSet("HUF", "EUR"),
            newHashSet("HUF", "USD"),
            newHashSet("ILS", "USD"),
            newHashSet("NOK", "EUR"),
            newHashSet("NOK", "USD"),
            newHashSet("PLN", "EUR"),
            newHashSet("PLN", "USD"),
            newHashSet("SEK", "EUR"),
            newHashSet("SEK", "USD"),
            newHashSet("TRY", "EUR"),
            newHashSet("TRY", "USD"),
            newHashSet("ZAR", "EUR"),
            newHashSet("ZAR", "USD"),
            newHashSet("ZAR", "GBP"),
            newHashSet("HKD", "EUR"),
            newHashSet("HKD", "GBP"),
            newHashSet("HKD", "USD"),
            newHashSet("JPY", "USD"),
            newHashSet("KRW", "USD"),
            newHashSet("NZD", "USD"),
            newHashSet("SGD", "EUR"),
            newHashSet("SGD", "GBP"),
            newHashSet("SGD", "USD"),
            newHashSet("THB", "USD"),
            newHashSet("TWD", "USD")
    );

    private static final List<String> CURRENCIES = newArrayList(
            "TWD",
            "THB",
            "SGD",
            "NZD",
            "KRW",
            "JPY",
            "HKD",
            "ZAR",
            "TRY",
            "SEK",
            "PLN",
            "NOK",
            "ILS",
            "HUF",
            "GBP",
            "DKK",
            "CZK",
            "CNY",
            "PLN",
            "CHF",
            "EUR",
            "AUD",
            "MXN",
            "CAD",
            "USD"
    );

    private static final Set<String> STYLES = newHashSet("Bermudan", "European", "American");
    private static final String ISDA_NAME = "CCS_EARLY_TERMINATION_SETTLEMENT_STANDARD";
    private static final List<String> ALLOWED_DCODES = newArrayList("D193", "D495", "D627", "D628", "D1039", "D1040", "D1041",
            "D1042", "D1043", "D1044", "D1054", "D1059", "D1060", "D1066",
            "D1067", "D1088", "D1089", "D1091", "D1093", "D1094", "D1097",
            "D1121", "D1127", "D1129", "D1130", "D1131", "D1134", "D1137",
            "D1138", "D1141", "D1143", "D1144", "D1146", "D1175", "D1181",
            "D1197", "D1207", "D1208", "D1222", "D1224", "D1231", "D1235",
            "D1239", "D1241", "D1245", "D1249", "D1250", "D1251", "D1269",
            "D1275", "D1276", "D1277", "D154", "D155", "D157", "D193", "D194",
            "D195", "D196", "D197", "D199", "D200", "D2028", "D203", "D2034",
            "D2036", "D2037", "D2039", "D204", "D2051", "D2052", "D2053",
            "D206", "D2060", "D207", "D2078", "D2087", "D2088", "D2089",
            "D209", "D2090", "D2091", "D2092", "D2093", "D2094", "D2095",
            "D2108", "D2110", "D2115", "D2122", "D2125", "D2126", "D2132",
            "D2135", "D2143", "D2152", "D2153", "D2162", "D2163", "D2165",
            "D358", "D399", "D403", "D405", "D412", "D414", "D416", "D418",
            "D419", "D421", "D436", "D440", "D457", "D458", "D459", "D474",
            "D475", "D482", "D485", "D486", "D488", "D489", "D493", "D495",
            "D502", "D517", "D520", "D522", "D525", "D621", "D623", "D624",
            "D625", "D627", "D628", "D630", "D631", "D632", "D718", "D719",
            "D721", "D722", "D727", "D781", "D783", "D784", "D785", "D787",
            "D789", "D790", "D791", "D792", "D793", "D794", "D795", "D796",
            "D797", "D798", "D799", "D927", "D977", "D982");
    public static final Function<String, TContractValue> TO_CONTRACT_VALUES = new Function<String, TContractValue>() {

        @Override
        public TContractValue apply(final String currency) {
            return new TContractValue().withValueType(new TValueType().withValue(NOTIONAL)).withCurrency(referenceDataKey(":erd.currency", currency));
        }
    };
    public static final Function<String, TReferenceDataKey> STRING_T_REFERENCE_DATA_KEY_FUNCTION = new Function<String, TReferenceDataKey>() {
        @Override
        public TReferenceDataKey apply(final String businessDaysCenterId) {
            return referenceDataKey(":fpml.business-center", businessDaysCenterId);
        }
    };

    @Test
    public void whenDcodeIsNotInList_NoIsdaShouldCreated() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomNotIn(randomAlphanumericFactory(4), ALLOWED_DCODES);
        final String currency1 = randomFrom(CURRENCIES);
        final String currency2 = currency1;
        final String optionStyle = randomFrom(STYLES);
        final String exerciseBusinessCenterId = "MXMC";
        final String expiryBusinessCenterId = "GBLO";
        final String pricingBusinessCenterId = "USN";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar expiryTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = randomFrom(TQuotationSide.class);
        final String cashSettlementCurrency = randomAlphanumeric(10);
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                exerciseBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        assertNull(getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenCurrenciesAreSame_NotIsdaPair_NotAdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = randomFrom(CURRENCIES);
        final String currency2 = currency1;
        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;
        final String optionStyle = randomFrom(STYLES);
        final String exerciseBusinessCenterId = "MXMC";
        final String expiryBusinessCenterId = "GBLO";
        final String pricingBusinessCenterId = "USN";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar expiryTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = randomFrom(TQuotationSide.class);
        final String cashSettlementCurrency = randomAlphanumeric(10);
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                exerciseBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }


    @Test
    public void whenNoSpecificRules_NotIsdaPair_NotAdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final Iterator<String> noSpecificRuleCurrencyPair = getNoRulesCurrencyCombination().iterator();
        final String currency1 = noSpecificRuleCurrencyPair.next();
        final String currency2 = noSpecificRuleCurrencyPair.next();
        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;
        final String optionStyle = randomFrom(STYLES);
        final String exerciseBusinessCenterId = "MXMC";
        final String expiryBusinessCenterId = "GBLO";
        final String pricingBusinessCenterId = "USN";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar expiryTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = randomFrom(TQuotationSide.class);
        final String cashSettlementCurrency = randomAlphanumeric(10);
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                exerciseBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenMoreThan2Currencies_NotIsdaPair_NotAdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final List<String> currencies = newArrayList(randomSetFrom(randomInt(3, 8), CURRENCIES));
        final boolean isdaCurrencyPair = false;
        final boolean isAdheredTo = false;
        final String optionStyle = randomFrom(STYLES);
        final String exerciseBusinessCenterId = "MXMC";
        final String expiryBusinessCenterId = "GBLO";
        final String pricingBusinessCenterId = "USN";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar expiryTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar pricingTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = randomFrom(TQuotationSide.class);
        final String cashSettlementCurrency = randomAlphanumeric(10);
        final Trade trade = createTrade(
                productClassification,
                currencies,
                optionStyle,
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                exerciseBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currencies, "/")).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currencies), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenNoFloatingFormula_BermudanStyle_isCcsEt_NotAdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "MXN";
        final String currency2 = "USD";
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;
        final String optionStyle = "Bermudan";
        final String exerciseBusinessCenterId = "USNY";
        final String expiryBusinessCenterId = "USNY";
        final String pricingBusinessCenterId = "USNY";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String expiryOffsetInterval = "-P5D";
        final String exerciseValuationOffsetInterval = "-P1D";
        final String exerciseSettlementOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(12, 30);
        final XMLGregorianCalendar pricingTime = xmlTime(12, 30);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                asList(exerciseBusinessCenterId),
                exerciseBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    /**
     * <object>
     <currencies>
     <currency>CAD</currency>
     <currency>USD</currency>
     </currencies>
     <index>USD-LIBOR-BBA</index>
     <index>USD-LIBOR-BBA-Bloomburg</index>
     <index>USD-LIBOR-ISDA</index>
     <index>USD-LIBOR-LIBO</index>
     <index>USD-LIBOR-Reference Banks</index>
     <method>Cross Currency Method</method>
     <businessDays>
     <center>CATO</center>
     <center>GBLO</center>
     <center>USNY</center>
     </businessDays>
     <expireDateOffset>-P5D</expireDateOffset>
     <cashValuationDate>-P2D</cashValuationDate>
     <businessCentre>CATO</businessCentre>
     <earliestExerciseTime>09:00:00.000Z</earliestExerciseTime>
     <latestExerciseTime>16:00:00.000Z</latestExerciseTime>
     <valuationTime>16:00:00.000Z</valuationTime>
     <quoteRate>Mid</quoteRate>
     <cashSettlementCcy>USD</cashSettlementCcy>
     </object>
     * @throws SaxonApiException
     * @throws IOException
     * @throws XPathExpressionException
     * @throws DatatypeConfigurationException
     * @throws SAXException
     * @throws TransformerException
     * @throws ParserConfigurationException
     */
    @Test
    public void whenNoFloatingFormula_CAD_USD_BermudanStyle_isCcsEt_AdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "CAD";
        final String currency2 = "USD";
        final String optionStyle = "Bermudan";
        final List<String> exerciseBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final List<String> expiryBusinessCenterIds = asList("USNY");
        final List<String> valuationBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final String exerciseLocationBusinessCenterId = "CATO";
        final String expiryBusinessCenterId = "CATO";
        final String pricingBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String exerciseSettlementOffsetInterval = "-P5D";
        final String expiryOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = "-P2D";
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(16, 0);
        final XMLGregorianCalendar pricingTime = xmlTime(16, 0);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                exerciseBusinessCenterIds,
                expiryBusinessCenterIds,
                valuationBusinessCenterIds,
                exerciseLocationBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenNoFloatingFormula_CAD_USD_AmericanEuropeanStyle_isCcsEt_AdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "CAD";
        final String currency2 = "USD";
        final String optionStyle = randomFrom("American", "European");
        final List<String> exerciseBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final List<String> expiryBusinessCenterIds = asList("USNY");
        final List<String> valuationBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final String exerciseLocationBusinessCenterId = "CATO";
        final String expiryBusinessCenterId = "CATO";
        final String pricingBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String expiryOffsetInterval = "-P5D";
        final String exerciseValuationOffsetInterval = "-P2D";
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(16, 0);
        final XMLGregorianCalendar pricingTime = xmlTime(16, 0);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                exerciseBusinessCenterIds,
                expiryBusinessCenterIds,
                valuationBusinessCenterIds,
                exerciseLocationBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenKnownConfiguredFloatingFormula_CAD_USD_AmericanEuropeanStyle_isCcsEt_AdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "CAD";
        final String currency2 = "USD";
        final String optionStyle = randomFrom("American", "European");
        final List<String> exerciseBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final List<String> expiryBusinessCenterIds = asList("USNY");
        final List<String> valuationBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final String exerciseLocationBusinessCenterId = "CATO";
        final String expiryBusinessCenterId = "CATO";
        final String pricingBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String expiryOffsetInterval = "-P5D";
        final String exerciseValuationOffsetInterval = "-P2D";
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(16, 0);
        final XMLGregorianCalendar pricingTime = xmlTime(16, 0);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final String floatingRateFormula = randomFrom(
                "USD-LIBOR-BBA",
                "USD-LIBOR-BBA-Bloomburg",
                "USD-LIBOR-ISDA",
                "USD-LIBOR-LIBO",
                "USD-LIBOR-Reference Banks");
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                exerciseBusinessCenterIds,
                expiryBusinessCenterIds,
                valuationBusinessCenterIds,
                exerciseLocationBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        trade.getProduct().getTradeLegs().add(
                new TTradeLeg()
                        .withLegType(
                                new TLegType()
                                        .withValue(TLegTypeEnum.FLOATING_INTEREST_RATE)
                        ).withFloatingFormula(
                        new TFloatingFormula()
                                .withFormulaTypes(new TFormulaType().withValue(TFormulaTypeEnum.FLOATING_INTEREST))
                                .withObservations(
                                        new TObservation()
                                                .withObservationType(new TObservationType().withValue(TObservationTypeEnum.FLOATING_RATE_RESET))
                                                .withFloatingRateIndices(referenceDataKey(TDomain.FPML_FLOATING_RATE_INDEX, floatingRateFormula)))
                )
        );
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void withUnKnownConfiguredFloatingFormula_CAD_USD_AmericanEuropeanStyle_isCcsEt_AdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "CAD";
        final String currency2 = "USD";
        final String optionStyle = randomFrom("American", "European");
        final List<String> exerciseBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final List<String> expiryBusinessCenterIds = asList("USNY");
        final List<String> valuationBusinessCenterIds = asList("GBLO", "CATO", "USNY");
        final String exerciseLocationBusinessCenterId = "CATO";
        final String expiryBusinessCenterId = "CATO";
        final String pricingBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String expiryOffsetInterval = "-P5D";
        final String exerciseValuationOffsetInterval = "-P2D";
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(16, 0);
        final XMLGregorianCalendar pricingTime = xmlTime(16, 0);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final String floatingRateFormula = randomNotIn(randomAlphanumericFactory(randomInt(1, 30)), asList(
                "USD-LIBOR-BBA",
                "USD-LIBOR-BBA-Bloomburg",
                "USD-LIBOR-ISDA",
                "USD-LIBOR-LIBO",
                "USD-LIBOR-Reference Banks"));
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                exerciseBusinessCenterIds,
                expiryBusinessCenterIds,
                valuationBusinessCenterIds,
                exerciseLocationBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        trade.getProduct().getTradeLegs().add(
                new TTradeLeg()
                        .withLegType(
                                new TLegType()
                                        .withValue(TLegTypeEnum.FLOATING_INTEREST_RATE)
                        ).withFloatingFormula(
                        new TFloatingFormula()
                                .withFormulaTypes(new TFormulaType().withValue(TFormulaTypeEnum.FLOATING_INTEREST))
                                .withObservations(
                                        new TObservation()
                                                .withObservationType(new TObservationType().withValue(TObservationTypeEnum.FLOATING_RATE_RESET))
                                                .withFloatingRateIndices(referenceDataKey(TDomain.FPML_FLOATING_RATE_INDEX, floatingRateFormula)))
                )
        );
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void withUnKnownConfiguredFloatingFormula_MXN_USD_AmericanEuropeanStyle_isCcsEt_AdheredTo() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final String xqueryModule = loadModuleAsString(CCS_ET_MATRIX_RATES_XQY);
        final String productClassification = randomFrom(ALLOWED_DCODES);
        final String currency1 = "CAD";
        final String currency2 = "USD";
        final String optionStyle = randomFrom("American", "European");
        final List<String> exerciseBusinessCenterIds = asList("GBLO", "MXMC", "USNY");
        final List<String> expiryBusinessCenterIds = asList("USNY");
        final List<String> valuationBusinessCenterIds = asList("GBLO", "MXMC", "USNY");
        final String exerciseLocationBusinessCenterId = "USNY";
        final String expiryBusinessCenterId = "USNY";
        final String pricingBusinessCenterId = "USNY";
        final TCashSettlementMethod cashSettlementMethod = CROSS_CURRENCY_METHOD;
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String expiryOffsetInterval = "-P5D";
        final String exerciseValuationOffsetInterval = "-P1D";
        final XMLGregorianCalendar exerciseTime = xmlTime(9, 0);
        final XMLGregorianCalendar expiryTime = xmlTime(12, 30);
        final XMLGregorianCalendar pricingTime = xmlTime(12, 30);
        final XMLGregorianCalendar tradeDate = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final TQuotationSide quotationSide = TQuotationSide.MID;
        final String cashSettlementCurrency = "USD";
        final String floatingRateFormula = randomAlphanumeric(randomInt(2, 30));
        final Trade trade = createTrade(
                productClassification,
                newArrayList(currency1, currency2),
                optionStyle,
                exerciseBusinessCenterIds,
                expiryBusinessCenterIds,
                valuationBusinessCenterIds,
                exerciseLocationBusinessCenterId,
                expiryBusinessCenterId,
                pricingBusinessCenterId,
                cashSettlementMethod,
                exerciseSettlementOffsetInterval,
                expiryOffsetInterval,
                exerciseValuationOffsetInterval,
                exerciseTime,
                expiryTime,
                pricingTime,
                tradeDate,
                quotationSide,
                cashSettlementCurrency);
        trade.getProduct().getTradeLegs().add(
                new TTradeLeg()
                        .withLegType(
                                new TLegType()
                                        .withValue(TLegTypeEnum.FLOATING_INTEREST_RATE)
                        ).withFloatingFormula(
                        new TFloatingFormula()
                                .withFormulaTypes(new TFormulaType().withValue(TFormulaTypeEnum.FLOATING_INTEREST))
                                .withObservations(
                                        new TObservation()
                                                .withObservationType(new TObservationType().withValue(TObservationTypeEnum.FLOATING_RATE_RESET))
                                                .withFloatingRateIndices(referenceDataKey(TDomain.FPML_FLOATING_RATE_INDEX, floatingRateFormula)))
                )
        );
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrencyPair(isdaCurrencyPair).withKey(join(currency1, "/", currency2)).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1, "/", currency2), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    //private

    private static void prettyPrint(final String payloadXml) throws IOException, ParserConfigurationException, TransformerException {
        //uncomment to pretty print, comment to turn off
//        Xmls.print(Xmls.toW3cDoc(payloadXml), System.out);
    }

    private static Trade createTrade(
            final String productClassification,
            final List<String> currencies,
            final String optionStyle,
            final List<String> exerciseBusinessCenterIds,
            final List<String> expiryBusinessCenterIds,
            final List<String> valuationBusinessCenterIds,
            final String exerciseLocationBusinessCenterId,
            final String expiryLocationBusinessCenterId,
            final String pricingLocationBusinessCenterId,
            final TCashSettlementMethod cashSettlementMethod,
            final String exerciseSettlementOffsetInterval,
            final String expiryOffsetInterval,
            final String exerciseValuationOffsetInterval,
            final XMLGregorianCalendar exerciseTime,
            final XMLGregorianCalendar expiryTime,
            final XMLGregorianCalendar pricingTime,
            final XMLGregorianCalendar tradeDate,
            final TQuotationSide quotationSide,
            final String cashSettlementCurrency) {
        return new Trade()
                .withEvent(new TEvent().withEventTypes(referenceDataKey(":athena.instrument", randomAlphanumeric(6))))
                .withTradeHeader(new TTradeHeader().withTradeDomain(randomNumeric(randomInt(2, 5))).withTradeDate(tradeDate)
                        .withPartyTradeData(new TPartyTradeData().withPartyViews(new TPartyView()).withBusinessIds(new TBusinessId()
                                .withIdentifierType(randomFrom(TIdentifierType.class)).withIdentifierValue(randomAlphanumeric(3)))))
                .withProduct(
                        new TProduct()
                                .withProductClasses(referenceDataKey(PRODUCT_CLASSIFICATION, productClassification))
                                .withTradeLegs(new TTradeLeg()
                                                .withLegType(new TLegType().withValue(randomFrom(CREDIT_FLOATING, FLOATING_INTEREST_RATE, FIXED_INTEREST_RATE)))
                                                .withContractValues(transform(currencies, TO_CONTRACT_VALUES))
                                ).withOptions(new TOption()
                                        .withExerciseStyles(referenceDataKey(":fpml.exercise-type", optionStyle))
                                        .withOptionType(TOptionType.EARLY_TERMINATION_RIGHTS)
                                        .withSettlementType(TSettlementType.CASH)
                                        .withCashSettlementMethod(cashSettlementMethod)
                                        .withEarliestExerciseTime(new TExerciseTime().withExerciseTime(exerciseTime).withExerciseLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(":fpml.business-center", exerciseLocationBusinessCenterId))))
                                        .withExpiryTime(expiryTime)
                                        .withExpiryLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(":fpml.business-center", expiryLocationBusinessCenterId)))
                                        .withUnderlyingValuation(new TUnderlyingValuation().withObservation(
                                                        new TObservation().withObservationType(new TObservationType().withValue(TObservationTypeEnum.SWAP_VALUATION))
                                                                .withPricingTime(pricingTime).withPricingLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(":fpml.business-center", pricingLocationBusinessCenterId)))
                                                                .withQuotationSide(quotationSide)
                                                )
                                        )
                                        .withCashSettlementCcy(referenceDataKey(":erd.currency", cashSettlementCurrency))
                                        .withEventDateSchedules(
                                                new TEventDateSchedule()
                                                        .withScheduleType(TScheduleType.EXERCISE_SETTLEMENT)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(transform(exerciseBusinessCenterIds, STRING_T_REFERENCE_DATA_KEY_FUNCTION)))

                                                        .withOffsetInterval(exerciseSettlementOffsetInterval),
                                                new TEventDateSchedule()
                                                        .withScheduleType(TScheduleType.EXERCISE_VALUATION)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(transform(valuationBusinessCenterIds, STRING_T_REFERENCE_DATA_KEY_FUNCTION)))
                                                        .withOffsetInterval(exerciseValuationOffsetInterval),
                                                new TEventDateSchedule()
                                                        .withScheduleType(TScheduleType.EXPIRY)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(transform(expiryBusinessCenterIds, STRING_T_REFERENCE_DATA_KEY_FUNCTION)))
                                                        .withOffsetInterval(expiryOffsetInterval)
                                        )
                        )
                );
    }

    private static String randomDuration() throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newDuration(Dates.Now.date().getTime()).toString();
    }

    private static XMLGregorianCalendar xmlTime(final int hour, final int mins) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hour, mins, 0, 0, 0);
    }


    private static Set<String> getNoRulesCurrencyCombination(){
        while (true){
            final String currency1 = randomFrom(CURRENCIES);
            final String currency2 = randomFrom(CURRENCIES);
            final Set<String> currencyCombination = newHashSet(currency1, currency2);
            if(currencyCombination.size() == 2 && !CURRENCY_PAIRS.contains(currencyCombination)){
                return currencyCombination;
            }
        }
    }
}

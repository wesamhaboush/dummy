package com.jpmorgan.dcpp.commons.test;

import org.apache.commons.lang3.Validate;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

import static java.lang.String.format;

public class IsInstanceMatcher extends TypeSafeMatcher<Class> {

  private final Class clazz;

  private IsInstanceMatcher(final Class clazz) {
    Validate.notNull(clazz, "clazz");

    this.clazz = clazz;
  }

  @Override
  protected boolean matchesSafely(final Class theClass) {
    return clazz.isAssignableFrom(theClass);
  }

  @Override
  public void describeTo(final Description description) {
    description.appendText(format("not a subclass of [%s]", clazz.getName()));
  }

  @Factory
  public static Matcher<Class> isInstanceOf(final Class theClass) {
    return new IsInstanceMatcher(theClass);
  }
}


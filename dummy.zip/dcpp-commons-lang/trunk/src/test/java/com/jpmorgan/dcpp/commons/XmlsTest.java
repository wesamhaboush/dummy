package com.jpmorgan.dcpp.commons;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.jpmorgan.dcpp.commons.xml.Version;
import com.ximpleware.NavException;
import com.ximpleware.ParseException;
import com.ximpleware.XPathEvalException;
import com.ximpleware.XPathParseException;
import junit.framework.Assert;
import org.apache.commons.lang3.time.StopWatch;
import org.jdom2.JDOMException;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.newLinkedList;
import static com.jpmorgan.dcpp.commons.Iterators.range;
import static com.jpmorgan.dcpp.commons.Randoms.randomFrom;
import static com.jpmorgan.dcpp.commons.Randoms.randomInt;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.apache.commons.lang3.StringUtils.join;
import static org.junit.Assert.assertEquals;

public class XmlsTest {

    @Test
    public void testXmlWithVersionGetsTheWriteVersionAsExcpected(){
        assertEquals("<age>1000</age>", Xmls.xml().start("age").text("1000").closeAndGet());
        assertEquals(join("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", System.getProperty("line.separator"), "<age>1000</age>"), Xmls.xml(Version.V1_0).start("age").text("1000").closeAndGet());
        assertEquals(join("<?xml version=\"1.2\" encoding=\"UTF-8\"?>", System.getProperty("line.separator"), "<age>1000</age>"), Xmls.xml(Version.V1_2).start("age").text("1000").closeAndGet());
    }

    @Test
    public void testXpathReturnsSingleElementValueCorrectly() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age>1000</age>" +
                        "</person>";
        final String xpath = "/person/age/text()";

        //when
        final String result = Xmls.xpathValue(xml, xpath);

        //then
        assertEquals("1000", result);
    }

    @Test
    public void testXpathReturnsAttributeValueCorrectlyUsingValueMethod() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "</person>";
        final String xpath = "/person/age/@certainty";

        //when
        final String result = Xmls.xpathValue(xml, xpath);

        //then
        assertEquals("NONE", result);
    }

    @Test
    public void testXpathReturnsElementValuesCorrectly() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "<age certainty=\"NONE\">2000</age>" +
                        "</person>";
        final String xpath = "/person/age/text()";

        //when
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        final List<String> result = Xmls.xpathValues(xml, xpath);
        stopWatch.stop();
//        System.out.println(stopWatch.getTime());

        //then
        assertEquals(newArrayList("1000", "2000"), result);
    }

    @Test
    public void testXpathReturnsElementValuesCorrectly_VTD() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "<age certainty=\"NONE\">2000</age>" +
                        "</person>";
        final String xpath = "/person/age/text()";

        //when
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        final List<String> result = Xmls.Vtd.xpathValues(xml, xpath);
        stopWatch.stop();
//        System.out.println(stopWatch.getTime());
        //then
        assertEquals(newArrayList("1000", "2000"), result);
    }

    @Test
    public void testBoth() throws Exception {
        for (int i : range(1, 10)) {
            testXpathReturnsAttributeValuesCorrectly_VTD();
            testXpathReturnsAttributeValuesCorrectly();
        }
    }

    @Test
    public void testXpathReturnsAttributeValuesCorrectly() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "<age certainty=\"WORSE_THAN_NONE\">2000</age>" +
                        "</person>";
        final String xpath = "/person/age/@certainty";

        //when
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        final List<String> result = Xmls.xpathValues(xml, xpath);
        stopWatch.stop();
//        System.out.println(stopWatch.getTime());

        //then
        assertEquals(newArrayList("NONE", "WORSE_THAN_NONE"), result);
    }

    @Test
    public void testXpathReturnsAttributeValuesCorrectly_VTD() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "<age certainty=\"WORSE_THAN_NONE\">2000</age>" +
                        "</person>";
        final String xpath = "/person/age/@certainty";

        //when
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        final List<String> result = Xmls.Vtd.xpathValues(xml, xpath);
        stopWatch.stop();
//        System.out.println(stopWatch.getTime());

        //then
        assertEquals(newArrayList("NONE", "WORSE_THAN_NONE"), result);
    }

    @Test
    public void testXpathReturnsAttributeValueCorrectly() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "</person>";
        final String xpath = "/person/age/@certainty";

        //when
        final String result = Xmls.xpathFromAttribute(xml, xpath);

        //then
        assertEquals("NONE", result);
    }

    @Test
    public void testXpathSetValueReturnsXmlWithElementValueChanged() throws Exception {
        //given
        final String newValue = "Lion";
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age certainty=\"NONE\">1000</age>" +
                        "</person>";
        final String xpath = "/person/name";

        //when
        final String result = Xmls.setXpathValue(xml, xpath, newValue);

        //then
        assertEquals(newValue, Xmls.xpathValue(result, xpath));
    }

    @Test
    public void testPrintAsDocument() throws IOException, SAXException, XPathExpressionException, ParserConfigurationException, TransformerException {
        //given
        final String xml = "<a><b>c</b></a>";
        final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        //when
        final NodeList result = Xmls.asNodeList(xml, "/a/b/text()");
        Xmls.printAsDocument(result, outputStream);

        //then
        assertEquals("<NodeList>c</NodeList>", new String(outputStream.toByteArray(), "UTF-8").trim());
    }

    @Test
    public void testPrint() throws IOException, SAXException, XPathExpressionException, ParserConfigurationException, TransformerException {
        //given
        final Document w3cDoc = fibonacciW3cDocument();
        final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        //when
        Xmls.print(w3cDoc, outputStream);

        //then
        assertEquals("<fibonacci>8</fibonacci>", new String(outputStream.toByteArray(), "UTF-8").trim());
    }

    @Test
    public void toW3cDocument() throws IOException, SAXException, XPathExpressionException, ParserConfigurationException, TransformerException, JDOMException, JDOMException {
        //given
        final org.jdom2.Document jdomDoc = fibonacciJdomDocument();

        //when
        final Document w3cDoc = Xmls.toW3cDocument(jdomDoc);

        //then
        assertNotNull(w3cDoc);
        assertEquals("fibonacci", w3cDoc.getChildNodes().item(0).getNodeName());
        assertEquals("8", w3cDoc.getChildNodes().item(0).getTextContent());
    }

    @Test
    public void toJdomDocument() throws IOException, SAXException, XPathExpressionException, ParserConfigurationException, TransformerException, JDOMException {
        //given
        final Document w3cDoc = fibonacciW3cDocument();

        //when
        final org.jdom2.Document jdomDoc = Xmls.toJdomDocument(w3cDoc);

        //then
        assertNotNull(jdomDoc);
//    Xml.printAsDocument(Xml.toW3cDocument(jdomDoc).getChildNodes(), System.out);
        assertEquals("fibonacci", jdomDoc.getRootElement().getName());
        assertEquals("8", jdomDoc.getRootElement().getText());
    }

    @Test
    public void testVtdIsSafeAcrossThreads() throws XPathEvalException, NavException, XPathParseException, ParseException, ExecutionException, InterruptedException {
        //given
        final int n = randomInt(2, 50);
        final ExecutorService executorService = Executors.newFixedThreadPool(n);
        final String xml = Xmls
                .xml()
                    .start("a").attr("lang", "en")
                        .start("b").attr("a1", "1").attr("a2", "2")
                            .start("c").text("some values ready").end()
                            .start("c").text("some other values ready")
                .end()
                .closeAndGet();
        final Map<String, List<String>> xpathResultMap = ImmutableMap.<String, List<String>>builder()
                .put("/a/@lang", newArrayList("en"))
                .put("/a/b/c/text()", newArrayList("some values ready", "some other values ready"))
                .put("/a/b/d", Lists.<String>newArrayList())
                .build();

        final List<Future<Boolean>> futures = new ArrayList<Future<Boolean>>(n);

        //when
//        System.out.println(xml);
        int i = 0;
        while(i++ < n) {
            futures.add(executorService.submit(new Callable<Boolean>() {
                @Override
                public Boolean call() throws Exception {
                    final String xpath = randomFrom(xpathResultMap.keySet());
                    assertEquals(xpathResultMap.get(xpath), Xmls.Vtd.xpathValues(xml, xpath));
                    return true;
                }
            }));
        }
        for(Future<Boolean> future : futures){
            assertTrue(future.get());
        }
    }

    @Test
    public void testXpathReturnsSingleElementValueCorrectlyWithXml0() throws Exception {
        //given
        final String xml =
                "<person>" +
                        "<name>Bear</name>" +
                        "<age>1000</age>" +
                        "</person>";
        final String xpath = "/person/*";

        //when
        final List<String> result = Xmls.xpathValuesAsXmls(xml, xpath);

        //then
        assertEquals("<?xml version=\"1.0\" encoding=\"UTF-8\"?><name>Bear</name>", result.get(0));
        assertEquals("<?xml version=\"1.0\" encoding=\"UTF-8\"?><age>1000</age>", result.get(1));
    }

    //utils

    private static org.jdom2.Document fibonacciJdomDocument() throws ParserConfigurationException {
        final org.jdom2.Element root = new org.jdom2.Element("fibonacci");
        root.setText("8");
        final org.jdom2.Document doc = new org.jdom2.Document(root);
        return doc;
    }

    private static Document fibonacciW3cDocument() throws ParserConfigurationException {
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        final DocumentBuilder builder = factory.newDocumentBuilder();
        final Document document = builder.newDocument();
        final org.w3c.dom.Element fibonacciElement = document.createElement("fibonacci");
        fibonacciElement.setTextContent("8");
        document.appendChild(fibonacciElement);
        return document;
    }
}

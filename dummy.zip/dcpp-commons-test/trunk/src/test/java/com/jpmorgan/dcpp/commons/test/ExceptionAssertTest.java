package com.jpmorgan.dcpp.commons.test;

import org.junit.Test;

import java.util.concurrent.Callable;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

public class ExceptionAssertTest {

    @Test
    public void testAssertThrowsExact3argsGoodCase() {
        //given
        final String message = randomAlphanumeric(10);
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                throw new TestRuntimeException();
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(message, code, testRuntimeException);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test(expected = AssertionError.class)
    public void testAssertThrowsExact3argsExceptionCase() {
        //given
        final String message = randomAlphanumeric(10);
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                return null;
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(message, code, testRuntimeException);

        //AssertionFailure should have been thrown
    }

    @Test
    public void testAssertThrowsExactCallableClassGoodCase() {
        //given
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                throw new TestRuntimeException();
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(code, testRuntimeException);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test(expected = AssertionError.class)
    public void testAssertThrowsExactCallableClassExceptionCase() {
        //given
        final String message = randomAlphanumeric(10);
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() throws Exception {
                return null;
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(message, code, testRuntimeException);

        //AssertionFailure should have been thrown
    }

    @Test(expected=AssertionError.class)
    public void testAssertThrowsExactRunnableClassExceptionCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(code, testRuntimeException);

        //AssertionFailure should have been thrown
    }

    @Test
    public void testAssertThrowsExactRunnableClassGoodCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
                throw new TestRuntimeException();
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact(code, testRuntimeException);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test(expected=AssertionError.class)
    public void testAssertThrowsExactRunnableWithMessageClassExceptionCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact("with message", code, testRuntimeException);

        //AssertionFailure should have been thrown
    }

    @Test
    public void testAssertThrowsExactRunnableClassWithMessageGoodCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
                throw new TestRuntimeException();
            }
        };

        final Class<? extends Throwable> testRuntimeException = TestRuntimeException.class;

        //when
        ExceptionAssert.assertThrowsExact("with message", code, testRuntimeException);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test
    public void testAssertDoesNotThrowExactRunnableClassWithMessageGoodCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {

            }
        };


        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, NullPointerException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test
    public void testAssertDoesNotThrowExactRunnableClassWithMessageGoodCase2() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
                throw new TestRuntimeException();
            }
        };


        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, NullPointerException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test(expected = AssertionError.class)
    public void testAssertDoesNotThrowExactRunnableClassWithMessageBadCase() {
        //given
        final Runnable code = new Runnable(){
            @Override
            public void run() {
                throw new TestRuntimeException();
            }
        };


        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, TestRuntimeException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test
    public void testAssertDoesNotThrowExactCallableClassWithMessageGoodCase() {
        //given
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() {
                return null;
            }
        };


        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, NullPointerException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test
    public void testAssertDoesNotThrowExactCallableClassWithMessageGoodCase2() {
        //given
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() {
                throw new TestRuntimeException();
            }
        };


        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, NullPointerException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    @Test(expected = AssertionError.class)
    public void testAssertDoesNotThrowExactCallableClassWithMessageBadCase() {
        //given
        final Callable<Void> code = new Callable<Void>(){
            @Override
            public Void call() {
                throw new TestRuntimeException();
            }
        };

        //when
        ExceptionAssert.assertDoesNotThrowExact("with message", code, TestRuntimeException.class);

        //should get here and nothing happens cz the code factually throws the exception expected
    }

    //utils

    private static class TestRuntimeException extends RuntimeException{

    }
}

package com.jpmorgan.ibtcp.dcpp.la.utils;

import com.google.common.base.Throwables;
import org.apache.commons.io.Charsets;
import org.apache.commons.lang.Validate;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;

import static org.apache.commons.io.IOUtils.toInputStream;

/**
 * Handles the marshalling and un-marshalling of objects to and from the schemas. Supports
 * transformation to and from both XML and JSON <tt>String</tt>s.
 * <p/>
 * Validation is supported by setting the <tt>com.jpmorgan.dcppdocs.schema.validate</tt> system property to either <tt>true</tt>
 * or <tt>false</tt>. By default it is to <tt>false</tt>, and can only be configured on application startup.
 *
 * @author 41072Si
 */
public final class ModelFactory {
    private static final Marshaller VALIDATING_MARSHALLER = create("validatingMarshaller");
    private static final Marshaller NON_VALIDATING_MARSHALLER = create("nonValidatingMarshaller");
    private static final Unmarshaller VALIDATING_UNMARSHALLER = Unmarshaller.class.cast(VALIDATING_MARSHALLER);
    private static final Unmarshaller NON_VALIDATING_UNMARSHALLER = Unmarshaller.class.cast(NON_VALIDATING_MARSHALLER);

    private final boolean validate;

    public ModelFactory(final boolean validate) {
        this.validate = validate;
    }

    private static Jaxb2Marshaller create(final String value) {
        return new ClassPathXmlApplicationContext("xml-marshalling-context.xml").getBean(value, Jaxb2Marshaller.class);
    }

    /**
     *
     * @param xmlString
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> T fromXml(final String xmlString, final Class<T> clazz) {
        Validate.notNull(xmlString, "XML String");
        Validate.notEmpty(xmlString, "XML String");
        Validate.notNull(clazz, "clazz");
        Validate.isTrue(VALIDATING_MARSHALLER.supports(clazz), "class supported by marshaller/unmarshaller");
        try {
            final StreamSource streamSource = toStreamSource(xmlString);
            final Object result = validate
                    ? VALIDATING_UNMARSHALLER.unmarshal(streamSource)
                    : NON_VALIDATING_UNMARSHALLER.unmarshal(streamSource);
            return clazz.cast(result);
        } catch (IOException e) {
            throw Throwables.propagate(e);
        }
    }


    /**
     *
     * @param t
     * @param <T>
     * @return
     */
    public <T> String toXml(final T t) {
        Validate.notNull(t, "type");
        try {
            final StringWriter stringWriter = new StringWriter();
            final Result result = new StreamResult(stringWriter);
            if (validate) {
                VALIDATING_MARSHALLER.marshal(t, result);
            } else {
                NON_VALIDATING_MARSHALLER.marshal(t, result);
            }
            return stringWriter.toString();
        } catch (final IOException e) {
            throw Throwables.propagate(e);
        }
    }



    private StreamSource toStreamSource(final String xmlString) throws IOException {
        return new StreamSource(toInputStreamReader(xmlString));
    }

    private InputStreamReader toInputStreamReader(final String xmlString) throws IOException {
        return new InputStreamReader(toInputStream(xmlString, Charsets.UTF_8), Charsets.UTF_8);
    }
}

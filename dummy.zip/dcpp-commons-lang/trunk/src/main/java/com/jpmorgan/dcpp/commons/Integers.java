package com.jpmorgan.dcpp.commons;

import java.util.AbstractList;
import java.util.List;

public class Integers {
    /**
     *
     * @param begin inclusive
     * @param end exclusive
     * @return list of integers to iterate over. Note, this has no memory implications. There are not actual list of integers
     */
    public static Iterable<Integer> range(final int begin, final int end) {
        return new AbstractList<Integer>() {
            @Override
            public Integer get(int index) {
                return begin <= end  ? begin + index : begin - index;
            }

            @Override
            public int size() {
                return Math.abs(end - begin);
            }
        };
    }
}

package com.jpmorgan.ibtcp.dcpp.xquery.engine;

import net.sf.saxon.s9api.XdmValue;

import java.util.Map;

public interface XQueryEngine {
    XdmValue execute(String xquery, Map<String, XdmValue> externalParams);
}

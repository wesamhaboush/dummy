package com.jpmorgan.ibtcp.dcpp.xquery;


import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.SignatureDetails;
import com.jpmorgan.ibtcp.dcpp.la.utils.ModelFactory;
import com.jpmorgan.ibtcp.dcpp.la.utils.NullSignatureDetails;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Collections2.filter;
import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.signatureDetails;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.Assert.assertEquals;

public class EdgSignatureTest extends AbstractXqueryTest {


    private static final ModelFactory MODEL_FACTORY = new ModelFactory(true);
    private static final Map<String, SignatureDetails> SIG_MAP = ImmutableMap.<String, SignatureDetails>builder()
            .put("U049822", new NullSignatureDetails())
            .put("V076903", signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)))
            .put("U113362", signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)))
            .put("V064493", signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)))
            .put("I023465", signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)))
            .put("O025325", signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)))
            .build();
    public static final String SIGNATURE_EQUITIES_XQY = "PaperConfirmationBusinessRules/Equity/signature_equities.xqy";
    public static final String LOOKUP_OQL_FUNCTION_$ID = "lookup:oql($functionName, $id)";

    @Test
    public void testSignatureRulesJacquesMagnan() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V076903";
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(buildOqlLookupFunctionMap("LOCTOK", SIG_MAP)));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String arrangingDesk = "A102765815456";
        final String counterPartyCountry = "BERMUDA123";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, arrangingDesk, counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());

    }

    @Test
    public void testSignatureRulesWilliamLee() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "U049822";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCHK",SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String arrangingDesk = "A102765815456";
        final String counterPartyCountry = "BERMUDA123";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, arrangingDesk, counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        null
                        , null
                        , null),
                actual.getPersonDetails());

    }

    @Test
    public void testSignatureRulesChristopherChan() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "U113362";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCHK",SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String arrangingDesk = "A102765815";
        final String counterPartyCountry = "BERMUDA123";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, arrangingDesk, counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    @Test
    public void testSignatureRulesMarkDewar() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V064493";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCSYD", SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String counterPartyCountry = "BERMUDA123";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, "", counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    @Test
    public void testSignatureRulesClaudiaFuereder() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "I023465";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCLON", SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String counterPartyCountry = "BERMUDA123";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, null, counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }


    @Test
    public void testSignatureRulesCarlosMoscoso1() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "O025325";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCNY", SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String ownerLegalEntity = "0101";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, null, null, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    @Test
    public void testSignatureRulesCarlosMoscoso3() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "O025325";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap("LOCHK", SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String ownerLegalEntity = "0101";
        final String counterPartyCountry = "VIRGIN ISLANDS, BRIT";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, null, counterPartyCountry, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    @Test
    public void testLegalEntity0833_willGetSignatureU049822() throws IOException, SaxonApiException {
        final String id = "U049822";
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap(randomAlphabetic(5), SIG_MAP);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final String ownerLegalEntity = "0833";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, null, null, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(id,
                personalDetails("SIGNATORY", id, null, null, null),
                actual.getPersonDetails());
    }

    @Test
    public void testLegalEntityBasedRules() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final Map<String, String> entityToIdMap = ImmutableMap.<String, String>builder()
                .put("0899", "U399762")
                .put("0896", "D385163")
                .put("0208", "F047671")
                .put("0099", "O025325")
                .put("0333", "O025325")
                .put("0637", "I023465")
                .put("0928", "V064493")
                .put("0028", "EMPTY")
                .put("0228", "EMPTY")
                .put("0034", "EMPTY")
                .put("0300", "EMPTY")
                .put("0355", "EMPTY")
                .put("0613", "EMPTY")
                .put("0634", "EMPTY")
                .put("0698", "EMPTY")
                .put("0453", "EMPTY")
                .build();

        final ImmutableMap.Builder<String,SignatureDetails> sigMapBuilder = ImmutableMap.<String, SignatureDetails>builder().putAll(SIG_MAP);

        final Predicate<String> notAlreadyInGlobalSigMap = new Predicate<String>() {
            @Override
            public boolean apply(String s) {
                return !SIG_MAP.keySet().contains(s);
            }
        };
        for(final String value : newHashSet(filter(entityToIdMap.values(), notAlreadyInGlobalSigMap))){
            sigMapBuilder.put(value,signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)));
        }

        final Map<String,SignatureDetails> sigMap = sigMapBuilder.build();

        for(final String id : entityToIdMap.keySet()){
            testLegalEntitySimpleMap(entityToIdMap.get(id), id, sigMap);
        }

    }

    private static void testLegalEntitySimpleMap(String id, final String ownerLegalEntity, Map<String, SignatureDetails> sigMap) throws IOException, SaxonApiException {
        final Map<String[], String> oqlMap = buildOqlLookupFunctionMap(randomAlphabetic(5), sigMap);
        final String xqueryModule = loadModuleAsString(SIGNATURE_EQUITIES_XQY).replace(LOOKUP_OQL_FUNCTION_$ID, xqueryMap(oqlMap));
        final String owningBusiness = "EDG";
        final String arrangerSpn = "arrangerSpnValue";
        final DsThunderheadInput inputPayload  = payload(owningBusiness, arrangerSpn, null, null, ownerLegalEntity);
        final String payloadXml = removePrelog(MODEL_FACTORY.toXml(inputPayload));


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = Arrays.asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = MODEL_FACTORY.fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(id,
                personalDetails("SIGNATORY", id,
                        sigMap.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , sigMap.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , sigMap.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    //utils

    private static Map<String[], String> buildOqlLookupFunctionMap(final String match, final Map<String, SignatureDetails> signatureDetailsMap) {
        final ImmutableMap.Builder<String[], String> builder = ImmutableMap.<String[], String>builder();
        builder.put(new String[]{"getDataValueMappingRecordForSignatureRules", "dataValueMappingId=CONFIRMATION_SIGNATURE_RULES_PARTIES,mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCTOK,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCTOK'"))
               .put(new String[]{"getDataValueMappingRecordForSignatureRules", "dataValueMappingId=CONFIRMATION_SIGNATURE_RULES_PARTIES,mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCHK,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCHK'"))
               .put(new String[]{"getDataValueMappingRecordForSignatureRules", "dataValueMappingId=CONFIRMATION_SIGNATURE_RULES_PARTIES,mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCSYD,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCSYD'"))
               .put(new String[]{"getDataValueMappingRecordForSignatureRules", "dataValueMappingId=CONFIRMATION_SIGNATURE_RULES_PARTIES,mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCLON,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCLON'"))
               .put(new String[]{"getDataValueMappingRecordForSignatureRules", "dataValueMappingId=CONFIRMATION_SIGNATURE_RULES_PARTIES,mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCNY,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCNY'"));
        for(Map.Entry<String, SignatureDetails> entry : signatureDetailsMap.entrySet()){
            builder.put(new String[]{"getSignature","id=" + entry.getKey()}, toString(entry));
        }
        return builder.build();
    }

    private static String quote(String match) {
        return '\'' + match + '\'';
    }

    private static String ifMatch(final String v1, final String v2){
        return v1.equals(v2) ? v1 : "()";
    }

   private static String xqueryMap(final Map<String[], String> map){
       final String itemTemplate = "else if( $functionName eq '%s' and $id eq '%s' ) then\n" +
               "%s\n";
       final StringBuilder sb = new StringBuilder();
       for(Map.Entry<String[], String> entry : map.entrySet()){
           sb.append(String.format(itemTemplate, entry.getKey()[0], entry.getKey()[1], entry.getValue()));
       }
       return StringUtils.removeStart(sb.append("else () \n").toString(), "else");
   }


}

package com.jpmorgan.ibtcp.dcpp.xquery;

import static com.jpmorgan.dcpp.commons.Xmls.xml;
import static com.jpmorgan.dcpp.commons.Xmls.xpathValue;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;

import com.google.common.collect.ImmutableMap;

public class EnrichConfirmationDocumentTest extends AbstractXqueryTest {

    private static final String XQUERY_CONFIRMATION_DOCUMENT_WITH_RESPONSE = "import module namespace confodocument="
            + "'com.jpmorgan.ibtcp.dcpp.la.confirmationdocument' at 'EnrichConfirmationDocument.xqy';"
            + "declare variable $response as node() external;"
            + "declare variable $csDocumentId as xs:string external;"
            + "declare variable $documentGenerationStatus as xs:string external;"
            + "declare variable $userAbandonedReason as xs:string external;"
            + "declare variable $lar as node() external;"
            + "confodocument:enrichConfirmationDocWithGdfResponse($response, $csDocumentId, $documentGenerationStatus,"
            + "$userAbandonedReason, $lar)";

    @Test
    public void testPayloadPopulatedWithOrgEntity() throws IOException, SaxonApiException, XPathExpressionException {
        //given
        final String xqueryModule = XQUERY_CONFIRMATION_DOCUMENT_WITH_RESPONSE;
        final String orgEntity = randomAlphabetic(5);
        final String response =
                xml().start("dsThunderheadInput").start("otmAttributes").child("orgEntity", orgEntity).closeAndGet();
        //when
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap
                        .< String, String > builder()
                        .put("response", response)
                        .put("csDocumentId", "csDocId")
                        .put("documentGenerationStatus", "documentGenerationStatus")
                        .put("userAbandonedReason", "rubbish")
                        .put("lar",
                                "<legalAffirmationRequest><larVersion>1</larVersion><tradeId>85000BH-0E0E1</tradeId><tradeVersion>1</tradeVersion><businessEventId>EBH-FGZSG</businessEventId><businessEventType>CRE</businessEventType><atpLink>789ea49e-2e19-4518-8fd7-c8f50c455740-1-31-31-31</atpLink><cancelOnlyFlag>false</cancelOnlyFlag><serializationKey>LA-85000BH-0E0E1-EBH-FGZSG-1</serializationKey><sequencingKey>LA-85000BH-0E0E1-EBH-FGZSG-1</sequencingKey><mechanism>PAPER</mechanism><legID>1</legID><pdfLink/><recreateBreakSTP/></legalAffirmationRequest>")
                        .build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(orgEntity,
                xpathValue(result.toString(), "/gbom/confirmationDocument/transmitPayloadInfo/orgEntity/text()"));
        assertEquals("85000BH-0E0E1",
                xpathValue(result.toString(), "/gbom/confirmationDocument/coreProcessingTradeId/text()"));
        assertEquals("1",
                xpathValue(result.toString(), "/gbom/confirmationDocument/lastProcessedStimulusVersion/text()"));
        assertEquals("EBH-FGZSG", xpathValue(result.toString(), "/gbom/confirmationDocument/businessEventId/text()"));
        assertEquals("85000BH-0E0E1",
                xpathValue(result.toString(), "/gbom/confirmationDocument/transmitPayloadInfo/tradeId/text()"));
        assertEquals("1",
                xpathValue(result.toString(), "/gbom/confirmationDocument/transmitPayloadInfo/tradeVersion/text()"));
    }

    @Test
    public void testPayloadPopulatedWithOwnerEci() throws IOException, SaxonApiException, XPathExpressionException {
        //given
        final String xqueryModule = XQUERY_CONFIRMATION_DOCUMENT_WITH_RESPONSE;
        final String ownerEci = randomAlphabetic(5);
        final String response =
                xml().start("dsThunderheadInput").start("parties").start("party")
                        .child("type", "RISK_MANAGEMENT_OWNER").child("eci", ownerEci).closeAndGet();

        //when
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap
                        .< String, String > builder()
                        .put("response", response)
                        .put("csDocumentId", "csDocId")
                        .put("documentGenerationStatus", "documentGenerationStatus")
                        .put("userAbandonedReason", "rubbish")
                        .put("lar",
                                "<legalAffirmationRequest><larVersion>1</larVersion><tradeId>85000BH-0E0E1</tradeId><tradeVersion>1</tradeVersion><businessEventId>EBH-FGZSG</businessEventId><businessEventType>CRE</businessEventType><atpLink>789ea49e-2e19-4518-8fd7-c8f50c455740-1-31-31-31</atpLink><cancelOnlyFlag>false</cancelOnlyFlag><serializationKey>LA-85000BH-0E0E1-EBH-FGZSG-1</serializationKey><sequencingKey>LA-85000BH-0E0E1-EBH-FGZSG-1</sequencingKey><mechanism>PAPER</mechanism><legID>1</legID><pdfLink/><recreateBreakSTP/></legalAffirmationRequest>")
                        .build();

        //        System.out.println(response);
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(ownerEci,
                xpathValue(result.toString(), "/gbom/confirmationDocument/transmitPayloadInfo/ownerEci/text()"));
    }

    @Test
    public void testPayloadPopulatedWithCounterpartyEci() throws IOException, SaxonApiException,
            XPathExpressionException {
        //given
        final String xqueryModule = XQUERY_CONFIRMATION_DOCUMENT_WITH_RESPONSE;
        final String counterpartyEci = randomAlphabetic(5);
        final String response =
                xml().start("dsThunderheadInput").start("parties").start("party").child("type", "COUNTERPARTY")
                        .child("eci", counterpartyEci).closeAndGet();

        //when
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap
                        .< String, String > builder()
                        .put("response", response)
                        .put("csDocumentId", "csDocId")
                        .put("documentGenerationStatus", "documentGenerationStatus")
                        .put("userAbandonedReason", "rubbish")
                        .put("lar",
                                "<legalAffirmationRequest><larVersion>1</larVersion><tradeId>85000BH-0E0E1</tradeId><tradeVersion>1</tradeVersion><businessEventId>EBH-FGZSG</businessEventId><businessEventType>CRE</businessEventType><atpLink>789ea49e-2e19-4518-8fd7-c8f50c455740-1-31-31-31</atpLink><cancelOnlyFlag>false</cancelOnlyFlag><serializationKey>LA-85000BH-0E0E1-EBH-FGZSG-1</serializationKey><sequencingKey>LA-85000BH-0E0E1-EBH-FGZSG-1</sequencingKey><mechanism>PAPER</mechanism><legID>1</legID><pdfLink/><recreateBreakSTP/></legalAffirmationRequest>")
                        .build();

        //        System.out.println(response);
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        //then
        assertEquals(counterpartyEci,
                xpathValue(result.toString(), "/gbom/confirmationDocument/transmitPayloadInfo/counterpartyEci/text()"));
    }
}

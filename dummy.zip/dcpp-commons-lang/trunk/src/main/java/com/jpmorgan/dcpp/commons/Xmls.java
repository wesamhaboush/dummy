package com.jpmorgan.dcpp.commons;

import com.jpmorgan.dcpp.commons.xml.StringXml;
import com.jpmorgan.dcpp.commons.xml.Version;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.ximpleware.*;
import org.apache.commons.lang3.Validate;
import org.jdom2.JDOMException;
import org.jdom2.input.DOMBuilder;
import org.jdom2.output.DOMOutputter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.*;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.List;

import static com.google.common.base.Throwables.propagate;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.newLinkedList;
import static com.jpmorgan.dcpp.commons.Integers.range;

public class Xmls {
    private static final String NODE_LIST = "NodeList";
    private static final Factory<Void, DOMOutputter> DOM_OUTPUTTER_FACTORY = new Factory<Void, DOMOutputter>(){
        @Override
        public DOMOutputter create(Void vo1d) {
            return new DOMOutputter();
        }
    };

    //Not thread-safe, so will be using thread-local
    private static final Factory<Void, DOMBuilder> DOM_BUILDER_FACTORY = new Factory<Void, DOMBuilder>(){
        @Override
        public DOMBuilder create(Void vo1d) {
            return new DOMBuilder();
        }
    };
    public static final XPathFactory XPATH_FACTORY = XPathFactory.newInstance();
    public static final DocumentBuilderFactory DOCUMENT_BUILDER_FACTORY = DocumentBuilderFactory.newInstance();
    public static final TransformerFactory TRANSFORMER_FACTORY = TransformerFactory.newInstance();

    private Xmls() {
    }

    public static void printAsDocument(final NodeList list, final OutputStream outputStream) throws IOException, ParserConfigurationException, TransformerException {
        print(toW3cDocument(list), outputStream);
    }

    public static void print(final Document document, final OutputStream outputStream) throws IOException, ParserConfigurationException, TransformerException {
        final Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        final StreamResult result = new StreamResult(new StringWriter());
        final DOMSource source = new DOMSource(document);
        transformer.transform(source, result);
        outputStream.write(result.getWriter().toString().getBytes());
        outputStream.flush();
    }

    public static Document toW3cDocument(final NodeList list) throws ParserConfigurationException {
        final Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        final Element rootElement = document.createElement(NODE_LIST);
        document.appendChild(rootElement);
        for (int i = 0; i < list.getLength(); i++) {
            final Node node = list.item(i);
            final Node copyNode = document.importNode(node, true);
            rootElement.appendChild(copyNode);
        }
        return document;
    }

    public static String xpathValue(final String xml, String path) throws XPathExpressionException {
        final XPath xpath = XPATH_FACTORY.newXPath();
        return String.class.cast(xpath.compile(path).evaluate(toW3cDoc(xml), XPathConstants.STRING));
    }

    public static List<String> xpathValues(final String xml, String path) throws XPathExpressionException {
        final XPath xpath = XPATH_FACTORY.newXPath();
        final NodeList nodeList = NodeList.class.cast(xpath.compile(path).evaluate(toW3cDoc(xml), XPathConstants.NODESET));
        return toStringValueList(nodeList);
    }

    public static List<String> xpathValuesAsXmls(final String xml, String path) throws XPathExpressionException, ParserConfigurationException, TransformerException {
        final XPath xpath = XPATH_FACTORY.newXPath();
        final NodeList nodeList = NodeList.class.cast(xpath.compile(path).evaluate(toW3cDoc(xml), XPathConstants.NODESET));
        final List<String> xmls = newArrayList();
        for (int i = 0; i < nodeList.getLength(); i++) {
            final Node node = nodeList.item(i);
            xmls.add(docToString(toDocument(node)));
        }
        return xmls;
    }

    private static Document toDocument(final Node node) throws ParserConfigurationException {
        final Document doc = DOCUMENT_BUILDER_FACTORY.newDocumentBuilder().newDocument();
        doc.appendChild(doc.importNode(node, true));
        return doc;
    }

    public static class Vtd {
        public static List<String> xpathValues(final String xml, String path) throws ParseException, XPathParseException, NavException, XPathEvalException {
            final List<String> resultValues = newLinkedList();
            final VTDGen vg = new VTDGen();
            vg.setDoc(xml.getBytes(Charset.forName("UTF-8")));
            vg.parse(true);
            final VTDNav vn = vg.getNav();
            final AutoPilot ap = new AutoPilot(vn);
            ap.bind(vn);
            ap.selectXPath(path);
            int i;
            if(isAttribute(path)){
                while ((i = ap.evalXPath()) != -1) {
                    resultValues.add(vn.toString(vn.getAttrVal(vn.toString(i))));
                }
            } else {
                while ((i = ap.evalXPath()) != -1) {
                    resultValues.add(vn.toString(i));
                }
            }
            return resultValues;
        }

        private static boolean isAttribute(final String path) {
            return path.substring(path.lastIndexOf('/')).contains("/@");
        }
    }

    public static String xpathFromAttribute(final String xml, String path) throws XPathExpressionException {
        final XPath xpath = XPATH_FACTORY.newXPath();
        final Document document = toW3cDoc(xml);
        return String.class.cast(xpath.compile(path).evaluate(document, XPathConstants.STRING));
    }

    public static String setXpathValue(final String xml, final String path, final String newValue) throws XPathExpressionException, TransformerException {
        final XPath xpath = XPATH_FACTORY.newXPath();
        final Document document = toW3cDoc(xml);
        final NodeList nodeList = NodeList.class.cast(xpath.compile(path).evaluate(document, XPathConstants.NODESET));


        for (int i = 0; i < nodeList.getLength(); i++) {
            nodeList.item(i).setTextContent(newValue);
        }

        return docToString(document);
    }

    private static String docToString(final Document doc) throws TransformerException {
        final Transformer transformer = TRANSFORMER_FACTORY.newTransformer();
        // below code to remove XML declaration
        // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        final StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        final String output = writer.getBuffer().toString();
        return output;
    }

    public static Document toW3cDoc(final String xml) {
        try {
            return doToW3cDoc(xml);
        } catch (IOException e) {
            throw propagate(e);
        } catch (SAXException e) {
            throw propagate(e);
        } catch (ParserConfigurationException e) {
            throw propagate(e);
        }
    }

    public static class XStreams {
        public static final XStream MARSHALLER = new XStream();
        public static final XStream UNMARSHALLER = new XStream(new DomDriver());

        public static <T> T unmarshal(final String xml, final Class<T> t) {
            return t.cast(UNMARSHALLER.fromXML(xml));
        }

        public static <T> String marshall(final T t) {
            return MARSHALLER.toXML(t);
        }
    }

    public static StringXml xml(){
        return new StringXml();
    }

    public static StringXml xml(Version version){
        return new StringXml(version);
    }

    private static Document doToW3cDoc(final String xml) throws IOException, SAXException, ParserConfigurationException {
        final DocumentBuilder db = DOCUMENT_BUILDER_FACTORY.newDocumentBuilder();
        final InputSource is = new InputSource(new StringReader(xml));
        return db.parse(is);
    }

    private static List<String> toStringValueList(final NodeList nodes) {
        final List<String> values = new LinkedList<String>();
        for (int i : range(0, nodes.getLength())) {
            values.add(nodes.item(i).getNodeValue());
        }
        return values;
    }

    public static org.jdom2.Document toJdomDocument(Document doc) throws JDOMException {
        return DOM_BUILDER_FACTORY.create(null).build(doc);
    }

    public static Document toW3cDocument(org.jdom2.Document doc) throws JDOMException {
        return DOM_OUTPUTTER_FACTORY.create(null).output(doc);
    }

    public static NodeList asNodeList(final String xml, boolean namespaceAware) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xml, "xml cannot be null");

        final InputSource inputSource = new InputSource(new StringReader(xml));
        return asNodeList(inputSource, namespaceAware);
    }

    public static NodeList asNodeList(final InputStream xmlStream, boolean namespaceAware) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xmlStream, "xmlStream cannot be null");

        final InputSource inputSource = new InputSource(xmlStream);
        return asNodeList(inputSource, namespaceAware);
    }

    public static NodeList asNodeList(final InputSource xmlSource, boolean namespaceAware) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xmlSource, "xmlSource cannot be null");

        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(namespaceAware); // never forget this!
        final DocumentBuilder builder = factory.newDocumentBuilder();
        final Document doc = builder.parse(xmlSource);
        return doc.getChildNodes();
    }

    public static NodeList asNodeList(final String xml, final String xpathText) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xml, "xml cannot be null");

        final InputSource inputSource = new InputSource(new StringReader(xml));
        return asNodeList(inputSource, xpathText);
    }


    public static NodeList asNodeList(final InputStream xmlStream, final String xpathText) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xmlStream, "xmlStream");

        final InputSource inputSource = new InputSource(xmlStream);
        return asNodeList(inputSource, xpathText);
    }

    public static NodeList asNodeList(final InputSource xmlSource, final String xpathText) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Validate.notNull(xmlSource, "xmlSource cannot be null");
        Validate.notNull(xpathText, "xpathText cannot be null");

        final DocumentBuilder builder = DOCUMENT_BUILDER_FACTORY.newDocumentBuilder();
        final Document doc = builder.parse(xmlSource);
        final XPathFactory xPathFactory = XPathFactory.newInstance();
        final XPath xpath = xPathFactory.newXPath();
        final XPathExpression expr = xpath.compile(xpathText);
        return NodeList.class.cast(expr.evaluate(doc, XPathConstants.NODESET));
    }

}

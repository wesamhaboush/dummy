package com.jpmorgan.hotel;

public interface Room {
    String getId();
    double calculatePrice(Facility...facilities);
}

package com.jpmorgan.ibtcp.dcpp.la.utils;

/*******************************************************************************
 * File Name: FileUtility.java
 * Copyright @2012 JPMorgan Chase
 *   Rls   Change Date  Changed By         Change Description
 *   ===   ===========  ==============     =======================
 *         15-May-12    Dipanjan C         Initial Creation
 ******************************************************************************/

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * Class to provide File utilities.
 */
public final class FileUtility {
    /**
    * Logger.
    */
    private static Logger logger = LoggerFactory.getLogger(FileUtility.class.getName());
    /**
     * Private Constructor.
     */
    private FileUtility() {
    }
    /**
     * Method to read the file as String.
     * @param filePath of type String.
     * @return output as String.
     */
    public static String readFileAsString(final String filePath) {
        byte[] buffer = null;
        BufferedInputStream inputStream = null;
        try {
            buffer = new byte[(int) (new File(filePath).length())];
            inputStream =
            new BufferedInputStream(new FileInputStream(filePath));
            inputStream.read(buffer);
        } catch (FileNotFoundException e1) {
            logger.info("File not found @ " + filePath);
        } catch (IOException e) {
            logger.info("File couldn't be read from " + filePath + "]");
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                logger.error(
                "Exception while closing file " + filePath);
            }
        }
        return new String(buffer);
    }

    /**
     * It search file in CLASSPATH and read contents.
     * @param filePath the file path
     * @return String of File As Class PathResource
     */
    public static String readFileAsClassPathResource(final String filePath) {
        byte[] buffer = null;
        BufferedInputStream bif = null;
        try {
            InputStream istr =
                    Class.forName(
                            "com.jpmorgan.ibtcp.dcpp.advices.utils.FileUtility")
                            .getClassLoader().getResourceAsStream(filePath);
            buffer = new byte[istr.available()];
            bif = new BufferedInputStream(istr);
            bif.read(buffer);
            return new String(buffer);
        } catch (IOException e) {
            logger.error("File not found in classpath[" + filePath
                    + "]", e);
        } catch (ClassNotFoundException e) {
            logger.error("File not found in classpath[" + filePath
                    + "]", e);
        } finally {
            try {
                if (bif != null) {
                    bif.close();
                }
            } catch (IOException e) {
                logger.error((new StringBuilder()).append(
                        "An IOException occurred while closing the file \"")
                        .append(filePath).append("\" connections").toString());
            }
        }
        return null;
    }

    /**
     * @param filename String
     * @return InputStream
     * @throws Exception exception
     */
    public static InputStream getInputStream(final String filename) throws Exception {
        InputStream in = null;
        try {
            in = new FileInputStream(filename);
        } catch (FileNotFoundException e1) {
            logger.warn("File not found:" + filename);
        }

        if (in == null) {
            in = FileUtility.class.getClassLoader().getResourceAsStream(filename);
        }

        if (in == null) {
            throw new FileNotFoundException("Unable to open file: " + filename);
        }
        return in;
    }
}

package com.jpmorgan.dcpp.commons;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import org.junit.Test;

import static com.jpmorgan.dcpp.commons.Xmls.xml;
import static junit.framework.TestCase.assertEquals;
import static org.apache.commons.lang3.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang3.builder.HashCodeBuilder.reflectionHashCode;
import static org.junit.Assert.assertNotNull;

public class XStreamTest {
    @Test
    public void testNonTolerantXStreamWithAllFieldsCovered(){
        //given
        final String fullXmlForPerson =
                xml()
                        .start("person")
                            .start("address")
                                .child("city", "bournemouth")
                            .end()
                        .child("age", "100000")
                .closeAndGet();


        //when
        final XStream xStream = new XStream(new DomDriver());
        xStream.alias(Person.class.getSimpleName().toLowerCase(), Person.class);
        xStream.alias(Address.class.getSimpleName().toLowerCase(), Address.class);
        final Person person = Person.class.cast(xStream.fromXML(fullXmlForPerson));

        //then
        assertNotNull(person);
        assertEquals(person("bournemouth", 100000), person);
        assertEquals(removeLineEndings(fullXmlForPerson), removeLineEndings(xStream.toXML(person("bournemouth", 100000))));
    }

    @Test
    public void testNonTolerantXStreamWithExtraElements(){
        //given
        final String fullXmlForPerson =
                xml()
                        .start("person")
                        .start("address")
                        .child("city", "bournemouth")
                        .end()
                        .child("age", "100000")
                        .closeAndGet();

        final String partialXmlForPerson =
                    xml()
                        .start("person")
                            .child("age", "100000")
                        .closeAndGet();


        //when
        final XStream xStream = new XStream(new DomDriver());
        xStream.alias(Person.class.getSimpleName().toLowerCase(), PartialPerson.class);
        xStream.ignoreUnknownElements();
        final PartialPerson partialPerson = PartialPerson.class.cast(xStream.fromXML(fullXmlForPerson));

        //then
        assertNotNull(partialPerson);
        assertEquals(partialPerson(100000), partialPerson);
        assertEquals(removeLineEndings(partialXmlForPerson), removeLineEndings(xStream.toXML(partialPerson(100000))));
        //XStreamMarshaller
    }

    //utils

    private PartialPerson partialPerson(final int age) {
        return new PartialPerson(age);
    }

    private String removeLineEndings(final String s) {
        return s.replaceAll("\\r\\n", "\n").replaceAll("\\r", "\n");
    }

    private Person person(final String city, final int age) {
        final Address address = new Address(city);
        return new Person(address, age);
    }

    private static class Address {

        private String city;

        Address(final String city) {
            this.city = city;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Address{" +
                    "city='" + city + '\'' +
                    '}';
        }
    }

    private static class Person {
        private Address address;
        private int age;

        Person(final Address address, final int age) {
            this.address = address;
            this.age = age;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Person{" +
                    "address=" + address +
                    ", age=" + age +
                    '}';
        }
    }

    private static class PartialPerson {
        private int age;

        PartialPerson(final int age) {
            this.age = age;
        }

        @Override
        public boolean equals(final Object that) {
            return reflectionEquals(this, that);
        }

        @Override
        public int hashCode() {
            return reflectionHashCode(this);
        }

        @Override
        public String toString() {
            return "Person{" +
                    "age=" + age +
                    '}';
        }
    }
}

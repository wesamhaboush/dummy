package com.jpmorgan.dcpp.commons.csv;

public interface CSVReadProc {
	void procRow(int rowIndex, String... values);
}


package com.jpmorgan.ibtcp.dcpp.la.signature;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.ibtcp.dcpp.la.utils.FileUtility;
import com.jpmorgan.ibtcp.dcpp.la.utils.XqueryUtil;
import com.jpmorgan.ibtcp.dcpp.xquery.AbstractXqueryTest;

public class MISReportParametersTest extends AbstractXqueryTest {

    private static String xqueryModule = null;

    static {

        xqueryModule =
                "import module namespace confodocument="
                        + "'com.jpmorgan.ibtcp.dcpp.la.confirmationdocument' at 'src/main/resources/bs-rules/xquery/EnrichConfirmationDocument.xqy';"
                        + "declare variable $response as node() external;"
                        + "declare variable $csDocumentId as xs:string external;"
                        + "declare variable $documentGenerationStatus as xs:string external;"
                        + "declare variable $userAbandonedReason as xs:string external;"
                        + "declare variable $lar as node() external;"
                        + "confodocument:enrichConfirmationDocWithGdfResponse($response, $csDocumentId, $documentGenerationStatus,"
                        + "$userAbandonedReason,$lar)";
    }

    @Test
    public void testMIS() throws SaxonApiException, IOException, XPathExpressionException {
        String enrichedPayloadXML =
                FileUtility.readFileAsString("src/test/resources/TestData/payload/responseForMISReport.xml");
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap
                        .< String, String > builder()
                        .put("response", enrichedPayloadXML)
                        .put("csDocumentId", "csDocId")
                        .put("documentGenerationStatus", "documentGenerationStatus")
                        .put("userAbandonedReason", "rubbish")
                        .put("lar",
                                "<legalAffirmationRequest><larVersion>1</larVersion><tradeId>85000BH-0E0E1</tradeId><tradeVersion>1</tradeVersion><businessEventId>EBH-FGZSG</businessEventId><businessEventType>CRE</businessEventType><atpLink>789ea49e-2e19-4518-8fd7-c8f50c455740-1-31-31-31</atpLink><cancelOnlyFlag>false</cancelOnlyFlag><serializationKey>LA-85000BH-0E0E1-EBH-FGZSG-1</serializationKey><sequencingKey>LA-85000BH-0E0E1-EBH-FGZSG-1</sequencingKey><mechanism>PAPER</mechanism><legID>1</legID><pdfLink/><recreateBreakSTP/></legalAffirmationRequest>")
                        .build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap, "bs-rules/xquery/");
        final XdmValue result = qe.evaluate();

        assertEquals(
                XqueryUtil.getViaXpath("//confirmationDocument/audit/recreateBreakSTP/text()",
                        XqueryUtil.getXdmNode(result.toString())), "true");
    }
}

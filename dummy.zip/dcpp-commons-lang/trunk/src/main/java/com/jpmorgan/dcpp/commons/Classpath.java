package com.jpmorgan.dcpp.commons;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.text.MessageFormat;

import static com.google.common.base.Throwables.propagate;

public class Classpath {
    public static String resourceAsString(final String resourcePath) {
        try {
            return IOUtils.toString(Classes.getClassLoader().getResourceAsStream(resourcePath));
        } catch (IOException e) {
            final String msg = MessageFormat.format("failed to read resource [{0}] from classpath", resourcePath);
            throw propagate(new RuntimeException(msg, e));
        }
    }
}

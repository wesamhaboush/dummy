package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.commons.Dates;
import com.jpmorgan.dcpp.commons.Xmls;
import com.jpmorgan.dcpp.la.model.generated.*;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.junit.Test;
import org.xml.sax.SAXException;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Dates.toXmlGregorianCalendar;
import static com.jpmorgan.dcpp.commons.Objects.isNull;
import static com.jpmorgan.dcpp.commons.Randoms.*;
import static com.jpmorgan.dcpp.la.model.generated.TDomain.*;
import static com.jpmorgan.dcpp.la.model.generated.TFormulaTypeEnum.FLOATING_INTEREST;
import static com.jpmorgan.dcpp.la.model.generated.TLegTypeEnum.FLOATING_INTEREST_RATE;
import static com.jpmorgan.dcpp.la.model.generated.TObservationTypeEnum.FLOATING_RATE_RESET;
import static com.jpmorgan.dcpp.la.model.generated.TOptionType.SWAPTION;
import static com.jpmorgan.dcpp.la.model.generated.TScheduleType.*;
import static com.jpmorgan.dcpp.la.model.generated.TSettlementType.PHYSICAL;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.referenceDataKey;
import static java.util.Arrays.asList;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.join;
import static org.joda.time.DateTime.now;
import static org.junit.Assert.assertNull;

public class SwaptionsMatrixOetRatesTest extends AbstractXqueryTest {
    private static final String SWAPTIONS_MATRIX_OET_RATES_XQY = "PaperConfirmationBusinessRules/Rates/swaptions-matrix-oet-rates.xqy";
    private static final List<String> CURRENCIES = newArrayList(
            "AUD",
            "CAD",
            "CHF",
            "CNY",
            "CZK",
            "DKK",
            "EUR",
            "GBP",
            "HKD",
            "HUF",
            "IDR",
            "INR",
            "ILS",
            "JPY",
            "KRW",
            "MXN",
            "MYR",
            "NOK",
            "NZD",
            "PHP",
            "PLN",
            "SEK",
            "SGD",
            "THB",
            "TRY",
            "TWD",
            "USD",
            "ZAR"
    );

    private static final Set<String> STYLES = newHashSet("Bermudan", "European", "American");
    private static final Set<String> UNWANTED_EVENTS = newHashSet("PU", "TU", "INC");
    private static final String ISDA_NAME = "ISDA_SETTLEMENT_MATRIX_SWAPTIONS";
    private static final List<String> PRODUCT_CLASSIFICATIONS = newArrayList("D1078", "D1097", "D1154", "D1222", "D392", "D393", "D394", "D396", "D397", "D401", "D406", "D500", "D501", "D608", "D610", "D613", "D621");

    @Test
    public void whenNotCorrectClassification_NoIsdaTagAdded() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = randomFrom(CURRENCIES);
        final String currency2 = randomFrom(newHashSet(filter(CURRENCIES, notEqualsTo(currency1))));
        final String optionStyle = randomFrom(STYLES);
        final String businessDaysCenterId = "MXMC";
        final String floatingRateIndex = randomAlphanumeric(10);
        final String exerciseLocationBusinessCenterId = "MXMC";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomFrom(UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final Trade trade = createTrade(
                newArrayList(currency1, currency2),
                eventType,
                floatingRateIndex,
                randomFrom(TSettlementType.class),
                optionStyle,
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        trade.getProduct().getTradeLegs().iterator().next().getContractValues().iterator().next().setCurrency(null);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        trade.getProduct().getProductClasses().clear();
        trade.getProduct().getProductClasses().add(referenceDataKey(TDomain.PRODUCT_CLASSIFICATION, randomNotIn(randomStringFactory(4), PRODUCT_CLASSIFICATIONS)));
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        assertNull(getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenNoSpecificRuleCurrency() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = randomNotIn(randomAlphabeticFactory(3), CURRENCIES);
        final String optionStyle = randomFrom(STYLES);
        final String businessDaysCenterId = "MXMC";
        final String floatingRateIndex = randomAlphanumeric(10);
        final String exerciseLocationBusinessCenterId = "MXMC";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomFrom(UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrency = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                randomFrom(TSettlementType.class),
                optionStyle,
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrency).withKey("").withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenNoCurrencyPresent() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = randomNotIn(randomAlphabeticFactory(3), CURRENCIES);
        final String optionStyle = randomFrom(STYLES);
        final String businessDaysCenterId = "MXMC";
        final String floatingRateIndex = randomAlphanumeric(10);
        final String exerciseLocationBusinessCenterId = "MXMC";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomFrom(UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrency = false;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                randomFrom(TSettlementType.class),
                optionStyle,
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);
        trade.getProduct().getTradeLegs().iterator().next().getContractValues().iterator().next().setCurrency(null);
        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrency).withKey("").withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithUnWantedEventType() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = randomFrom(CURRENCIES);
        final String optionStyle = randomFrom(STYLES);
        final String businessDaysCenterId = "MXMC";
        final String floatingRateIndex = randomAlphanumeric(10);
        final String exerciseLocationBusinessCenterId = "MXMC";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomFrom(UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate()));
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrency = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                randomFrom(TSettlementType.class),
                optionStyle,
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                newArrayList(businessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrency).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithDifferentEventType_NoFloatingRateIndex_physicalSettlement_Bermudan() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = PHYSICAL;
        final String optionStyle = "Bermudan";
        final String floatingRateIndex = null;
        final String exerciseBusinessDaysCenterId = "CATO";
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithDifferentEventType_NoFloatingRateIndex_physicalSettlement_UnknownStyle() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = PHYSICAL;
        final String optionStyle = randomNotIn(randomAlphabeticFactory(randomInt(5, 9)), newArrayList("Bermudan", "European", "American"));
        final String floatingRateIndex = null;
        final String exerciseBusinessDaysCenterId = "CATO";
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = randomFrom(TCashSettlementMethod.class);
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = randomDuration();
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                Collections.<String>emptyList(),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                randomDuration(),
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }



    @Test
    public void whenOneCurrencyWithDifferentEventType_NoFloatingRateIndex_cashSettlement_cashPriceMethod_Bermudan() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = TSettlementType.CASH;
        final String optionStyle = "Bermudan";
        final String exerciseBusinessDaysCenterId = "CATO";
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String floatingRateIndex = null;
        final String cashSettlementPaymentDateBusinessCenter = "CATO";
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = TCashSettlementMethod.CASH_PRICE;
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = exerciseSettlementOffsetInterval;
        final String paymentOffsetInterval = "P1D";
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = exerciseDayType;
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                newArrayList(cashSettlementPaymentDateBusinessCenter),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                paymentOffsetInterval,
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithDifferentEventType_ExistingFloatingRateIndex_cashSettlement_cashPriceMethod_Bermudan() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = TSettlementType.CASH;
        final String optionStyle = "Bermudan";
        final String exerciseBusinessDaysCenterId1 = "CATO";
        final String exerciseBusinessDaysCenterId2 = "GBLO";
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String floatingRateIndex = "CAD-LIBOR-BBA-SwapMarker";
        final String cashSettlementPaymentDateBusinessCenter1 = "CATO";
        final String cashSettlementPaymentDateBusinessCenter2 = "GBLO";
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = TCashSettlementMethod.CASH_PRICE;
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = exerciseSettlementOffsetInterval;
        final String paymentOffsetInterval = "P1D";
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = exerciseDayType;
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId1, exerciseBusinessDaysCenterId2),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                newArrayList(cashSettlementPaymentDateBusinessCenter1,cashSettlementPaymentDateBusinessCenter2),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                paymentOffsetInterval,
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithDifferentEventType_ExistingNonSpecifiedFloatingRateIndex_cashSettlement_cashPriceMethod_Bermudan() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = TSettlementType.CASH;
        final String optionStyle = "Bermudan";
        final String exerciseBusinessDaysCenterId1 = "CATO";
        final String exerciseBusinessDaysCenterId2 = "GBLO";
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String floatingRateIndex = randomAlphanumeric(10);
        final String cashSettlementPaymentDateBusinessCenter1 = "CATO";
        final String cashSettlementPaymentDateBusinessCenter2 = "GBLO";
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = TCashSettlementMethod.CASH_PRICE;
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = exerciseSettlementOffsetInterval;
        final String paymentOffsetInterval = "P1D";
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = exerciseDayType;
        final String expiryDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = false;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId1, exerciseBusinessDaysCenterId2),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                newArrayList(cashSettlementPaymentDateBusinessCenter1,cashSettlementPaymentDateBusinessCenter2),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                paymentOffsetInterval,
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    @Test
    public void whenOneCurrencyWithDifferentEventType_NoFloatingRateIndex_cashSettlement_cashPriceMethod_AmericanOrEuropean() throws SaxonApiException, IOException, XPathExpressionException, DatatypeConfigurationException, SAXException, TransformerException, ParserConfigurationException {
        //Given
        final String xqueryModule = loadModuleAsString(SWAPTIONS_MATRIX_OET_RATES_XQY);
        final String currency1 = "CAD";
        final TSettlementType settlementType = TSettlementType.CASH;
        final String optionStyle = randomFrom("American", "European");
        final String exerciseBusinessDaysCenterId = randomNotIn(randomAlphanumericFactory(4), asList("CATO"));
        final String valuationBusinessDaysCenterId = "CATO";
        final String expiryBusinessDaysCenterId = "CATO";
        final String floatingRateIndex = null;
        final String cashSettlementPaymentDateBusinessCenter = "CATO";
        final String exerciseLocationBusinessCenterId = "CATO";
        final TCashSettlementMethod cashSettlementMethod = TCashSettlementMethod.CASH_PRICE;
        final String eventType = randomNotIn(randomAlphanumericFactory(randomInt(2, 4)), UNWANTED_EVENTS);
        final String expiryOffsetInterval = randomDuration();
        final String exerciseSettlementOffsetInterval = randomDuration();
        final String exerciseValuationOffsetInterval = expiryOffsetInterval;
        final String paymentOffsetInterval = "P1D";
        final XMLGregorianCalendar exerciseTime = xmlTime(11,0);
        final String exerciseDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String valuationDayType = randomFrom("Calendar", "Business", "CALENDAR", "BUSINESS");
        final String expiryDayType = valuationDayType;

        final boolean isdaCurrencyPair = true;
        final boolean isAdheredTo = true;

        final Trade trade = createTrade(
                newArrayList(currency1),
                eventType,
                floatingRateIndex,
                settlementType,
                optionStyle,
                newArrayList(exerciseBusinessDaysCenterId),
                newArrayList(valuationBusinessDaysCenterId),
                newArrayList(expiryBusinessDaysCenterId),
                exerciseLocationBusinessCenterId,
                newArrayList(cashSettlementPaymentDateBusinessCenter),
                cashSettlementMethod,
                expiryOffsetInterval,
                exerciseSettlementOffsetInterval,
                exerciseValuationOffsetInterval,
                paymentOffsetInterval,
                exerciseTime,
                exerciseDayType,
                valuationDayType,
                expiryDayType);

        final DsThunderheadInput inputPayload  = payload()
                .withTrade(trade)
                .withProductEnrichment(new T2ProductEnrichment())
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);
        prettyPrint(payloadXml);
        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final String resultItem = resultXdmItems.iterator().next().toString();
        final T40IsdaStandards isdaStandards = new T40IsdaStandards().withStandards(new T41Standard().withIsAdheredTo(isAdheredTo).withIsdaCurrency(isdaCurrencyPair).withKey(currency1).withName(ISDA_NAME));
        assertEquals(join("currencies used ", currency1), isdaStandards, getModelFactory().fromXml(resultItem, DsThunderheadInput.class).getProductEnrichment().getIsdaStandards());
    }

    public Predicate<String> notEqualsTo(final String currency1) {
        return new Predicate<String>(){
            @Override
            public boolean apply(final String input) {
                return !currency1.equals(input);
            }

            };
    }

    //private

    private static void prettyPrint(final String payloadXml) throws IOException, ParserConfigurationException, TransformerException {
        //uncomment to pretty print, comment to turn off
//        Xmls.print(Xmls.toW3cDoc(payloadXml), System.out);
    }

    private static Trade createTrade(
            final List<String> currencies,
            final String eventType,
            final String floatingRateIndex,
            final TSettlementType settlementType,
            final String optionStyle,
            final List<String> exerciseBusinessCenterIds,
            final List<String> valuationBusinessCenterIds,
            final List<String> expiryBusinessCenterIds,
            final String exerciseLocationBusinessCenterId,
            final List<String> cashSettlementPaymentDateBusinessCenterIds,
            final TCashSettlementMethod cashSettlementMethod,
            final String expiryOffsetInterval,
            final String exerciseSettlementOffsetInterval,
            final String exerciseValuationOffsetInterval,
            final String paymentOffsetInterval,
            final XMLGregorianCalendar exerciseTime,
            final String exerciseDayType,
            final String valuationDayType,
            final String expiryDayType) throws DatatypeConfigurationException {
        final List<TContractValue> contractValues = newArrayList();
        for(final String currency : currencies){
            contractValues.add(new TContractValue().withValueType(new TValueType().withValue(randomFrom(TValueTypeEnum.class))).withId(randomAlphanumeric(5)).withCurrency(referenceDataKey(ERD_CURRENCY, currency)));
        }
        final List<TReferenceDataKey> exerciseBusinessCenterIdReferenceDataKeys = newArrayList();
        for(final String exerciseBusinessCenterId : exerciseBusinessCenterIds){
            exerciseBusinessCenterIdReferenceDataKeys.add(referenceDataKey(FPML_BUSINESS_CENTER, exerciseBusinessCenterId));
        }
        final List<TReferenceDataKey> valuationBusinessCenterIdReferenceDataKeys = newArrayList();
        for(final String valuationBusinessCenterId : valuationBusinessCenterIds){
            valuationBusinessCenterIdReferenceDataKeys.add(referenceDataKey(FPML_BUSINESS_CENTER, valuationBusinessCenterId));
        }
        final List<TReferenceDataKey> expiryBusinessCenterIdReferenceDataKeys = newArrayList();
        for(final String expiryBusinessCenterId : expiryBusinessCenterIds){
            expiryBusinessCenterIdReferenceDataKeys.add(referenceDataKey(FPML_BUSINESS_CENTER, expiryBusinessCenterId));
        }
        final List<TReferenceDataKey> cashSettlementPaymentDateBusinessCenterIdReferenceDataKeys = newArrayList();
        for(final String cashSettlementPaymentDateBusinessCenterId : cashSettlementPaymentDateBusinessCenterIds){
            cashSettlementPaymentDateBusinessCenterIdReferenceDataKeys.add(referenceDataKey(FPML_BUSINESS_CENTER, cashSettlementPaymentDateBusinessCenterId));
        }
        return new Trade()
                .withEvent(new TEvent().withEventTypes(referenceDataKey(DCPP_EVENT_TYPE, eventType)))
                .withTradeHeader(new TTradeHeader().withTradeDomain(randomNumeric(randomInt(2, 5))).withTradeDate(toXmlGregorianCalendar(randomDateBetween(now().minusDays(5).toDate(), now().plusDays(5).toDate())))
                        .withPartyTradeData(new TPartyTradeData().withPartyViews(new TPartyView()).withBusinessIds(new TBusinessId()
                                .withIdentifierType(randomFrom(TIdentifierType.class)).withIdentifierValue(randomAlphanumeric(3)))))
                .withProduct(
                        new TProduct()
                                .withProductClasses(referenceDataKey(PRODUCT_CLASSIFICATION, randomFrom(PRODUCT_CLASSIFICATIONS)))
                                .withTradeLegs(new TTradeLeg()
                                                .withLegType(new TLegType().withValue(FLOATING_INTEREST_RATE))
                                                .withFloatingFormula(new TFloatingFormula()
                                                        .withFormulaTypes(new TFormulaType().withValue(FLOATING_INTEREST))
                                                        .withObservations(new TObservation()
                                                                .withObservationType(new TObservationType().withValue(FLOATING_RATE_RESET))
                                                                .withFloatingRateIndices(isNull(floatingRateIndex) ? null : referenceDataKey(FPML_FLOATING_RATE_INDEX, floatingRateIndex))))
                                                .withContractValues(contractValues)
                                ).withOptions(new TOption()
                                        .withExerciseStyles(referenceDataKey(randomFrom(TDomain.class).value(), optionStyle))
                                        .withOptionType(SWAPTION)
                                        .withSettlementType(settlementType)
                                        .withCashSettlementMethod(cashSettlementMethod)
                                        .withLatestExerciseTime(new TExerciseTime().withExerciseTime(exerciseTime).withExerciseLocation(new TBusinessCenter().withBusinessCenterIds(referenceDataKey(FPML_BUSINESS_CENTER, exerciseLocationBusinessCenterId))))
                                        .withEventDateSchedules(
                                                new TEventDateSchedule()
                                                        .withScheduleType(EXERCISE_SETTLEMENT)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(exerciseBusinessCenterIdReferenceDataKeys))
                                                        .withDayType(exerciseDayType)
                                                        .withOffsetInterval(exerciseSettlementOffsetInterval),
                                                new TEventDateSchedule()
                                                        .withScheduleType(EXERCISE_VALUATION)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(valuationBusinessCenterIdReferenceDataKeys))
                                                        .withDayType(valuationDayType)
                                                        .withOffsetInterval(exerciseValuationOffsetInterval),
                                                new TEventDateSchedule()
                                                        .withScheduleType(EXPIRY)
                                                        .withBusinessCenters(new TBusinessCenter().withBusinessCenterIds(expiryBusinessCenterIdReferenceDataKeys))
                                                        .withDayType(expiryDayType).withOffsetInterval(expiryOffsetInterval),
                                                new TEventDateSchedule()
                                                        .withScheduleType(PAYMENT)
                                                        .withBusinessCenters(cashSettlementPaymentDateBusinessCenterIdReferenceDataKeys.isEmpty() ? null : new TBusinessCenter().withBusinessCenterIds().withBusinessCenterIds(cashSettlementPaymentDateBusinessCenterIdReferenceDataKeys))
                                                        .withOffsetInterval(paymentOffsetInterval)
                                        )
                        )
                );
    }

    private static String randomDuration() throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newDuration(Dates.Now.date().getTime()).toString();
    }

    private static XMLGregorianCalendar xmlTime(final int hour, final int mins) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendarTime(hour, mins, 0, 0, 0);
    }
}

package com.jpmorgan.hotel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static java.util.Collections.unmodifiableSet;

public class SimpleRoomBookingService implements RoomBookingService {
    private final Map<String, Room> availableRooms = new HashMap<String, Room>();

    @Override
    public double quoteRoom(final String id, final Facility... facilities) {
        final Room room = availableRooms.get(id);
        availableRooms.remove(id);

        return room.calculatePrice(facilities);
    }

    @Override
    public Set<Room> getAvailableRooms() {
        return unmodifiableSet(new HashSet(availableRooms.values()));
    }

    public void addRooms(final Room... rooms){
        for(Room room : rooms) {
            availableRooms.put(room.getId(), room);
        }
    }

}

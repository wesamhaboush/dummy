import org.springframework.stereotype.Repository;

@Repository("personRepository")
public class PersonRepositoryImpl1 implements PersonRepository{
}

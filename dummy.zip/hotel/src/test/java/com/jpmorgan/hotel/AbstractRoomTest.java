package com.jpmorgan.hotel;

import org.junit.Test;

import static org.junit.Assert.*;

public class AbstractRoomTest {

    @Test
    public void getIdWillReturnProvidedId() throws Exception {
        //given
        final String id = "123";

        //when
        final String result = new AbstractRoom(id){}.getId();

        //then
        assertEquals(id, result);
    }
}

package com.jpmorgan.hotel;

import java.util.Set;

public interface RoomBookingService {
    double quoteRoom(String id, Facility... facilities);
    Set<Room> getAvailableRooms();
}

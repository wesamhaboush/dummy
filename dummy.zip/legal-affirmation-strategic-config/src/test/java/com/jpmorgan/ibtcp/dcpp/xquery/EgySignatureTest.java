package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.la.model.generated.DsThunderheadInput;
import com.jpmorgan.dcpp.la.model.generated.SignatureDetails;
import com.jpmorgan.dcpp.la.model.generated.T23Party;
import com.jpmorgan.dcpp.la.model.generated.T25PersonDetail;
import com.jpmorgan.ibtcp.dcpp.la.utils.NullSignatureDetails;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmItem;
import net.sf.saxon.s9api.XdmValue;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Iterators.filter;
import static com.jpmorgan.dcpp.commons.Randoms.randomFrom;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.payload;
import static com.jpmorgan.ibtcp.dcpp.la.model.PayloadBuilder.signatureDetails;
import static java.util.Arrays.asList;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.junit.Assert.assertEquals;

public class EgySignatureTest extends AbstractXqueryTest {

    private static final Map<String, SignatureDetails> SIG_MAP = getSigMap("V337433","U518485","V336606", "R048511");
    private static final String SIGNATURE_COMMODITIES_XQY = "PaperConfirmationBusinessRules/Commodity/signature_commodities.xqy";

    @Test
    public void testRuleMarkedWithMetalSpecific() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V336606";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String baseProduct = "Metals";
        final String caid = "A102826757";
        final DsThunderheadInput inputPayload  = payload()
                .withBaseProduct(baseProduct)
                .withParties(new T23Party().withCaid(caid).withType("RISK_MANAGEMENT_OWNER"))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when

        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());
    }

    @Test
    public void testRuleMarkedWithBaseProductsMarketedFromAsia() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V336606";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String baseProduct = randomFrom("Metals","Agricultural","Energy", "Environmental", "Freight");
        final String salesPersonCity = randomFrom("Seoul", "Tokyo", "Taipei", "Bangkok", "Beijing", "Shanghai", "Hong Kong", "Singapore");
        String type = "SALESPERSON";

        final DsThunderheadInput inputPayload  = payload()
                .withPersonDetail(randomAlphabetic(6), type, salesPersonCity)
                .withBaseProduct(baseProduct)
                .withParties(new T23Party().withSpn(salesPersonCity).withType("COUNTERPARTY"))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()).getPersonDetails().iterator().next(),
                filter(actual.getPersonDetails().getPersonDetails().iterator(), noMatchingId(id)).next());
    }


    @Test
    public void testRuleMarkedWithBaseProductsTradedFromAsia() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V336606";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String baseProduct = randomFrom("Metals", "Agricultural", "Energy", "Environmental", "Freight");
        final String traderCity = randomFrom("Seoul", "Tokyo", "Taipei", "Bangkok", "Beijing", "Shanghai", "Hong Kong", "Singapore");
        String type = "TRADER";

        final DsThunderheadInput inputPayload  = payload()
                .withPersonDetail(randomAlphabetic(6), type, traderCity)
                .withBaseProduct(baseProduct)
                .withParties(new T23Party().withSpn(traderCity).withType("COUNTERPARTY"))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);

        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()).getPersonDetails().iterator().next(),
                filter(actual.getPersonDetails().getPersonDetails().iterator(), noMatchingId(id)).next());
    }

    @Test
    public void testSignatureRulesForCarrieChenWillBeReturnedIfLegalEntityIs_0160() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "U518485";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String legalEntity = "0160";
        final DsThunderheadInput inputPayload  = payload()
                .withParties(new T23Party().withType("RISK_MANAGEMENT_OWNER").withLegalEntity(legalEntity))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());

    }

    @Test
    public void testSignatureRulesForLegalEntitiesSet1_R048511() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "R048511";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String legalEntity = randomFrom("0055","0056","0057","0058","0059","0101","0453","0637");
        final DsThunderheadInput inputPayload  = payload()
                .withParties(new T23Party().withType("RISK_MANAGEMENT_OWNER").withLegalEntity(legalEntity))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getFirst()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getMiddle()
                        , SIG_MAP.get(id).getReferenceData().getWorkerData().getName().getLast()),
                actual.getPersonDetails());

    }

    @Test
    public void testSignatureRulesForLegalEntitiesSet2WithMissingDetails() throws SaxonApiException, IOException, XPathExpressionException {
        //Given
        final String id = "V337433";
        final String xqueryModule = loadModuleAsString(SIGNATURE_COMMODITIES_XQY).replace("lookup:oql($functionName, $id)", xqueryMap(buildOqlLookupFunctionMap(randomAlphanumeric(10), SIG_MAP)));
        final String legalEntity = randomFrom("0051","0052","0096","0099","0387","0528");
        final DsThunderheadInput inputPayload  = payload()
                .withParties(new T23Party().withType("RISK_MANAGEMENT_OWNER").withLegalEntity(legalEntity))
                .build();
        final String payloadXml = getModelFactory().toXml(inputPayload);


        final ImmutableMap<String, String> varValueMap = ImmutableMap.<String, String>builder()
                .put("payload", payloadXml)
                .build();
        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);

        //when
        final XdmValue result = qe.evaluate();

        //then
        final List<XdmItem> resultXdmItems = asList(Iterators.toArray(result.iterator(), XdmItem.class));
        final DsThunderheadInput actual = getModelFactory().fromXml(resultXdmItems.iterator().next().toString(), DsThunderheadInput.class);
        assertEquals(
                personalDetails("SIGNATORY", id,
                        null
                        ,null
                        , null),
                actual.getPersonDetails());

    }



    private Predicate<T25PersonDetail> noMatchingId(final String id) {
        return new Predicate<T25PersonDetail>() {
            @Override
            public boolean apply(final T25PersonDetail t25PersonDetail) {
                return id.equals(t25PersonDetail.getId());
            }
        };
    }



    //utils

    private Map<String[], String> buildOqlLookupFunctionMap(final String match, final Map<String, SignatureDetails> signatureDetailsMap) {
        final ImmutableMap.Builder<String[], String> builder = ImmutableMap.<String[], String>builder();
        builder.put(new String[]{"getDataValueMappingRecordForSignatureRules", "mappingClassification=EDGARRANGINGDESKREGION,SPNType=LOCTOK,spnIdentifierValue=arrangerSpnValue"}, ifMatch(quote(match), "'LOCTOK'"));
        for(Map.Entry<String, SignatureDetails> entry : signatureDetailsMap.entrySet()){
            builder.put(new String[]{"getSignature","id=" + entry.getKey()}, toString(entry));
        }
        return builder.build();
    }

    private static String quote(String match) {
        return '\'' + match + '\'';
    }

    private static String ifMatch(final String v1, final String v2){
        return v1.equals(v2) ? v1 : "()";
    }

   private static String xqueryMap(final Map<String[], String> map){
       final String itemTemplate = "else if( $functionName eq '%s' and $id eq '%s' ) then\n" +
               "%s\n";
       final StringBuilder sb = new StringBuilder();
       for(Map.Entry<String[], String> entry : map.entrySet()){
           sb.append(String.format(itemTemplate, entry.getKey()[0], entry.getKey()[1], entry.getValue()));
       }
       return StringUtils.removeStart(sb.append("else () \n").toString(), "else");
   }

    private static ImmutableMap<String, SignatureDetails> getSigMap(final String...ids) {
        final ImmutableMap.Builder<String, SignatureDetails> sigMapBuilder = ImmutableMap.<String, SignatureDetails>builder();
        for(String id : ids){
            if("V337433".equals(id)) {
                sigMapBuilder.put(id, new NullSignatureDetails());
            } else {
                sigMapBuilder.put(id, signatureDetails(randomAlphabetic(5), randomAlphabetic(6), randomAlphabetic(7)));
            }
        }
        return sigMapBuilder.build();
    }


}

package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.ObjectUtils;
import org.junit.Test;

import java.util.Set;
import java.util.UUID;

import static com.google.common.collect.Sets.newHashSet;
import static com.jpmorgan.dcpp.commons.Integers.range;
import static com.jpmorgan.dcpp.commons.Uuids.RANDOM_UUID_FACTORY;
import static org.junit.Assert.assertEquals;

public class UuidsTest {
    @Test
    public void testRandomUuidFactoryCreatesNotEqualInstances(){
        //given
        final Set<UUID> uuids = newHashSet();
        final int count = 10;

        //when
        for(final Integer i : range(0, count)){
            uuids.add(RANDOM_UUID_FACTORY.create(ObjectUtils.NULL));
        }

        //then
        assertEquals(count, uuids.size());
    }
}

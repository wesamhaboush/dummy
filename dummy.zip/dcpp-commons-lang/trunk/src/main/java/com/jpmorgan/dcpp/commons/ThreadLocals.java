package com.jpmorgan.dcpp.commons;

import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;

import static com.jpmorgan.dcpp.commons.Objects.isNull;

public class ThreadLocals {
    private static final transient Logger LOGGER = Slf4jLoggerFactory.create();

    private static final ThreadLocal<Map<Object, Object>> THREAD_LOCAL = new ThreadLocal<Map<Object, Object>>(){
        @Override
        protected Map<Object, Object> initialValue() {
            LOGGER.debug("THREAD_LOCAL created for thread [{}]", Thread.currentThread().getId());
            return new HashMap<Object, Object>();
        }
    };


    public static <T> T getTLO(final Object key, final Class<T> type) {
        return type.cast(THREAD_LOCAL.get().get(key));
    }

    public static  void putTlo(final Object key, final Object value) {
        THREAD_LOCAL.get().put(key, value);
        LOGGER.debug("Thread object added [{} -> {}]", key, value);
    }

    public static void putTloIfAbsent(final Object key, final Object value) {
        if(!THREAD_LOCAL.get().containsKey(key)){
            putTlo(key, value);
        }
        LOGGER.debug("Thread object added [{} -> {}]", key, value);
    }

    public  static void clear(){
        THREAD_LOCAL.get().clear();
    }

    public static void destroy(){
        THREAD_LOCAL.remove();
    }

    public static void remove(final Object key){
        THREAD_LOCAL.get().remove(key);
    }
}

package com.jpmorgan.dcpp.commons.caching;

public interface CacheService<K,V> {
    void put(K key, V value);
    V get(K key);
    void clear();
    boolean remove(K key);
}

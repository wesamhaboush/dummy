package com.jpmorgan.dcpp.commons;

import org.apache.commons.lang3.Validate;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

public class Classes {
  private Classes() {
  }

  public static <T> boolean isArray(final T t) {
    Validate.notNull(t, "cannot tell if a null object is an array or not. It can be either or neither");
    return t.getClass().isArray();
  }

  /**
   * Note: this method returns the runtime value, not the compile time class,
   * this could mean for example it will return an anonymous class in runtime
   * if the compiler optimizes the code by generating one (enums implementing
   * interfaces per member for example)
   *
   * @return The class from which the current method was invoked
   */
  public static Class<?> getInvokerClassOfCurrentMethod() {
    final Class<?>[] classes = new ClassesHelper().getClassContext();
    return classes[3];
  }

  public static Class<?> getCurrentClass() {
    return new ClassesHelper().getClassContext()[2];
  }

  /**
   * Note: This should be used because it copes with cases when we run within
   * containers as well as outside them.
   *
   * @return
   */
  public static ClassLoader getClassLoader() {
    final ClassLoader loader = Thread.currentThread().getContextClassLoader();
    return loader != null ? loader : getCurrentClass().getClassLoader();
  }

  public static List<String> getClasspathItems() {
    final ClassLoader cl = getClassLoader();

    final URL[] urls = ((URLClassLoader) cl).getURLs();
    final List<String> classpathItems = newArrayList();
    for (final URL url : urls) {
      classpathItems.add(url.getFile());
    }
    return classpathItems;
  }

  private static final class ClassesHelper extends SecurityManager {
    @Override
    protected Class<?>[] getClassContext() {
      return super.getClassContext();
    }
  }
}

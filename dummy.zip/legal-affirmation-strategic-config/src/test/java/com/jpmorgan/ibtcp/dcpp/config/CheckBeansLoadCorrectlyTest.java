package com.jpmorgan.ibtcp.dcpp.config;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.reflect.ClassPath;
import com.jpmorgan.dcpp.commons.Classes;
import fj.F;
import fj.F2;
import fj.Ord;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.*;
import org.junit.Test;

import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import static com.google.common.base.Predicates.containsPattern;
import static com.google.common.base.Predicates.in;
import static com.google.common.base.Predicates.not;
import static com.google.common.base.Throwables.propagate;
import static com.google.common.collect.Collections2.transform;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.filter;
import static com.google.common.collect.Sets.newHashSet;
import static com.google.common.collect.Sets.newTreeSet;
import static com.jpmorgan.dcpp.commons.Classpath.resourceAsString;
import static com.jpmorgan.dcpp.commons.Xmls.xpathValues;
import static fj.data.Set.iterableSet;
import static junit.framework.Assert.assertEquals;
import static org.apache.commons.io.FileUtils.getFile;
import static org.apache.commons.io.FileUtils.readLines;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class CheckBeansLoadCorrectlyTest {

    private static final String RESOURCE_NAMES_FROM_LOOKUP_STEPS_XPATH = "/*:beans/*:bean[@class = 'com.jpmorgan.ibtcp.dcpp.la.dataObject.Step']/*:property[@name ='resourceName']/@value";
    private static final String STEP_BEAN_IDS_FROM_LOOKUP_STEPS_XPATH = "/*:beans/*:bean[@class = 'com.jpmorgan.ibtcp.dcpp.la.dataObject.Step']/@id";

    private static final String STEPS_BEAN_IDS_FROM_GDF_REQUEST_XPATH = "/*:beans/*:bean[@class = 'java.util.ArrayList' and contains(lower-case(@id), 'steps')]/*:constructor-arg/*:list/*:ref/@bean";
    private static final String RESOURCE_BEAN_IDS_FROM_GDF_REQUEST_XPATH = "/*:beans/*:bean[@class = 'java.util.ArrayList' and contains(lower-case(@id), 'resources')]/*:constructor-arg/*:list/*:ref/@bean";

    private static final String RESOURCE_NAMES_FROM_RESOURCES_XPATH = "/*:beans/*:bean[@class = 'com.jpmorgan.ibtcp.dcpp.la.dataObject.Resource']/*:property[@name ='resourceName']/@value";
    private static final String RESOURCE_BEAN_IDS_FROM_RESOURCES_XPATH = "/*:beans/*:bean[@class = 'com.jpmorgan.ibtcp.dcpp.la.dataObject.Resource']/@id";
    private static final String PAPER_CONFIRMATION_BUSINESS_RULES_XMLS_REG_PATTERN = ".*PaperConfirmationBusinessRules.*\\.xml";

    @Test
    public void testAllStepsFromLookUpStepsFileAreConfiguredInGdfRequestXmlFile() throws IOException, XPathExpressionException {
        //given
        final String gdfRequestXml = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/gdfRequest.xml"));
        final String lookUpStepsXml = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Common/lookupsStep.xml"));
        final Set<String> stepBeanIdsFromGdfRequest = newHashSet(xpathValues(gdfRequestXml, STEPS_BEAN_IDS_FROM_GDF_REQUEST_XPATH));
        final Set<String> stepBeanIdsFromLookUpStepsXml = newHashSet(xpathValues(lookUpStepsXml, STEP_BEAN_IDS_FROM_LOOKUP_STEPS_XPATH));


        //then
        assertFalse(stepBeanIdsFromGdfRequest.isEmpty());
        assertFalse(stepBeanIdsFromLookUpStepsXml.isEmpty());
        assertEquals("diff: " + CollectionUtils.disjunction(stepBeanIdsFromLookUpStepsXml, stepBeanIdsFromGdfRequest), stepBeanIdsFromLookUpStepsXml, stepBeanIdsFromGdfRequest);
    }

    @Test
    public void testAllResourcesFromResourceFilesAreConfiguredInGdfRequestXmlFile() throws IOException, XPathExpressionException {
        //given
        final String gdfRequestXml = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/gdfRequest.xml"));
        final Set<String> resourceBeanIdsFromGdfRequest = newHashSet(xpathValues(gdfRequestXml, RESOURCE_BEAN_IDS_FROM_GDF_REQUEST_XPATH));

        final Set<ClassPath.ResourceInfo> allClasspathResources = ClassPath.from(this.getClass().getClassLoader()).getResources();

        final Set<ClassPath.ResourceInfo> xmlResourceInfosInPaperConfirmationDirOnClasspath = filter(allClasspathResources, onlyXmlsInPaperConfirmationDirFromClasspath());
        final Set<String> xmlFileNames = newHashSet(transform(xmlResourceInfosInPaperConfirmationDirOnClasspath, toResourceNamesAsStrings()));
        final Collection<String> resourceNamesFromResourceBeans = iterableSet(Ord.stringOrd, xmlFileNames).toStream().foldLeft(toBeanIdsFromResourceBeans(), Sets.<String>newHashSet());


        //then
        assertFalse(resourceNamesFromResourceBeans.isEmpty());
        assertFalse(resourceBeanIdsFromGdfRequest.isEmpty());
        assertEquals("diff: " + CollectionUtils.disjunction(resourceBeanIdsFromGdfRequest, resourceNamesFromResourceBeans), resourceBeanIdsFromGdfRequest, resourceNamesFromResourceBeans);
    }

    @Test
    public void testBeansAllResourcesInStepsHaveMatchingResourcesInXmlResourceFiles() throws IOException, XPathExpressionException {
        //given
        final String lookUpStepsResourceXml = IOUtils.toString(Classes.getClassLoader().getResourceAsStream("PaperConfirmationBusinessRules/Common/lookupsStep.xml"));
        final List<String> resourceNamesFromLookUpSteps = xpathValues(lookUpStepsResourceXml, RESOURCE_NAMES_FROM_LOOKUP_STEPS_XPATH);

        final Set<ClassPath.ResourceInfo> allClasspathResources = ClassPath.from(this.getClass().getClassLoader()).getResources();
        final Set<ClassPath.ResourceInfo> xmlResourceInfosInPaperConfirmationDirOnClasspath = filter(allClasspathResources, onlyXmlsInPaperConfirmationDirFromClasspath());
        final Set<String> xmlFileNames = newHashSet(transform(xmlResourceInfosInPaperConfirmationDirOnClasspath, toResourceNamesAsStrings()));
        final Collection<String> resourceNamesFromResourceBeans = iterableSet(Ord.stringOrd, xmlFileNames).toStream().foldLeft(toResourceNamesFromResourceBeans(), Sets.<String>newHashSet());

        //when
        //nothing

        //then
        assertFalse(resourceNamesFromLookUpSteps.isEmpty());
        assertFalse(resourceNamesFromResourceBeans.isEmpty());
        assertTrue(String.format("not all resources name in %s  correspond to resources in %s this test fails whenever this happens. Ensure all steps correspond to resources",
                resourceNamesFromLookUpSteps, resourceNamesFromResourceBeans)
                , iterableSet(Ord.stringOrd, resourceNamesFromLookUpSteps).filter(stepsThatDoNotCorrespondToResourceBeans(resourceNamesFromResourceBeans)).isEmpty());
        assertTrue(Iterables.all(resourceNamesFromLookUpSteps, hasACorrespondingResourceNameInBeans(resourceNamesFromResourceBeans)));
    }

    @Test
    public void testAllFilesInResourcesExistInInstallListFile() throws IOException {
        //given
        //get all subfolders of resources and subtract xsd and binding, and then find all files within the rest
        final File resourcesDir = new File("./src/main/resources/");
        final Set<String> resourcesSubdirs = newHashSet(resourcesDir.list(DirectoryFileFilter.INSTANCE));
        final Set<String> targetResourcesSubdirs = filter(resourcesSubdirs, not(in(newArrayList("xsd", "bindings"))));
        final Set<ClassPath.ResourceInfo> allClasspathResources = ClassPath.from(this.getClass().getClassLoader()).getResources();
        final Set<ClassPath.ResourceInfo> resourceInfosInTargetDirs = filter(allClasspathResources, onlyResourcesInTargetDirs(targetResourcesSubdirs));
        final Set<String> resourceNamesInTargetDirs = newHashSet(transform(resourceInfosInTargetDirs, toResourceNamesWithoutFolderNames()));
        final Set<String> fileLinesInInstallList = Sets.filter(newHashSet(readLines(getFile("./slab/components/legal-affirmation-strategic-config/installList"))), containsPattern("^file\\s+555"));
        final Set<String> fileLinesInInstallListWithoutFile555 = newHashSet(Lists.transform(newArrayList(fileLinesInInstallList), toFileNamesOnly()));


        //when

        //then
        assertTrue(!fileLinesInInstallListWithoutFile555.isEmpty());
        assertTrue(!resourceNamesInTargetDirs.isEmpty());
        assertEquals("diff:" + CollectionUtils.disjunction(fileLinesInInstallListWithoutFile555, resourceNamesInTargetDirs),
                fileLinesInInstallListWithoutFile555, resourceNamesInTargetDirs);
    }

    private Function<String, String> toFileNamesOnly() {
        return new Function<String, String>() {
            @Override
            public String apply(final String input) {
                return input.replaceAll("file\\s+555\\s+", "").trim();
            }
        };
    }

    private Predicate<String> hasACorrespondingResourceNameInBeans(final Collection<String> resourceNamesFromResourceBeans) {
        return new Predicate<String>() {
            @Override
            public boolean apply(final String resourceNameFromLookupSteps) {
                return resourceNamesFromResourceBeans.contains(resourceNameFromLookupSteps);
            }
        };
    }

    private F<String, Boolean> stepsThatDoNotCorrespondToResourceBeans(final Collection<String> resourceNamesFromResourceBeans) {
        return new F<String, Boolean>() {
            @Override
            public Boolean f(final String resourceNameFromLookupSteps) {
                return !resourceNamesFromResourceBeans.contains(resourceNameFromLookupSteps);
            }
        };
    }

    private F2<Collection<String>, String, Collection<String>> toResourceNamesFromResourceBeans() {
        return new F2<Collection<String>, String, Collection<String>>() {
            @Override
            public Collection<String> f(final Collection<String> accumulator, final String xmlName) {
                final String xml = resourceAsString(xmlName);
                final List<String> resourceNameList = silentXpathValues(xml, RESOURCE_NAMES_FROM_RESOURCES_XPATH);
                accumulator.addAll(resourceNameList);
                return accumulator;
            }
        };
    }

    private F2<Collection<String>, String, Collection<String>> toBeanIdsFromResourceBeans() {
        return new F2<Collection<String>, String, Collection<String>>() {
            @Override
            public Collection<String> f(final Collection<String> accumulator, final String xmlName) {
                final String xml = resourceAsString(xmlName);
                final List<String> resourceNameList = silentXpathValues(xml, RESOURCE_BEAN_IDS_FROM_RESOURCES_XPATH);
                accumulator.addAll(resourceNameList);
                return accumulator;
            }
        };
    }

    private Predicate<ClassPath.ResourceInfo> onlyXmlsInPaperConfirmationDirFromClasspath() {
        return new Predicate<ClassPath.ResourceInfo>() {
            @Override
            public boolean apply(final ClassPath.ResourceInfo resourceInfo) {
                return resourceInfo.getResourceName().matches(PAPER_CONFIRMATION_BUSINESS_RULES_XMLS_REG_PATTERN);
            }
        };
    }

    private Predicate<ClassPath.ResourceInfo> onlyResourcesInTargetDirs(final Set<String> targetDirs) {
        return new Predicate<ClassPath.ResourceInfo>() {
            @Override
            public boolean apply(final ClassPath.ResourceInfo resourceInfo) {
                return Iterables.any(targetDirs, new Predicate<String>() {
                    @Override
                    public boolean apply(final String input) {
                        return resourceInfo.getResourceName().startsWith(input);
                    }
                });
            }
        };
    }

    private Function<ClassPath.ResourceInfo, String> toResourceNamesAsStrings() {
        return new Function<ClassPath.ResourceInfo, String>() {
            @Override
            public String apply(final ClassPath.ResourceInfo resourceInfo) {
                return resourceInfo.getResourceName();
            }
        };
    }

    private Function<ClassPath.ResourceInfo, String> toResourceNamesWithoutFolderNames() {
        return new Function<ClassPath.ResourceInfo, String>() {
            @Override
            public String apply(final ClassPath.ResourceInfo resourceInfo) {
                return resourceInfo.getResourceName().substring(resourceInfo.getResourceName().lastIndexOf('/') + 1);
            }
        };
    }

    private List<String> silentXpathValues(final String xml, final String xpath) {
        try {
            return xpathValues(xml, xpath);
        } catch (XPathExpressionException e) {
            throw propagate(e);
        }
    }
}

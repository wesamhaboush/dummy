package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import static com.jpmorgan.dcpp.commons.Randoms.*;
import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


public class EqualsTest {

    @Test
    public void testAreEqualWithBooleanAndBoolean() {
        assertTrue(Equals.areEqual(true, true));
        assertTrue(Equals.areEqual(false, false));
        assertFalse(Equals.areEqual(true, false));
        assertFalse(Equals.areEqual(false, true));
    }

    @Test
    public void testAreEqualWithIntAndInt() {
        final int int1 = randomInt();
        final int int2 = randomInt();
        assertTrue(Equals.areEqual(int1, int1));
        assertTrue(Equals.areEqual(int2, int2));
        assertFalse(Equals.areEqual(int1, int2));
        assertFalse(Equals.areEqual(int2, int1));
    }

    @Test
    public void testAreEqualWithCharandChar() {
        final char char1 = randomChar();
        final char char2 = randomChar();
        assertTrue(Equals.areEqual(char1, char1));
        assertTrue(Equals.areEqual(char2, char2));
        assertFalse(Equals.areEqual(char1, char2));
        assertFalse(Equals.areEqual(char2, char1));
    }

    @Test
    public void testAreEqualWithShortAndShort() {
        final short short1 = randomShort();
        final short short2 = randomShort();
        assertTrue(Equals.areEqual(short1, short1));
        assertTrue(Equals.areEqual(short2, short2));
        assertFalse(Equals.areEqual(short1, short2));
        assertFalse(Equals.areEqual(short2, short1));
    }

    @Test
    public void testAreEqualWithByteAndByte() {
        final byte byte1 = randomByte();
        final byte byte2 = different(byte1);
        assertTrue(Equals.areEqual(byte1, byte1));
        assertTrue(Equals.areEqual(byte2, byte2));
        assertFalse(Equals.areEqual(byte1, byte2));
        assertFalse(Equals.areEqual(byte2, byte1));
    }

    private byte different(byte byte1) {
        byte otherByte = randomByte();
        while( otherByte == byte1){
            otherByte = randomByte();
        }
        return otherByte;
    }

    @Test
    public void testAreEqualWithLongAndLong() {
        final long long1 = randomLong();
        final long long2 = randomLong();
        assertTrue(Equals.areEqual(long1, long1));
        assertTrue(Equals.areEqual(long2, long2));
        assertFalse(Equals.areEqual(long1, long2));
        assertFalse(Equals.areEqual(long2, long1));
    }

    @Test
    public void testAreEqualWithFloatAndFloat() {
        final float float1 = randomFloat();
        final float float2 = randomFloat();
        assertTrue(Equals.areEqual(float1, float1));
        assertTrue(Equals.areEqual(float2, float2));
        assertFalse(Equals.areEqual(float1, float2));
        assertFalse(Equals.areEqual(float2, float1));
    }

    @Test
    public void testAreEqualWithDoubleAndDouble() {
        final double double1 = randomDouble();
        final double double2 = randomDouble();
        assertTrue(Equals.areEqual(double1, double1));
        assertTrue(Equals.areEqual(double2, double2));
        assertFalse(Equals.areEqual(double1, double2));
        assertFalse(Equals.areEqual(double2, double1));
    }

    @Test
    public void testAreEqualWithGenericTypeAndGenericType() {
        final String s1 = randomAlphanumeric(nextInt(0, 50));
        final String s2 = randomAlphanumeric(nextInt(0, 50));
        final String s3 = new String(s1);

        assertTrue(Equals.areEqual(s1, s1));
        assertTrue(Equals.areEqual(s2, s2));
        assertTrue(Equals.areEqual(s1, s3));
        assertFalse(Equals.areEqual(s1, s2));
        assertFalse(Equals.areEqual(s2, s1));
    }

    @Test
    public void testAreArraysEqual() {
        //given
        final String[] s1 = randomArray(String[].class, randomStringFactory(nextInt(1, 50)), nextInt(1, 50));
        final String[] s2 = randomArray(String[].class, randomStringFactory(nextInt(1, 50)),  nextInt(1, 50));
        final String[] s3 = new String[s1.length];
        System.arraycopy(s1, 0, s3, 0, s1.length);

        //then
        assertTrue(Equals.areArraysEqual(s1, s1));
        assertTrue(Equals.areArraysEqual(s2, s2));
        assertTrue(Equals.areArraysEqual(s1, s3));

        assertFalse(Equals.areArraysEqual(s1, s2));
        assertFalse(Equals.areArraysEqual(s2, s1));
        assertFalse(Equals.areArraysEqual(s2, s3));

        //empty arrays are equal
        assertTrue(Equals.areArraysEqual(new String[0], new String[0]));
        assertTrue(Equals.areArraysEqual(new String[0], new Object[0]));

        //nulls?
        assertTrue(Equals.areArraysEqual(null, null));
    }

    @Test
    public void testAreEqualWith4ArgsWithDoubleWhenNotEqual() {
        final int ulps = 10;
        final double target = randomDouble();

        final double value1 = target + 2 * Math.ulp(target);
        final double value2 = target - 2 * Math.ulp(target);

        final double value3 = target + 4 * Math.ulp(target);
        final double value4 = target - 4 * Math.ulp(target);

        final double value5 = target + 6 * Math.ulp(target);
        final double value6 = target - 6 * Math.ulp(target);

        final double value7 = target + 8 * Math.ulp(target);
        final double value8 = target - 8 * Math.ulp(target);

        final double value9 = target + 10 * Math.ulp(target);
        final double value10 = target - 10 * Math.ulp(target);

        final double value11 = target + 11 * Math.ulp(target);
        final double value12 = target - 11 * Math.ulp(target);

        final double value13 = target + 13 * Math.ulp(target);
        final double value14 = target - 13 * Math.ulp(target);

        assertTrue(Equals.areEqual(target, value1, target, ulps));
        assertTrue(Equals.areEqual(target, value2, target, ulps));
        assertTrue(Equals.areEqual(target, value3, target, ulps));
        assertTrue(Equals.areEqual(target, value4, target, ulps));
        assertTrue(Equals.areEqual(target, value5, target, ulps));
        assertTrue(Equals.areEqual(target, value6, target, ulps));
        assertTrue(Equals.areEqual(target, value7, target, ulps));
        assertTrue(Equals.areEqual(target, value8, target, ulps));
        assertTrue(Equals.areEqual(target, value9, target, ulps));
        assertTrue(Equals.areEqual(target, value10, target, ulps));
        assertFalse(Equals.areEqual(target, value11, target, ulps));
        assertFalse(Equals.areEqual(target, value12, target, ulps));
        assertFalse(Equals.areEqual(target, value13, target, ulps));
        assertFalse(Equals.areEqual(target, value14, target, ulps));
    }

    @Test
    public void testAreEqualWith4ArgsFloat() {
        final int ulps = 10;
        final float target = randomFloat();

        final float value1 = target + 2 * Math.ulp(target);
        final float value2 = target - 2 * Math.ulp(target);

        final float value3 = target + 4 * Math.ulp(target);
        final float value4 = target - 4 * Math.ulp(target);

        final float value5 = target + 6 * Math.ulp(target);
        final float value6 = target - 6 * Math.ulp(target);

        final float value7 = target + 8 * Math.ulp(target);
        final float value8 = target - 8 * Math.ulp(target);

        final float value9 = target + 10 * Math.ulp(target);
        final float value10 = target - 10 * Math.ulp(target);

        final float value11 = target + 11 * Math.ulp(target);
        final float value12 = target - 11 * Math.ulp(target);

        final float value13 = target + 13 * Math.ulp(target);
        final float value14 = target - 13 * Math.ulp(target);

        assertTrue(Equals.areEqual(target, value1, target, ulps));
        assertTrue(Equals.areEqual(target, value2, target, ulps));
        assertTrue(Equals.areEqual(target, value3, target, ulps));
        assertTrue(Equals.areEqual(target, value4, target, ulps));
        assertTrue(Equals.areEqual(target, value5, target, ulps));
        assertTrue(Equals.areEqual(target, value6, target, ulps));
        assertTrue(Equals.areEqual(target, value7, target, ulps));
        assertTrue(Equals.areEqual(target, value8, target, ulps));
        assertTrue(Equals.areEqual(target, value9, target, ulps));
        assertTrue(Equals.areEqual(target, value10, target, ulps));
        assertFalse(Equals.areEqual(target, value11, target, ulps));
        assertFalse(Equals.areEqual(target, value12, target, ulps));
        assertFalse(Equals.areEqual(target, value13, target, ulps));
        assertFalse(Equals.areEqual(target, value14, target, ulps));
    }

    @Test
    public void testAllEqual() {
        assertTrue(Equals.allEqual(null, null));
        assertTrue(Equals.allEqual(null, null, null));
        assertTrue(Equals.allEqual("A", "A"));
        assertTrue(Equals.allEqual("A", "A", "A"));

        assertFalse(Equals.allEqual(null, "A"));
        assertFalse(Equals.allEqual(null, "A", "B"));
        assertFalse(Equals.allEqual(null, "A", "A"));
        assertFalse(Equals.allEqual(null, "A", "A", null));
        assertFalse(Equals.allEqual("A", "A", null));
    }

    @Test(expected=RuntimeException.class)
    public void testAllEqualExceptionCaseWithNullArray() {
        Equals.allEqual(null);
    }

    @Test(expected = RuntimeException.class)
    public void testAllEqualExceptionCaseWithEmptyArray() {
        Equals.allEqual(new Object[]{});
    }

}

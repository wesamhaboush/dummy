package com.jpmorgan.dcpp.commons;

import org.apache.commons.collections.CollectionUtils;

import java.util.*;

public class Collections2 {

  public static <T> Collection<T> emptyIfNull(final Collection<T> ts){
    return ts == null ? Collections.<T>emptySet() : ts;
  }

  public static <T> Set<T> emptyIfNull(final Set<T> ts){
    return ts == null ? Collections.<T>emptySet() : ts;
  }

  public static <T> List<T> emptyIfNull(final List<T> ts){
    return ts == null ? Collections.<T>emptyList() : ts;
  }

  public static <K,V> Map<K,V> emptyIfNull(final Map<K,V> ts){
    return ts == null ? Collections.<K,V>emptyMap() : ts;
  }

  public static <T> Collection<T> emptyCollection(final Class<T> clazz){
    return (Collection<T>)CollectionUtils.EMPTY_COLLECTION;
  }

  public static <T> List<T> emptyList(final Class<T> clazz){
    return Collections.<T>emptyList();
  }

  public static <T> Set<T> emptySet(final Class<T> clazz){
    return Collections.<T>emptySet();
  }

  public static <K,V> Map<K,V> emptyMap(final Class<K> k, final Class<V> v){
    return Collections.<K,V>emptyMap();
  }

}

package com.jpmorgan.dcpp.commons.xml;

import java.io.StringWriter;

public class StringXml implements PrologOrXmlElement, XmlStartTag {

  private final Xml wax;
  private final StringWriter stringWriter;

  public StringXml() {
    this.stringWriter = new StringWriter();
    this.wax = new Xml(stringWriter);
  }

  public StringXml(Version version) {
    this.stringWriter = new StringWriter();
    this.wax = new Xml(stringWriter, version);
  }

  public StringXml includeFinalNewline() {
    wax.includeFinalNewline();
    return this;
  }

  public StringXml excludeFinalNewline() {
    wax.excludeFinalNewline();
    return this;
  }

  public StringXml attr(String name, Object value) {
    wax.attr(name, value);
    return this;
  }

  public StringXml attr(String prefix, String name, Object value) {
    wax.attr(prefix, name, value);
    return this;
  }

  public StringXml attr(
          String prefix, String name, Object value, boolean newLine) {
    wax.attr(prefix, name, value, newLine);
    return this;
  }

  public StringXml blankLine() {
    wax.blankLine();
    return this;
  }

  public StringXml cdata(String text) {
    wax.cdata(text);
    return this;
  }

  public StringXml cdata(String text, boolean newLine) {
    wax.cdata(text, newLine);
    return this;
  }

  public StringXml child(String name) {
    wax.child(name);
    return this;
  }

  public StringXml child(String name, String text) {
    wax.child(name, text);
    return this;
  }

  public StringXml child(String prefix, String name, String text) {
    wax.child(prefix, name, text);
    return this;
  }

  public void close() {
    wax.close();
  }

  public String get() {
    return stringWriter.toString();
  }

  public String closeAndGet() {
    wax.close();
    return stringWriter.toString();
  }

  public StringXml comment(String text) {
    wax.comment(text);
    return this;
  }

  public StringXml comment(String text, boolean newLine) {
    wax.comment(text, newLine);
    return this;
  }

  public StringXml commentedStart(String name) {
    wax.commentedStart(name);
    return this;
  }

  public StringXml commentedStart(String prefix, String name) {
    wax.commentedStart(prefix, name);
    return this;
  }

  public StringXml defaultNamespace(String uri) {
    wax.defaultNamespace(uri);
    return this;
  }

  public StringXml defaultNamespace(String uri, String schemaPath) {
    wax.defaultNamespace(uri, schemaPath);
    return this;
  }

  public StringXml defaultNS(String uri) {
    wax.defaultNS(uri);
    return this;
  }

  public StringXml defaultNS(String uri, String schemaPath) {
    wax.defaultNS(uri, schemaPath);
    return this;
  }

  public StringXml dtd(String systemId) {
    wax.dtd(systemId);
    return this;
  }

  public StringXml dtd(String publicId, String systemId) {
    wax.dtd(publicId, systemId);
    return this;
  }

  public StringXml end() {
    wax.end();
    return this;
  }

  public StringXml end(boolean verbose) {
    wax.end(verbose);
    return this;
  }

  public StringXml entityDef(String name, String value) {
    wax.entityDef(name, value);
    return this;
  }

  public StringXml externalEntityDef(String name, String filePath) {
    wax.externalEntityDef(name, filePath);
    return this;
  }

  public String getIndent() {
    return wax.getIndent();
  }

  public StringXml setIndent(int numSpaces) {
    wax.setIndent(numSpaces);
      return this;
  }

  public String getLineSeparator() {
    return wax.getLineSeparator();
  }

  public StringXml setLineSeparator(String lineSeparator) {
    wax.setLineSeparator(lineSeparator);
      return this;
  }

  public String getSchemaVersion() {
    return wax.getSchemaVersion();
  }

  public StringXml setSchemaVersion(String version) {
    wax.setSchemaVersion(version);
      return this;
  }

  public boolean isSpaceInEmptyElements() {
    return wax.isSpaceInEmptyElements();
  }

  public StringXml setSpaceInEmptyElements(boolean spaceInEmptyElements) {
    wax.setSpaceInEmptyElements(spaceInEmptyElements);
      return this;
  }

  public boolean isTrustMe() {
    return wax.isTrustMe();
  }

  public StringXml setTrustMe(boolean trustMe) {
    wax.setTrustMe(trustMe);
      return this;
  }

  public StringXml namespace(String prefix, String uri) {
    wax.namespace(prefix, uri);
    return this;
  }

  public StringXml namespace(
          String prefix, String uri, String schemaPath) {
    wax.namespace(prefix, uri, schemaPath);
    return this;
  }

  public StringXml ns(String prefix, String uri) {
    wax.ns(prefix, uri);
    return this;
  }

  public StringXml ns(
          String prefix, String uri, String schemaPath) {
    wax.ns(prefix, uri, schemaPath);
    return this;
  }

  public StringXml pi(String target, String data) {
    wax.pi(target, data);
    return this;
  }

  public StringXml processingInstruction(String target, String data) {
    wax.processingInstruction(target, data);
    return this;
  }

  public StringXml setIndent(String indent) {
    wax.setIndent(indent);
      return this;
  }

  public StringXml noIndentsOrLineSeparators() {
    wax.noIndentsOrLineSeparators();
      return this;
  }

  public StringXml start(String name) {
    wax.start(name);
    return this;
  }

  public StringXml start(String prefix, String name) {
    wax.start(prefix, name);
    return this;
  }

  public StringXml text(String text) {
    wax.text(text);
    return this;
  }

  public StringXml text(String text, boolean newLine) {
    wax.text(text, newLine);
    return this;
  }

  public StringXml unescapedAttr(String name, Object value) {
    wax.unescapedAttr(name, value);
    return this;
  }

  public StringXml unescapedAttr(String prefix, String name, Object value) {
    wax.unescapedAttr(prefix, name, value);
    return this;
  }

  public StringXml unescapedAttr(String prefix, String name, Object value, boolean newLine) {
    wax.unescapedAttr(prefix, name, value, newLine);
    return this;
  }

  public StringXml unescapedText(String text) {
    wax.unescapedText(text);
    return this;
  }

  public StringXml unescapedText(String text, boolean newLine) {
    wax.unescapedText(text, newLine);
    return this;
  }

  public StringXml xslt(String filePath) {
    wax.xslt(filePath);
    return this;
  }
}
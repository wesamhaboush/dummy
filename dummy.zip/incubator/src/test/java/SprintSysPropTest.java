import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.management.*;
import javax.management.remote.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Set;

public class SprintSysPropTest {
    @Test
    public void testSystemProperty() {
        final ApplicationContext applicationContext = new ClassPathXmlApplicationContext("app-context.xml");
        final String message1 =  applicationContext.getBean("message1", String.class);
        final String message2 =  applicationContext.getBean("message2", String.class);
        final String message3 =  applicationContext.getBean("message3", String.class);
        final String message4 =  applicationContext.getBean("message4", String.class);
        System.out.println("messages read: " + Arrays.asList(message1, message2, message3, message4));
    }

    @Test
    public void testJmx() throws IOException, MalformedObjectNameException, IntrospectionException, InstanceNotFoundException, ReflectionException {
        final ApplicationContext applicationContext = new ClassPathXmlApplicationContext("app-context.xml");
        MBeanServer mbs =  applicationContext.getBean("mbeanServer", MBeanServer.class);
        final Set<ObjectName> objectNames = mbs.queryNames(null, null);
        for (ObjectName name : objectNames) {
            MBeanInfo info = mbs.getMBeanInfo(name);
            System.out.println(info);
        }
// Make a connector server...
        JMXServiceURL url = new JMXServiceURL("service:jmx:rmi://");
        JMXConnectorServer cs =
                JMXConnectorServerFactory.newJMXConnectorServer(url, null, mbs);
        cs.start();
        JMXConnector cc = null;
        try {
            JMXServiceURL addr = cs.getAddress();

            // Now make a connector client using the server's address
            cc = JMXConnectorFactory.connect(addr);
            MBeanServerConnection mbsc = cc.getMBeanServerConnection();
            final Set<ObjectName> objectNames1 = mbsc.queryNames(null, null);
            for (ObjectName name : objectNames1) {
                MBeanInfo info = mbs.getMBeanInfo(name);
                System.out.println(info);
            }
            System.out.println(mbsc.getMBeanCount());
            System.out.println(Arrays.toString(mbsc.getDomains()));
//            ...test logic here, using mbsc...
//            ...e.g. String attr = (String) mbsc.getAttribute(objectName, "MyAttr");
//            ...or   mbsc.addNotificationListener(objectName, listener, filter, null);
        } finally {
            if (cc != null)
                cc.close();
            cs.stop();
        }
    }

}

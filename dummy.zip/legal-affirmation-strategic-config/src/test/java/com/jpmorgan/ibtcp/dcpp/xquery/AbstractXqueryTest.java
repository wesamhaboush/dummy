package com.jpmorgan.ibtcp.dcpp.xquery;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterators;
import com.jpmorgan.dcpp.commons.Classes;
import com.jpmorgan.dcpp.commons.logging.slf4j.Slf4jLoggerFactory;
import com.jpmorgan.dcpp.la.model.generated.*;
import com.jpmorgan.ibtcp.dcpp.la.utils.ModelFactory;
import com.jpmorgan.ibtcp.dcpp.la.utils.NullSignatureDetails;
import net.sf.saxon.event.Builder;
import net.sf.saxon.lib.FeatureKeys;
import net.sf.saxon.lib.ModuleURIResolver;
import net.sf.saxon.s9api.*;
import net.sf.saxon.trans.XPathException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.google.common.base.Throwables.propagate;

public class AbstractXqueryTest {
    private static final transient Logger LOGGER = Slf4jLoggerFactory.create();
    private static final ModelFactory MODEL_FACTORY = new ModelFactory(true);

    private static final ObjectFactory OBJECT_FACTORY = new ObjectFactory();

    protected static String loadModuleAsString(String moduleName) throws IOException {
        return IOUtils.toString(Classes.getClassLoader().getResourceAsStream(moduleName));
    }

    protected static String removePrelog(final String xml) {
        return xml.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
    }

    protected static T2PersonDetails personalDetails(String type, String id, String firstName, String middleName, String lastname) {
        return OBJECT_FACTORY.createT2PersonDetails()
                .withPersonDetails(OBJECT_FACTORY.createT25PersonDetail()
                        .withType(type)
                        .withId(id)
                        .withFirstName(firstName)
                        .withSecondName(middleName)
                        .withSurname(lastname));
    }

    protected static XQueryEvaluator xqueryEvaluator(String xqueryModeul, Map<String, String> varValueMap) throws SaxonApiException {
        Processor proc = new Processor(true);
        proc.setConfigurationProperty(FeatureKeys.TREE_MODEL, Builder.LINKED_TREE);

        XQueryCompiler comp = proc.newXQueryCompiler();
        comp.setUpdatingEnabled(true);
        XQueryExecutable exp = comp.compile(xqueryModeul);

        XQueryEvaluator qe = exp.load();

        for (Map.Entry<String, String> entry : varValueMap.entrySet()) {
            XdmNode source = proc.newDocumentBuilder().build(new StreamSource(IOUtils.toInputStream(entry.getValue())));
            qe.setExternalVariable(new QName(entry.getKey()), source);
        }
        return qe;
    }

    protected static XQueryEvaluator xqueryEvaluator(String xqueryModeul, Map<String, String> varValueMap, final String classpathModuleBase) throws SaxonApiException {
        Processor proc = new Processor(true);
        XQueryCompiler comp = proc.newXQueryCompiler();
        comp.setModuleURIResolver(new ClasspathBasedModuleURIResolver(classpathModuleBase));
        comp.setUpdatingEnabled(true);
        XQueryExecutable exp = comp.compile(xqueryModeul);

        XQueryEvaluator qe = exp.load();

        for (Map.Entry<String, String> entry : varValueMap.entrySet()) {
            if(entry.getValue().startsWith("<")) {
                XdmNode source = proc.newDocumentBuilder().build(new StreamSource(IOUtils.toInputStream(entry.getValue())));
                qe.setExternalVariable(new QName(entry.getKey()), source);
            } else {
                qe.setExternalVariable(new QName(entry.getKey()), new XdmAtomicValue(entry.getValue(), ItemType.STRING));
            }
        }
        return qe;
    }

    protected ModelFactory getModelFactory() {
        return MODEL_FACTORY;
    }

    protected static String toString(Map.Entry<String, SignatureDetails> entry) {
        return entry.getValue() instanceof NullSignatureDetails ? "()" : removePrelog(MODEL_FACTORY.toXml(entry.getValue()));
    }

    private static class ClasspathBasedModuleURIResolver implements ModuleURIResolver, Serializable {

        private static final long serialVersionUID = -480364471418950068L;
        private final String classpathModuleBase;

        public ClasspathBasedModuleURIResolver(final String classpathModuleBase) {
            this.classpathModuleBase = classpathModuleBase;
        }

        @Override
        public final StreamSource[] resolve(final String s, final String s1, final String[] strings)
                throws XPathException {
            StreamSource[] sources = new StreamSource[strings.length];
            for (int i = 0; i < strings.length; i++) {
                try {
                    String[] split = strings[i].split("/");
                    String fileName = split[split.length - 1];
                    LOGGER.debug("Trying to Load XQuery Module {} {}", classpathModuleBase, fileName);
                    Resource resource = new ClassPathResource(classpathModuleBase + fileName);
                    sources[i] = new StreamSource(resource.getInputStream());
                } catch (IOException e) {
                    throw propagate(e);
                }
            }
            return sources;
        }
    }
}

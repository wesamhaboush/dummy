package com.jpmorgan.dcpp.commons.xml;

public interface PrologOrXmlElement extends PrologXml, XmlElement {
}

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(value = DefaultConfig.class)
public class TestConfig {
    @Bean
    public String testDefaultString(){
        return "simple test string";
    }

    @Bean
    public PersonRepository personRepository(){
        return new PersonRepository() {
        };
    }
}

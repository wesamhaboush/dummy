package com.jpmorgan.ibtcp.dcpp.xquery;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.xml.xpath.XPathExpressionException;

import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XQueryEvaluator;
import net.sf.saxon.s9api.XdmValue;

import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.jpmorgan.dcpp.commons.Xmls;
import com.jpmorgan.ibtcp.dcpp.la.utils.FileUtility;

public class OtmIbmlResourceTest extends AbstractXqueryTest {
    private final static String OTM_IBML_RESOURCE = "PaperConfirmationBusinessRules/Common/get-otm-ibml-resource.xqy";

    @Test
    public void testPayloadPopulated() throws IOException, SaxonApiException, XPathExpressionException {
        //given
        final String xqueryModule =
                loadModuleAsString(OTM_IBML_RESOURCE).replace("lookup:oql($functionName, $id)", "()");
        final String payload =
                FileUtility
                        .readFileAsString("src/test/resources/TestData/payload/gdfpayloadwithoutotmattribute.xml");

        //when
        final ImmutableMap < String, String > varValueMap =
                ImmutableMap.< String, String > builder().put("payload", payload).build();

        final XQueryEvaluator qe = xqueryEvaluator(xqueryModule, varValueMap);
        final XdmValue result = qe.evaluate();
        //then
        assertEquals("2012-03-05",
                Xmls.xpathValue(result.toString(), "/dsThunderheadInput/otmAttributes/tradeDate/text()"));
    }
}

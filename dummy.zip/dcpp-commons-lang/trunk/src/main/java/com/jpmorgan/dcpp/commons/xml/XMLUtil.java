package com.jpmorgan.dcpp.commons.xml;

import org.apache.commons.lang3.StringEscapeUtils;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.regex.Pattern;

final class XMLUtil {

    public static final String DEFAULT_ENCODING = "UTF-8";

    private static final String NAME_START_CHAR_CLASS_RANGES = ""
        + "A-Z" + "_" + "a-z"
        + "\u00C0-\u00D6" + "\u00D8-\u00F6" + "\u00F8-\u02FF"
        + "\u0370-\u037D" + "\u037F-\u1FFF" + "\u200C-\u200D"
        + "\u2070-\u218F" + "\u2C00-\u2FEF" + "\u3001-\uD7FF"
        + "\uF900-\uFDCF" + "\uFDF0-\uFFFD";

    private static final String NAME_CHAR_CLASS_RANGES = ""
        + "-" // Must be first character of character class regex.
        + NAME_START_CHAR_CLASS_RANGES
        + Pattern.quote(".") + "0-9"
        + "\u00B7" + "\u0300-\u036F" + "\u203F-\u2040";

    public static final Pattern FULL_NAME_PATTERN = Pattern.compile(
        "^[" + NAME_START_CHAR_CLASS_RANGES + "]["
        + NAME_CHAR_CLASS_RANGES + "]*$");

    private XMLUtil() {
    }

    public static String escape(Object value, Version version) {
        if (value == null) return "";

        String text = value.toString();

        // Escape special characters in text.
        switch (version){
            case V1_0:
                return StringEscapeUtils.escapeXml10(text);
            case V1_1:
                return StringEscapeUtils.escapeXml11(text);
            default:
                return StringEscapeUtils.escapeXml10(text);
        }
    }

    public static boolean hasValue(final String value) {
        return (value != null) && (value.length() > 0);
    }

    public static boolean isComment(String text) {
        return (text != null) && !text.contains("--");
    }

    public static boolean isName(String text) {
        if (text == null) return false;

        // Names that start with "XML" in any case are reserved.
        if (text.toLowerCase().startsWith("xml")) return false;

        // Since that didn't match, try the full regular expression.
        return FULL_NAME_PATTERN.matcher(text).matches();
    }

    public static boolean isURI(String text) {
        try {
            new URI(text);
            return true;
        } catch (URISyntaxException e) {
            return false;
        }
    }

    public static boolean isVersion(String text) {
        return "1.0".equals(text) || "1.1".equals(text) || "1.2".equals(text);
    }

    public static void verifyComment(String text) {
        if (!isComment(text)) {
            throw new IllegalArgumentException(
                '"' + text + "\" is an invalid comment");
        }
    }

    public static void verifyName(String text) {
        if (!isName(text)) {
            throw new IllegalArgumentException(
                '"' + text + "\" is an invalid XML name");
        }
    }

    public static void verifyURI(String text) {
        if (!isURI(text)) {
            throw new IllegalArgumentException(
                '"' + text + "\" is an invalid URI");
        }
    }

    public static void verifyVersion(String text) {
        if (!isVersion(text)) {
            throw new IllegalArgumentException(
                '"' + text + "\" is an invalid XML version");
        }
    }
}

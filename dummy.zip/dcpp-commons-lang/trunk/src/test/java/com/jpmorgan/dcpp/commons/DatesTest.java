package com.jpmorgan.dcpp.commons;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.junit.Ignore;
import org.junit.Test;

import javax.xml.bind.DatatypeConverter;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;
import java.sql.Timestamp;
import java.util.Date;

import static junit.framework.Assert.*;


public class DatesTest {
    @Test
    public void testStandardizeDate() throws Exception {
        assertEquals("2012-12-23T12:10:44+06:00", Dates.standardizeDate("2012-12-23T12:10:44+0600"));
        assertEquals("2012-12-23T12:10:44+06:00", Dates.standardizeDate("2012-12-23T12:10:44+06:00"));
        assertEquals("1999-07-01T19:30:00+10:00", Dates.standardizeDate("1999-07-01T19:30+10:00"));
    }

    @Test
    public void testToDateTime() throws Exception {
        assertEquals(new DateTime(DateTimeZone.forOffsetHours(6))
                .withYear(2012).withMonthOfYear(12).withDayOfMonth(23)
                .withHourOfDay(12).withMinuteOfHour(10).withSecondOfMinute(44).withMillisOfSecond(0),
                Dates.toDateTime("2012-12-23T12:10:44+0600"));

        assertEquals(new DateTime(DateTimeZone.forOffsetHours(6))
                .withYear(2012).withMonthOfYear(12).withDayOfMonth(23)
                .withHourOfDay(12).withMinuteOfHour(10).withSecondOfMinute(44).withMillisOfSecond(0),
                Dates.toDateTime("2012-12-23T12:10:44+06:00"));

        assertEquals(new DateTime(DateTimeZone.forOffsetHours(10))
                .withYear(1999).withMonthOfYear(7).withDayOfMonth(1)
                .withHourOfDay(19).withMinuteOfHour(30).withSecondOfMinute(0).withMillisOfSecond(0),
                Dates.toDateTime("1999-07-01T19:30+10:00"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testToDateTimeIfInvalid() throws Exception {
        Dates.toDateTime("rabbish");
    }

    @Test
    public void testIsIsoDateInvalidDate() throws Exception {
        assertFalse(Dates.isIsoDate("rabbish"));
    }

  /**
   * this method needs fixing. i am probably missing something because
   * this test does not succeed on all machines
   * @throws Exception
   */
    @Test
//    @Ignore
    public void testTimeZoneConversion() throws Exception {
        //given
//      System.setProperty("user.timezone", "Africa/Harare");
        final LocalDateTime dt = LocalDateTime.parse("2012-10-01T16:00:00");
//      System.out.println(dt);
        //when
        final DateTime newDt = Dates.inTimeZone(dt, "Asia/Damascus", "Europe/London");

//      System.out.println(newDt);
//      System.out.println(newDt.toLocalDateTime());

        //then
        assertEquals("2012-10-01T14:00:00.000+01:00", newDt.toString());
    }

    @Test
    public void testTimeZoneConversionNoSourceTimeZone() throws Exception {
        //given
        final DateTime dt = Dates.toDateTime("2012-08-26T11:30:00+0600");

        //when
        final DateTime newDt = Dates.inTimeZone(dt, "Europe/London");

        //then
        assertEquals("2012-08-26T11:30:00.000+06:00", dt.toString());
        assertEquals("2012-08-26T06:30:00.000+01:00", newDt.toString());
    }

    @Test
    public void testTimeZoneConversionNoSourceZuluFormat() throws Exception {
        //given
        final DateTime dt = Dates.toDateTime("2012-08-26T11:30:00.000Z");

        //when
        final DateTime newDt = Dates.inTimeZone(dt, "Europe/London");

        //then
        assertEquals("2012-08-26T11:30:00.000Z", dt.toString());
        assertEquals("2012-08-26T12:30:00.000+01:00", newDt.toString());
    }

    @Test
    public void testDateTime2GregorianCalendar() throws DatatypeConfigurationException {
        //given
        final DateTime dt = Dates.toDateTime("2012-08-26T11:30:00.000Z");

        //when
        final XMLGregorianCalendar newDt = Dates.toXmlGregorianCalendar(dt);
        final String printedNewDt = DatatypeConverter.printDateTime(newDt.toGregorianCalendar());

        //then
        assertEquals("2012-08-26T11:30:00Z", printedNewDt);
        assertEquals("2012-08-26T11:30:00.000Z", dt.toString());
        assertEquals("2012-08-26T11:30:00.000Z", newDt.toString());
    }

    @Test
    public void testDateTime2GregorianCalendar_WithOffset() throws DatatypeConfigurationException {
        //given
        final DateTime dt = Dates.toDateTime("2012-08-26T11:30:00+0600");

        //when
        final XMLGregorianCalendar newDt = Dates.toXmlGregorianCalendar(dt);
        final String printedNewDt = DatatypeConverter.printDateTime(newDt.toGregorianCalendar());

        //then
        assertEquals("2012-08-26T11:30:00+06:00", printedNewDt);
        assertEquals("2012-08-26T11:30:00.000+06:00", dt.toString());
        assertEquals("2012-08-26T11:30:00.000+06:00", newDt.toString());
    }

  @Test
  public void testToXmlGregorianCalendar(){
    //given
    final String date = "2012-08-26T11:30:00+0600";

    //when
    final XMLGregorianCalendar xmlGregorianCalendar = Dates.toXmlGregorianCalendar(date);

    //then
    assertEquals("2012-08-26T05:30:00.000Z", xmlGregorianCalendar.toString());
  }

  @Test
   public void testToXmlGregorianCalendar_Zulu(){
    //given
    final String date = "2012-08-26T11:30:00Z";

    //when
    final XMLGregorianCalendar xmlGregorianCalendar = Dates.toXmlGregorianCalendar(date);

    //then
    assertEquals("2012-08-26T11:30:00.000Z", xmlGregorianCalendar.toString());
  }

  //at the moment, the behaviour is dependent on the machine it happens on when no time zone is present in the string
  //we need to think how to handle this
  @Test
  @Ignore
  public void testToXmlGregorianCalendar_NoTimeZone(){
          System.setProperty("user.timezone", "Africa/Harare");
    //given
    final String date = "2012-08-26T11:30:00";

    Dates.isIsoDate(date);
    //when
    final XMLGregorianCalendar xmlGregorianCalendar = Dates.toXmlGregorianCalendar(date);

    //then
    assertEquals("2012-08-26T10:30:00.000Z", xmlGregorianCalendar.toString());
  }

  @Test
  public void testToString_Zulu() throws DatatypeConfigurationException {
    //given
    final XMLGregorianCalendar date = Dates.toXmlGregorianCalendar(Dates.toDateTime("2012-08-26T11:30:00Z"));

    //when
    final String dateAsString = Dates.toString(date);

    //then
    assertEquals("2012-08-26T11:30:00+00:00", dateAsString);
  }

  @Test
  public void testToXmlGregorianCalendar_RoundTrip(){
    //given
    final String date = "2012-08-26T11:30:00+0600";

    //when
    final XMLGregorianCalendar xmlGregorianCalendar = Dates.toXmlGregorianCalendar(date);
    final String asString = Dates.toString(xmlGregorianCalendar);

    //then
    assertEquals("2012-08-26T05:30:00.000Z", xmlGregorianCalendar.toString());
    assertEquals("2012-08-26T05:30:00+00:00", asString);
  }

  @Test
  public void testFormatter(){
    //given
    final DateTime date = Dates.toDateTime("2012-08-26T11:30:00+0600");

    //when

    //then
    assertEquals("2012-08-26T11:30:00+06:00", Dates.formatter("yyyy-MM-dd'T'HH:mm:ssZZ").print(date));
    assertEquals("2012-08-26T11:30:00+0600", Dates.formatter("yyyy-MM-dd'T'HH:mm:ssZ").print(date));
    assertEquals("2012-08-26T11:30+0600", Dates.formatter("yyyy-MM-dd'T'HH:mmZ").print(date));
    assertEquals("11:30+0600", Dates.formatter("HH:mmZ").print(date));
  }

  @Test
  public void testToSqlDate(){
    //given
    final java.util.Date utilDate = DateTime.now().toDate();

    //when
    java.sql.Date sqlDate = Dates.toSqlDate(utilDate);

    //then
    assertEquals(utilDate.getTime(), sqlDate.getTime());
  }

  @Test
  public void testNoMillisWorksToEliminateMillis(){
    //given
    final java.util.Date utilDate = DateTime.now().toDate();

    if(utilDate.getTime() % 1000 == 0){
      utilDate.setTime(utilDate.getTime() + 1);
    }

    //when
    java.util.Date utilDateWithoutMillis = Dates.noMillis(utilDate);

    //then
    assertTrue(utilDateWithoutMillis.getTime() % 1000 == 0);
    assertTrue(utilDate.getTime() - utilDateWithoutMillis.getTime() < 1000);
  }

  @Test
  public void testToSqlTimestamp(){
    //given
    final java.util.Date utilDate = DateTime.now().toDate();
    final java.util.Date nullUtilDate = null;

    //when
    Timestamp sqlTimestamp = Dates.toSqlTimestamp(utilDate);

    //then
    assertEquals(utilDate.getTime(), sqlTimestamp.getTime());
    assertNull(Dates.toSqlTimestamp(nullUtilDate));
  }

  @Test
  public void testNow(){
    assertEquals(DateTime.class, Dates.Now.dateTime().getClass());
    assertEquals(Date.class, Dates.Now.date().getClass());
    assertEquals(Timestamp.class, Dates.Now.timestamp().getClass());
  }
}

package com.jpmorgan.dcpp.commons;

import org.junit.Test;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.jpmorgan.dcpp.commons.Iterators.range;
import static junit.framework.Assert.assertEquals;

public class IteratorsTest {
  @Test
  public void testRange_positive() throws Exception {
    //given
    final List<Integer> result = newArrayList();

    //when
    for(final Integer i : range(5, 9)){
      result.add(i);
    }

    //then
    assertEquals(newArrayList(5, 6, 7, 8, 9), result);
  }

  @Test
  public void testRange_positiveWithStep() throws Exception {
    //given
    final List<Integer> result = newArrayList();

    //when
    for(final Integer i : range(5, 9, 2)){
      result.add(i);
    }

    //then
    assertEquals(newArrayList(5, 7, 9), result);
  }

  @Test
  public void testRange_crossSign() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, 9)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9), values);
  }

  @Test
  public void testRange_crossSignWithStep() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, 9, 3)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1, 2, 5, 8), values);
  }

  @Test
  public void testRange_negative() throws Exception {
    //given
    final List<Integer> result = newArrayList();

    //when
    for(final Integer i : range(-9, -1)){
      result.add(i);
    }

    //then
    assertEquals(newArrayList(-9, -8, -7, -6, -5, -4, -3, -2, -1), result);
  }

  @Test
  public void testRange_negativeWithStep() throws Exception {
    //given
    final List<Integer> result = newArrayList();

    //when
    for(final Integer i : range(-9, -1, 4)){
      result.add(i);
    }

    //then
    assertEquals(newArrayList(-9, -5, -1), result);
  }

  @Test
  public void testRange_reversePositive() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(9, 5)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(9, 8, 7, 6, 5), values);
  }

  @Test
  public void testRange_reversePositiveWithStep() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(9, 5, 6)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(9), values);
  }

  @Test
  public void testRange_reverseCrossSign() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(9, -1)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1), values);
  }

  @Test
  public void testRange_reverseCrossSignWithStep() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(9, -1, 7)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(9, 2), values);
  }

  @Test
  public void testRange_reverseNegative() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, -9)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1, -2, -3, -4, -5, -6, -7, -8, -9), values);
  }

  @Test
  public void testRange_reverseNegativeWithStep() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, -9, 2)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1, -3, -5, -7, -9), values);
  }

  @Test
  public void testRange_singleItem() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, -1)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1), values);
  }

  @Test
  public void testRange_singleItemWithStep() throws Exception {
    //given
    final List<Integer> values = newArrayList();

    //when
    for(final Integer i : range(-1, -1, 8)){
      values.add(i);
    }

    //then
    assertEquals(newArrayList(-1), values);
  }
}

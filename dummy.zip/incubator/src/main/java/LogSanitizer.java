import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.Range;
import com.jpmorgan.dcpp.commons.Xmls;
import org.apache.commons.lang3.tuple.Pair;

import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import static com.google.common.base.Joiner.on;
import static com.google.common.base.Preconditions.checkState;
import static org.apache.commons.io.Charsets.UTF_8;
import static org.apache.commons.io.FileUtils.*;
import static org.apache.commons.io.IOUtils.readLines;
import static org.apache.commons.lang3.StringUtils.join;

public class LogSanitizer{
    public static final void main(final String...args) throws IOException, XPathExpressionException {
        final List<String> lines = readLines(openInputStream(getFile("C:/dev/tdf-logs/sendfollowing.log")), UTF_8);
        List<String> xmlLines = Lists.transform(lines, removePrefixBeforeXml());
        final String xmlFile = "<root>" + on('\n').join(xmlLines) + "</root>";
//        write(getFile("C:/dev/tdf-logs/sendfollowing-sanitized.xml"), xmlFile, UTF_8);
        List<String> documentIds = Xmls.xpathValues(xmlFile, "/root/sendDocument/header/documentId/text()");
        List<String> addresses = Xmls.xpathValues(xmlFile, "/root/sendDocument/destination/recipient/address/text()");
        checkState(addresses.size() == documentIds.size(), String.format("size of ids and addresses are different addresses[%s], documentIds[%s]!!", addresses.size(), documentIds.size()));
        System.out.println(new HashSet<String>(documentIds).size());
        System.out.println(new HashSet<String>(addresses).size());
        System.out.println(String.format("[%s][%s]", documentIds.size(), documentIds));
        System.out.println(String.format("[%s][%s]", addresses.size(), addresses));
        List<String> csvLines = new LinkedList<String>();
        for(int i : com.jpmorgan.dcpp.commons.Iterators.range(0, addresses.size() - 1)){
            csvLines.add(join(documentIds.get(i), ",", addresses.get(i)));
        }
        write(getFile("C:/dev/tdf-logs/sendfollowing.csv"), on('\n').join(csvLines), UTF_8);
    }

    private static Function<String, String> removePrefixBeforeXml() {
        return new Function<String, String>() {
            @Override
            public String apply(final String input) {
                return input.replaceAll("^tdf.*?>", "");
            }
        };
    }
}

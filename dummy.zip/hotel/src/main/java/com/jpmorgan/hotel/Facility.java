package com.jpmorgan.hotel;

public enum Facility {
    SWIMMINGPOOL,
    ENSUITE_BATHROOM,
    ROOM_BREAKFAST,
    INTERNET,
    LATE_CHECKOUT;
}
